import UIKit
import WebKit

class headerTemplateView: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {
    
    @IBOutlet var headerBody        : UIView!
    @IBOutlet weak var headerTitle  : UILabel!
    @IBOutlet weak var homeIcon     : UIImageView!
    @IBOutlet weak var horizontalRule: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
        
        guard let view = UINib(nibName: "headerTemplateView", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]
        
        // color
        self.headerBody.backgroundColor = commonFunc.deepGreen
        
        //
        self.homeIcon.isUserInteractionEnabled   = true
        
        self.horizontalRule.backgroundColor = commonFunc.brightGray
        
        self.addSubview(view)
        
    }
    
    func setHeaderTitlea(str:String) {
        self.headerTitle.text   = str
    }

}
