import UIKit
import WebKit

class swipeTemplateView: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {

    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentsView: UIView!
    
    // title view related
    @IBOutlet weak var titleView        : UIView!
    @IBOutlet weak var markIcon         : UILabel!
    @IBOutlet weak var titleFooterLine  : UIView!
    @IBOutlet weak var titleLabel       : UILabel!
    @IBOutlet weak var rightIconLabel   : UILabel!
    @IBOutlet weak var imgRightIcon: UIImageView!
    
    @IBOutlet weak var hyperLinkTextView: UITextView!
    @IBOutlet weak var contentsImage    : UIImageView!
    
    // nav view related
    @IBOutlet weak var navView          : UIView!
    
    @IBOutlet weak var imgView          : UIView!
    @IBOutlet weak var iconCoverView    : UIView!
    @IBOutlet weak var imgIcon          : UIImageView!
    
    
    @IBOutlet weak var imgUnderLineView : UIView!
    @IBOutlet weak var navBackView      : UIView!
    
    // nav sub field related
    @IBOutlet weak var navSubFieldView      : UIView!
    @IBOutlet weak var navFuncButton1View   : UIView!
    @IBOutlet weak var navFuncButton1Label  : UILabel!
    @IBOutlet weak var navFuncButton1Icon   : UIImageView!
    
    @IBOutlet weak var navFuncButton2View   : UIView!
    @IBOutlet weak var navFuncButton2Label  : UILabel!
    @IBOutlet weak var navFuncButton2Icon   : UIImageView!
    
    @IBOutlet weak var navFuncButton3View   : UIView!
    @IBOutlet weak var navFuncButton3Label  : UILabel!
    @IBOutlet weak var navFuncButton3Icon   : UIImageView!
    
    @IBOutlet weak var nextButtonView       : UIView!
    @IBOutlet weak var nextButtonLabel      : UILabel!
    
    @IBOutlet weak var footerView           : UIView!
    
    // remove "weak" option to change status
    @IBOutlet var constraintContentsHeight: NSLayoutConstraint!
    
    @IBOutlet var constraintTitleTop: NSLayoutConstraint!
    @IBOutlet var constraintTitleHeight: NSLayoutConstraint!
    @IBOutlet var constraintTitleBottomToHyperLinkText: NSLayoutConstraint!
    
    @IBOutlet var constraintHyperLinkTextBottomToImage: NSLayoutConstraint!
    @IBOutlet var constraintHyperLinkTextBottomToSuperView: NSLayoutConstraint!
    @IBOutlet var constraintContentsImageBottomToSuperView: NSLayoutConstraint!
    
    @IBOutlet var constraintNavOpenHeight: NSLayoutConstraint!
    @IBOutlet var constraintNavCloseHeight: NSLayoutConstraint!
    @IBOutlet var constraintNavMinHeight: NSLayoutConstraint!
    
    @IBOutlet var constraintFooterHeight: NSLayoutConstraint!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
        
        guard let view = UINib(nibName: "swipeTemplateView", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]
                
        // initial setting
        self.hideContentsView(bool: false)
        self.hideImageView(bool: true)
        self.hideNavView(bool: false)
        self.hideRightIconLabel(bool: true)
        self.hideNextButtonView(bool: true)
        
        // color
//        self.contentsView.backgroundColor           = commonFunc.white
        self.contentsView.backgroundColor           = commonFunc.clear
        self.titleFooterLine.backgroundColor        = commonFunc.deepGreen
//        self.titleLabel.backgroundColor             = commonFunc.white
        self.titleLabel.backgroundColor             = commonFunc.clear
        self.rightIconLabel.backgroundColor         = commonFunc.deepPink

//        self.hyperLinkTextView.backgroundColor      = commonFunc.white
        self.hyperLinkTextView.backgroundColor      = commonFunc.clear
        
        self.navView.backgroundColor                = commonFunc.clear
        
        self.imgView.backgroundColor                = commonFunc.clear
//        self.imgIcon.backgroundColor                = commonFunc.white
        self.imgIcon.backgroundColor                = commonFunc.clear
        self.iconCoverView.backgroundColor          = commonFunc.brightLime.withAlphaComponent(0.5)
        self.imgUnderLineView.backgroundColor       = commonFunc.brightLime.withAlphaComponent(0.5)

        self.navBackView.backgroundColor            = commonFunc.brightLime.withAlphaComponent(0.5)
        self.navSubFieldView.backgroundColor        = commonFunc.clear

        self.navFuncButton1View.backgroundColor     = commonFunc.clear
        self.navFuncButton2View.backgroundColor     = commonFunc.clear
        self.navFuncButton3View.backgroundColor     = commonFunc.clear
        
        self.navFuncButton1Label.backgroundColor    = commonFunc.brightYellow
        self.navFuncButton2Label.backgroundColor    = commonFunc.brightYellow
        self.navFuncButton3Label.backgroundColor    = commonFunc.brightYellow
        
        self.nextButtonView.backgroundColor         = commonFunc.clear
        self.nextButtonLabel.backgroundColor        = commonFunc.deepGreen
        
        self.footerView.backgroundColor             = commonFunc.deepGreen
        
        // style
        self.navFuncButton1Label.clipsToBounds          = true
        self.navFuncButton1Label.layer.cornerRadius     = 5
        
        self.navFuncButton2Label.clipsToBounds          = true
        self.navFuncButton2Label.layer.cornerRadius     = 5
        
        self.navFuncButton3Label.clipsToBounds          = true
        self.navFuncButton3Label.layer.cornerRadius     = 5
        
//        self.navFuncButton1Label.layer.maskedCorners    = [.layerMinXMaxYCorner, .layerMaxXMinYCorner]
//        self.navFuncButton2Label.layer.maskedCorners    = [.layerMinXMaxYCorner, .layerMaxXMinYCorner]
//        self.navFuncButton3Label.layer.maskedCorners    = [.layerMinXMaxYCorner, .layerMaxXMinYCorner]
        
        self.nextButtonLabel.clipsToBounds      = true
        self.nextButtonLabel.layer.cornerRadius = 5

        self.rightIconLabel.clipsToBounds       = true
        self.rightIconLabel.layer.cornerRadius  = self.rightIconLabel.frame.height / 2
        
        self.iconCoverView.layer.maskedCorners  = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        self.iconCoverView.layer.cornerRadius   = 10

        // title mark icon setting
        self.markIcon.layer.borderWidth         = 8
        self.markIcon.layer.borderColor         = commonFunc.deepGreen.cgColor
//        self.markIcon.backgroundColor           = commonFunc.white
        self.markIcon.backgroundColor           = commonFunc.clear

        // link text setting
        self.hyperLinkTextView.isSelectable     = true
        self.hyperLinkTextView.isEditable       = false
        self.hyperLinkTextView.isUserInteractionEnabled = false
        self.hyperLinkTextView.delegate         = self
        
        // set shadow
        self.navFuncButton1View.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.navFuncButton1View.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.navFuncButton1View.layer.shadowRadius  = 3
        self.navFuncButton2View.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.navFuncButton2View.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.navFuncButton2View.layer.shadowRadius  = 3
        self.navFuncButton3View.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.navFuncButton3View.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.navFuncButton3View.layer.shadowRadius  = 3
        self.nextButtonView.layer.shadowColor       = commonFunc.deepBlack.cgColor
        self.nextButtonView.layer.shadowOffset      = CGSize(width: 3, height: 5)
        self.nextButtonView.layer.shadowRadius      = 3

        self.showNavFuncButton1Shadow()
        self.showNavFuncButton2Shadow()
        self.showNavFuncButton3Shadow()
        self.showNextButtonShadow()
        
        // init navFuncButton
        self.hideNavFuncButton1(bool: true)
        self.hideNavFuncButton2(bool: true)
        self.hideNavFuncButton3(bool: true)
        
        self.setNavFuncButton1Text(str: "Button 1")
        self.setNavFuncButton2Text(str: "Button 2")
        self.setNavFuncButton3Text(str: "Button 3")

        // define of tapping action
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickImg), button: self.imgView)
        
        // ピンチジェスチャ
        // 現在のtransfromを保存
        self.defaultXPoint = contentsView.center.x
        self.defaultYPoint = contentsView.center.y
        self.defaultWidth  = contentsView.frame.size.width
        self.defaultHeight = contentsView.frame.size.height
        
        let pinchGesture = UIPinchGestureRecognizer()
        pinchGesture.addTarget(self, action: #selector(pinchAction(_:) ) )
        self.contentsView.addGestureRecognizer(pinchGesture)

        
        // ダブルタップジェスチャ
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(doubleTapAction(_:)))
        doubleTapGesture.numberOfTapsRequired = 2
        self.contentsView.addGestureRecognizer(doubleTapGesture)
        
        self.hyperLinkTextView.isScrollEnabled  = false
        
        self.constraintContentsHeight.constant  = UIScreen.main.bounds.size.height
        
        self.addSubview(view)
        
    }

    // hide bottom nav
    func hideNavView(bool : Bool){
        self.navView.isHidden       = bool
    }
    
    // hide bottom nav
    func hideImageView(bool : Bool){
        self.contentsImage.isHidden = bool
    }

    // hide nav
    func hideContentsView(bool : Bool){
        self.contentsView.isHidden  = bool
    }
    
    // set title text
    func setTitle(str:String){
        self.titleLabel.text        = str
    }
    
    // set link text
    func setLinkText(str: NSMutableAttributedString){
        self.hyperLinkTextView.attributedText = str
        self.hyperLinkTextView.layoutIfNeeded()
        self.hyperLinkTextView.sizeToFit()
    }

    // set menu label text
    func setNavFuncButton1Text(str:String){
        self.navFuncButton1Label.text   = str
    }

    // set menu label text
    func setNavFuncButton2Text(str:String){
        self.navFuncButton2Label.text   = str
    }

    // set menu label text
    func setNavFuncButton3Text(str:String){
        self.navFuncButton3Label.text   = str
    }
    
    func setNavFuncButton1Image(str:String) {
        self.navFuncButton1Icon.image   = UIImage(named: str)
    }
    
    func setNavFuncButton2Image(str:String) {
        self.navFuncButton2Icon.image   = UIImage(named: str)
    }
    
    func setNavFuncButton3Image(str:String) {
        self.navFuncButton3Icon.image   = UIImage(named: str)
    }

    // hide func button
    func hideNavFuncButton1(bool:Bool){
        self.navFuncButton1View.isHidden = bool
    }

    // hide func button
    func hideNavFuncButton2(bool:Bool){
        self.navFuncButton2View.isHidden = bool
    }

    // hide func button
    func hideNavFuncButton3(bool:Bool){
        self.navFuncButton3View.isHidden = bool
    }

    // hide right icon -> change hide icon
    func hideRightIconLabel(bool:Bool){
        
        // old icon is always hidden
        self.rightIconLabel.isHidden = true
        
        // new icon image
        //self.imgRightIcon.isHidden = bool
        
        if(bool){
            self.imgRightIcon.image = UIImage(named: "smartphone")
            self.scrollView.backgroundColor = commonFunc.white
        }
        else{
            self.imgRightIcon.image = UIImage(named: "laptop")
            self.scrollView.backgroundColor = commonFunc.mame
        }
    }
    
    // set next Label text
    func setImage(str:String){
        self.contentsImage.image     = UIImage(named: str)
    }
    
    func hideNextButtonView(bool:Bool){
        self.nextButtonView.isHidden    = bool
    }
    
    func showNavFuncButton1Shadow(){
        self.navFuncButton1View.layer.shadowOpacity = 0.6
    }
    
    func hideNavFuncButton1Shadow(){
        self.navFuncButton1View.layer.shadowOpacity = 0
    }

    func showNavFuncButton2Shadow(){
        self.navFuncButton2View.layer.shadowOpacity = 0.6
    }
    
    func hideNavFuncButton2Shadow(){
        self.navFuncButton2View.layer.shadowOpacity = 0
    }

    func showNavFuncButton3Shadow(){
        self.navFuncButton3View.layer.shadowOpacity = 0.6
    }
    
    func hideNavFuncButton3Shadow(){
        self.navFuncButton3View.layer.shadowOpacity = 0
    }

    func showNextButtonShadow(){
        self.nextButtonView.layer.shadowOpacity = 0.6
    }
    
    func hideNextButtonShadow(){
        self.nextButtonView.layer.shadowOpacity = 0
    }

    func setTitleHeight(height:CGFloat){
        self.constraintTitleHeight.constant      = height
    }

    func setContentsHeight(height:CGFloat){
        self.constraintContentsHeight.constant   = height
    }

    func setNavOpenHeight(){
        
        self.constraintNavOpenHeight.constant = 5
        self.constraintNavOpenHeight.constant += self.imgView.bounds.height

        if(!self.navFuncButton1View.isHidden) {
            self.constraintNavOpenHeight.constant += self.navFuncButton1View.bounds.height
            self.constraintNavOpenHeight.constant += 5
        }

        if(!self.navFuncButton2View.isHidden) {
            self.constraintNavOpenHeight.constant += self.navFuncButton2View.bounds.height
            self.constraintNavOpenHeight.constant += 5
        }

        if(!self.navFuncButton3View.isHidden) {
            self.constraintNavOpenHeight.constant += self.navFuncButton1View.bounds.height
            self.constraintNavOpenHeight.constant += 5
        }

    }
    
    func setNavFuncCount(num: Int) {
        
        for i in 1...num {
            
            if(i>=1){
                self.hideNavFuncButton1(bool: false)
            }
            
            if(i>=2){
                self.hideNavFuncButton2(bool: false)
            }
            
            if(i>=3){
                self.hideNavFuncButton3(bool: false)
            }
            
        }
    }

    func calcContentsHeight(){
        
        var contentsHeight: CGFloat = 0

        // print("[Debug Swipe] top margin of title : \(self.constraintTitleTop.constant)")
        contentsHeight += self.constraintTitleTop.constant

        // print("[Debug Swipe] height of title : \(self.constraintTitleHeight.constant)")
        contentsHeight += self.constraintTitleHeight.constant

        // print("[Debug Swipe] bottom margin of title : \(self.constraintTitleBottomToHyperLinkText.constant)")
        contentsHeight += self.constraintTitleBottomToHyperLinkText.constant

        // print("[Debug Swipe] aaaaaa : \(self.hyperLinkTextView.frame)")

        // print("[Debug Swipe] height of hyperLinkTextView : \(hyperLinkTextView.frame.height)")
        contentsHeight += self.hyperLinkTextView.frame.height
        
        if(constraintHyperLinkTextBottomToImage.isActive){
            // print("[Debug Swipe] bottom margin of hyperLinkTextView to imageView : \(constraintHyperLinkTextBottomToImage.constant)")
            contentsHeight += constraintHyperLinkTextBottomToImage.constant
        }
        
//        if(self.constraintHyperLinkTextBottomToSuperView.isActive){
//            // print("[Debug Swipe] bottom margin of hyperLinkTextView : \(constraintHyperLinkTextBottomToSuperView.constant)")
//            contentsHeight += constraintHyperLinkTextBottomToSuperView.constant
//        }
        
//        if(self.constraintContentsImageBottomToSuperView.isActive){
//            // print("[Debug Swipe] bottom margin of imageView : \(constraintContentsImageBottomToSuperView.constant)")
//           contentsHeight += constraintContentsImageBottomToSuperView.constant
//        }

        if(!self.contentsImage.isHidden){
            // print("[Debug Swipe] height of imageView : \(self.contentsImage.image!.size.height)")
            contentsHeight += self.contentsImage.image!.size.height

//            let height = self.frame.size.width * (self.contentsImage.image!.size.height / self.contentsImage.image!.size.width)
//            contentsHeight += height
        }
                
        // print("[Debug Swipe] height of contents : \(contentsHeight)")
        self.constraintContentsHeight.constant  = contentsHeight
        
    }
    
    func checkStyle(){

        // contents image:hide
        if(self.contentsImage.isHidden){
            self.constraintHyperLinkTextBottomToImage.isActive      = false
            //self.constraintHyperLinkTextBottomToSuperView.isActive  = true
//            self.constraintContentsImageBottomToSuperView.isActive  = false
        }
        else {
            self.constraintHyperLinkTextBottomToImage.isActive      = true
            //self.constraintHyperLinkTextBottomToSuperView.isActive  = false
//            self.constraintContentsImageBottomToSuperView.isActive  = true
        }

        // nav view
        if(!self.navView.isHidden){
            // print("[checkStyle] nav:show")
            self.openNavView()
        }
        else{
            // print("[checkStyle] nav:hide")
        }
        
    }
    
    // adjust view size
    func adjustViewStyle(displayHeight:CGFloat){
        self.setTitleHeight(height: displayHeight * 0.06)
        self.setNavOpenHeight()
        self.checkStyle()
        self.calcContentsHeight()
    }

    // open or close bottom nav when click img
    @objc func didClickImg(gesture: UILongPressGestureRecognizer){
        
        // handle touch down and touch up events separately
        if gesture.state == .began {
            
        }
        else if gesture.state == .ended { // optional for touch up event catching

            // when nav view is opened
            if self.constraintNavOpenHeight.isActive {
                self.closeNavView()
            }
            // when nav view is closed
            else {
                self.openNavView()
            }
            
        }
        
    }

    func openNavView(){
        
        self.constraintNavOpenHeight.isActive                   = true
        self.constraintNavCloseHeight.isActive                  = false
        self.imgIcon.image                                      = UIImage(named: "closeNav")
        self.navSubFieldView.isHidden                           = false
        
    }

    func closeNavView(){
        
        self.constraintNavOpenHeight.isActive                   = false
        self.imgIcon.image                                      = UIImage(named: "openNav")
        self.navSubFieldView.isHidden                           = true
        
        if self.navView.frame.height * self.constraintNavCloseHeight.multiplier < self.constraintNavMinHeight.constant {
            self.constraintNavCloseHeight.isActive     = false
            self.constraintNavMinHeight.isActive       = true
        }
        else {
            self.constraintNavCloseHeight.isActive     = true
            self.constraintNavMinHeight.isActive       = false
        }
        
    }

    // *************************************************** //
    // *************************************************** //
    // ピンチイン・アウト　ドラッグ関連
    // *************************************************** //
    // *************************************************** //
    
    //
    var currentScale:CGFloat = 1
    
    var defaultXPoint:CGFloat = 0
    var defaultYPoint:CGFloat = 0
    var defaultWidth:CGFloat = 0
    var defaultHeight:CGFloat = 0
    
    func setDefaultHeight(height : CGFloat){
        self.defaultHeight = height
    }

    // Pinch
    @objc func pinchAction(_ gesture: UIPinchGestureRecognizer ){
        
        ////前回の拡大縮小も含めて初期値からの拡大縮小比率を計算
        let scale = gesture.scale - 1 + currentScale
        
        let maxScale: CGFloat = 3.0
        let minScale: CGFloat = 0.8
        
        // 縮小はしない
        var rate = scale < minScale ? minScale : scale
        
        UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
            //拡大縮小の反映
            self.contentsView.transform = CGAffineTransform(scaleX: rate , y: rate )
        }, completion: nil)

        if(gesture.state == .ended) {

            if(rate < 1){
                rate = 1
                UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
                    //拡大縮小の反映
                    self.contentsView.transform = CGAffineTransform(scaleX: rate , y: rate )
                }, completion: nil)
            }
            else if(rate > maxScale){
                rate = maxScale
                UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
                    //拡大縮小の反映
                    self.contentsView.transform = CGAffineTransform(scaleX: rate , y: rate )
                }, completion: nil)
            }
            //終了時に拡大・縮小率を保存しておいて次回に使いまわす
            currentScale = rate
        }

    }
    // 元のサイズに戻す
    @objc func doubleTapAction(_ gesture: UITapGestureRecognizer ){

        // 等倍
        let rate: CGFloat = 1
        
        UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
            //拡大縮小の反映
            self.contentsView.transform = CGAffineTransform(scaleX: rate , y: rate )
        }, completion: nil)

        if(gesture.state == .ended) {
            //終了時に拡大・縮小率を保存しておいて次回に使いまわす
            currentScale = rate
        }
        
    }

}
