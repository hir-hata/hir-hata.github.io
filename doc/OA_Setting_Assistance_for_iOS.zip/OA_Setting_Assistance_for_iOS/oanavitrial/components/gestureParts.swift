import UIKit

class gestureParts: UILongPressGestureRecognizer {
    
    func uiViewGestureInit(target: Any?, action: Selector?, button: UIView){
        
        let pressGesture = UILongPressGestureRecognizer(target: target, action: action)
        pressGesture.minimumPressDuration = 0
        button.addGestureRecognizer(pressGesture)
        
    }
    
    func uiLabelGestureInit(target: Any?, action: Selector?, button: UILabel){
        
        let pressGesture = UILongPressGestureRecognizer(target: target, action: action)
        pressGesture.minimumPressDuration = 0
        button.addGestureRecognizer(pressGesture)
        
    }
    
}
