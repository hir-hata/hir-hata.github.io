import UIKit
import WebKit

class bottomTabMenu: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {
    
    @IBOutlet weak var tab01: tabButton!
    @IBOutlet weak var tab02: tabButton!
    @IBOutlet weak var tab03: tabButton!
    @IBOutlet weak var tab04: tabButton!
    @IBOutlet weak var tab05: tabButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
                
        guard let view = UINib(nibName: "bottomTabMenu", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]

        self.tab01.setTabText(text: "非常用持ち出し袋はシルバー")
        self.tab02.setTabText(text: "図書館")
        
        // viewに追加
        self.addSubview(view)
        
    }

}
