import UIKit
import WebKit

class swipeTemplateView_v3: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {

    @IBOutlet var TemplateBody: UIView!
    @IBOutlet weak var SafeAreaBottom: UIView!
    @IBOutlet weak var TitleView: titleView!
    @IBOutlet weak var ScrollContent: scrollContent!
    @IBOutlet weak var Hr01: UIView!
    @IBOutlet weak var Hr02: UIView!
    @IBOutlet weak var Hr03: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
        
        guard let view = UINib(nibName: "swipeTemplateView_v3", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]
        
        self.SafeAreaBottom.backgroundColor = commonFunc.deepGreen
        
        self.Hr01.backgroundColor = commonFunc.brightGray.withAlphaComponent(0.7)
        self.Hr02.backgroundColor = commonFunc.brightGray
        self.Hr03.backgroundColor = commonFunc.brightGray

        // ピンチジェスチャ
        let pinchGesture = UIPinchGestureRecognizer()
        pinchGesture.addTarget(self, action: #selector(pinchAction(_:) ) )
        self.TemplateBody.addGestureRecognizer(pinchGesture)

        // ダブルタップジェスチャ
//        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(doubleTapAction(_:)))
//        doubleTapGesture.numberOfTapsRequired = 2
//        self.TemplateBody.addGestureRecognizer(doubleTapGesture)

        // タップジェスチャ
//        let singleTapGesture = UITapGestureRecognizer(target: self, action: #selector(singleTapAction(_:)))
//        singleTapGesture.numberOfTapsRequired = 1
//        self.TemplateBody.addGestureRecognizer(singleTapGesture)

//        // ドラッグジェスチャ
//        let panGesture = UIPanGestureRecognizer(target: self, action:#selector(panAction(_:)))
//        self.TemplateBody.addGestureRecognizer(panGesture)
        
        // 現在のtransfromを保存
//        print("first (x,y) : (\(TemplateBody.center.x), \(TemplateBody.center.y))")
//        print("first (width, height) : (\(TemplateBody.frame.size.width), \(TemplateBody.frame.size.height))")
        self.defaultXPoint = TemplateBody.center.x
        self.defaultYPoint = TemplateBody.center.y
        self.defaultWidth  = TemplateBody.frame.size.width
        self.defaultHeight = TemplateBody.frame.size.height
        // viewに追加
        self.addSubview(view)

        print("defaultXPoint : \(TemplateBody.center.x)")
        print("defaultYPoint : \(TemplateBody.center.y)")

        print("first (width, height) : (\(TemplateBody.frame.size.width), \(TemplateBody.frame.size.height)) x\(TemplateBody.frame.size.width / self.defaultWidth) x\(TemplateBody.frame.size.height / self.defaultHeight) scale:\(currentScale)")
    }
    
    // *************************************************** //
    // *************************************************** //
    // ピンチイン・アウト　ドラッグ関連
    // *************************************************** //
    // *************************************************** //
    
    //
    var currentScale:CGFloat = 1
    
    var defaultXPoint:CGFloat = 0
    var defaultYPoint:CGFloat = 0
    var defaultWidth:CGFloat = 0
    var defaultHeight:CGFloat = 0
    
    func setDefaultHeight(height : CGFloat){
        self.defaultHeight = height
    }

    // Pinch
    @objc func pinchAction(_ gesture: UIPinchGestureRecognizer ){
        
        ////前回の拡大縮小も含めて初期値からの拡大縮小比率を計算
        let scale = gesture.scale - 1 + currentScale
        
        let maxScale: CGFloat = 3.0
        let minScale: CGFloat = 0.8
        
        // 縮小はしない
        var rate = scale < minScale ? minScale : scale
        
        UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
            //拡大縮小の反映
            self.TemplateBody.transform = CGAffineTransform(scaleX: rate , y: rate )
        }, completion: nil)

        if(gesture.state == .ended) {

            if(rate < 1){
                rate = 1
                UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
                    //拡大縮小の反映
                    self.TemplateBody.transform = CGAffineTransform(scaleX: rate , y: rate )
                }, completion: nil)
            }
            else if(rate > maxScale){
                rate = maxScale
                UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
                    //拡大縮小の反映
                    self.TemplateBody.transform = CGAffineTransform(scaleX: rate , y: rate )
                }, completion: nil)
//                print("(x,y) : (\(TemplateBody.center.x), \(TemplateBody.center.y))")
            }
            //終了時に拡大・縮小率を保存しておいて次回に使いまわす
            currentScale = rate
        }
        
//        print("(width, height) : (\(TemplateBody.frame.size.width), \(TemplateBody.frame.size.height)) x\(TemplateBody.frame.size.width / self.defaultWidth) x\(TemplateBody.frame.size.height / self.defaultHeight) scale:\(currentScale)")

    }
      
    @objc func singleTapAction(_ gesture: UITapGestureRecognizer ){
        
//        print("(x,y) : (\(TemplateBody.center.x), \(TemplateBody.center.y))")
//        print("(width, height) : (\(TemplateBody.frame.size.width), \(TemplateBody.frame.size.height)) x\(TemplateBody.frame.size.width / self.defaultWidth) x\(TemplateBody.frame.size.height / self.defaultHeight) scale:\(currentScale)")

    }
    // 元のサイズに戻す
    @objc func doubleTapAction(_ gesture: UITapGestureRecognizer ){

        print("before defaultXPoint : \(TemplateBody.center.x)")
        print("before defaultYPoint : \(TemplateBody.center.y)")
        
        
        // 補正
        if(self.defaultXPoint != TemplateBody.center.x){
            self.defaultXPoint = TemplateBody.center.x
        }

        if(self.defaultYPoint != TemplateBody.center.y){
            self.defaultYPoint = TemplateBody.center.y
        }

        // 等倍
        let rate: CGFloat = 1
        
        UIView.animate(withDuration: 0.3, delay: 0.0, animations: {
            //拡大縮小の反映
            //self.TemplateBody.frame.size.height = self.defaultHeight
            self.TemplateBody.transform = CGAffineTransform(scaleX: rate , y: rate )
            self.TemplateBody.center = CGPoint(x: self.defaultXPoint, y: 374)
        }, completion: nil)

        if(gesture.state == .ended) {
            //終了時に拡大・縮小率を保存しておいて次回に使いまわす
            currentScale = rate
        }
        
        print("after defaultXPoint : \(TemplateBody.center.x)")
        print("after defaultYPoint : \(TemplateBody.center.y)")

        
        print("after (width, height) : (\(TemplateBody.frame.size.width), \(TemplateBody.frame.size.height)) x\(TemplateBody.frame.size.width / self.defaultWidth) x\(TemplateBody.frame.size.height / self.defaultHeight) scale:\(currentScale)")

    }
    
    // ドラッグ
    @objc func panAction(_ gesture: UIPanGestureRecognizer) {

        // 現在のtransfromを保存
        let transform = TemplateBody.transform

//        print("(x,y) : (\(TemplateBody.center.x), \(TemplateBody.center.y))")
        // transformを初期値に戻す
        // これを入れないと、拡大時のドラッグの移動量が少なくなってしまう
        TemplateBody.transform = CGAffineTransform.identity

        // 画像をドラッグした量だけ動かす
        let point: CGPoint = gesture.translation(in: TemplateBody)
        
        var nextXPoint = TemplateBody.center.x + point.x
        var nextYPoint = TemplateBody.center.y + point.y
        
        // 画面外に出ないように調整
        let XMargin = (self.currentScale * self.defaultWidth - self.defaultWidth) / 2
        let YMargin = (self.currentScale * self.defaultHeight - self.defaultHeight) / 2

        if(nextXPoint < defaultXPoint - XMargin){
            nextXPoint = defaultXPoint - XMargin
        }
        else if(nextXPoint > defaultXPoint + XMargin){
            nextXPoint = defaultXPoint + XMargin
        }

        if(nextYPoint < defaultYPoint - YMargin){
            nextYPoint = defaultYPoint - YMargin
        }
        else if(nextYPoint > defaultYPoint + YMargin){
            nextYPoint = defaultYPoint + YMargin
        }

        let movedPoint = CGPoint(x: nextXPoint,
                                 y: nextYPoint)
        TemplateBody.center = movedPoint

        // 保存しておいたtransformに戻す
        TemplateBody.transform = transform

        // ドラッグで移動した距離をリセット
        gesture.setTranslation(CGPoint.zero, in: TemplateBody)

    }


}
