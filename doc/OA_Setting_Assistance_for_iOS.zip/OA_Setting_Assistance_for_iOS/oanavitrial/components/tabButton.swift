import UIKit
import WebKit

class tabButton: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {

    @IBOutlet var Body: UIView!
    @IBOutlet weak var tabImage: UIImageView!
    @IBOutlet weak var tabText: UILabel!
    @IBOutlet weak var topMargin: UIView!
    @IBOutlet weak var middleMargin: UIView!
    @IBOutlet weak var bottomMargin: UIView!
    
    var bkColorHex = "42CCB3"
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
                
        guard let view = UINib(nibName: "tabButton", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]
        
        self.tabText.adjustsFontSizeToFitWidth = true
        
        self.tabImage.image = UIImage(named: "open_window")

        self.Body.backgroundColor = UIColor(hex: bkColorHex)
        self.tabImage.backgroundColor = UIColor(hex: bkColorHex)
        self.tabText.backgroundColor = UIColor(hex: bkColorHex)
        self.topMargin.backgroundColor = UIColor(hex: bkColorHex)
        self.middleMargin.backgroundColor = UIColor(hex: bkColorHex)
        self.bottomMargin.backgroundColor = UIColor(hex: bkColorHex)
        
        // define of tapping action
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickBody), button: self.Body)
        
        // viewに追加
        self.addSubview(view)
        
    }
    
    
    @objc func didClickBody(gesture: UILongPressGestureRecognizer){
        
        // handle touch down and touch up events separately
        if gesture.state == .began {
        }
        else if gesture.state == .ended { // optional for touch up event catching
            print("click")
        }
        
    }
    
    // ラベルテキスト設定
    func setTabImage(imageName: String){
        self.tabImage.image = UIImage(named: imageName)
    }
    
    // ラベルテキスト設定
    func setTabText(text: String){
        self.tabText.text = text
    }

}

extension UIColor {
    convenience init(hex: String, alpha: CGFloat = 1.0) {
        let v = Int("000000" + hex, radix: 16) ?? 0
        let r = CGFloat(v / Int(powf(256, 2)) % 256) / 255
        let g = CGFloat(v / Int(powf(256, 1)) % 256) / 255
        let b = CGFloat(v / Int(powf(256, 0)) % 256) / 255
        self.init(red: r, green: g, blue: b, alpha: min(max(alpha, 0), 1))
    }
}
