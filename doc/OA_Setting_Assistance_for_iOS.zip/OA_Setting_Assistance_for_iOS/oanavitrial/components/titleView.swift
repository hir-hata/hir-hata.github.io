import UIKit
import WebKit

class titleView:  UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {


    @IBOutlet weak var Hr: UIView!
    @IBOutlet weak var TitleLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
                
        guard let view = UINib(nibName: "titleView", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]
        
        self.Hr.backgroundColor = commonFunc.deepGreen
        self.TitleLabel.adjustsFontSizeToFitWidth = true
        // viewに追加
        self.addSubview(view)
        
    }
    
    func setTitle(text : String){
        self.TitleLabel.text = text
    }
}
