import UIKit
import WebKit

class scrollContent: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {

    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var TextView: UITextView!
    @IBOutlet weak var ImageView: UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
                
        guard let view = UINib(nibName: "scrollContent", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]

        // viewに追加
        self.addSubview(view)
        
    }
    
    func setText(text : String){
        TextView.text = text
    }
    
    func setImage(imageName : String){
        self.ImageView.image     = UIImage(named: imageName)
    }
    
    func setBackgroundColor(hex :String){
        ScrollView.backgroundColor = UIColor(hex: hex)
    }
    
}
