import UIKit
import WebKit

class scrollContentHorizontal: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    fileprivate func commonInit() {
                
        guard let view = UINib(nibName: "scrollContentHorizontal", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]

        // viewに追加
        self.addSubview(view)
        
    }

}
