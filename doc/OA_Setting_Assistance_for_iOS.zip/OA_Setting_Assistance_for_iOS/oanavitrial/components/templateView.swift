import UIKit
import WebKit

class templateView: UIView, WKNavigationDelegate, WKUIDelegate, UITextViewDelegate {

    @IBOutlet weak var contentsView     : UIView!
    
    @IBOutlet weak var headerView       : UIView!
    @IBOutlet weak var homeIcon         : UIImageView!
    @IBOutlet weak var explanationIcon  : UIImageView!
    @IBOutlet weak var headerLabel      : UILabel!
    
    @IBOutlet weak var titleView        : UIView!
    @IBOutlet weak var markIcon         : UILabel!
    @IBOutlet weak var titleFooterLine  : UIView!
    @IBOutlet weak var titleLabel       : UILabel!
    @IBOutlet weak var rightIconLabel   : UILabel!
    

    @IBOutlet weak var imageView        : UIImageView!
    @IBOutlet weak var hyperLinkTextView: UITextView!
    
    @IBOutlet weak var footerView       : UIView!
    @IBOutlet weak var backButtonView   : UIView!
    @IBOutlet weak var backLabel        : UILabel!
    @IBOutlet weak var funcButtonView   : UIView!
    @IBOutlet weak var funcLabel        : UILabel!
    @IBOutlet weak var nextButtonView   : UIView!
    @IBOutlet weak var nextLabel        : UILabel!
    
    @IBOutlet weak var navView          : UIView!
    @IBOutlet weak var imgView          : UIView!
    @IBOutlet weak var imgUnderLineView : UIView!
    @IBOutlet weak var iconCoverView    : UIView!
    @IBOutlet weak var imgIcon          : UIImageView!
    @IBOutlet weak var navMessageLabel  : UILabel!
    @IBOutlet weak var navFooterView    : UIView!
    @IBOutlet weak var navBackView      : UIView!
    @IBOutlet weak var navFunctionView  : UIView!
    
    
    @IBOutlet weak var navBackButtonView    : UIView!
    @IBOutlet weak var navFuncButtonView    : UIView!
    @IBOutlet weak var navFuncButton2View   : UIView!
    @IBOutlet weak var navFuncButton3View   : UIView!
    @IBOutlet weak var navNextButtonView    : UIView!
    
    @IBOutlet weak var navBackLabel     : UILabel!
    @IBOutlet weak var navFuncLabel     : UILabel!
    @IBOutlet weak var navFuncLabel2    : UILabel!
    @IBOutlet weak var navFuncLabel3    : UILabel!
    @IBOutlet weak var navNextLabel     : UILabel!
    
    @IBOutlet weak var frontFooterView  : UIView!
    
    // remove "weak" option to change status
    @IBOutlet var constraintHeaderHeight    : NSLayoutConstraint!
    
    @IBOutlet var constraintTitleHeight     : NSLayoutConstraint!
    @IBOutlet var constraintTitleTop        : NSLayoutConstraint!
    @IBOutlet var constraintTitleBottom     : NSLayoutConstraint!
    
    @IBOutlet var constraintContentsHeight  : NSLayoutConstraint!
    @IBOutlet var constraintFooterHeight    : NSLayoutConstraint!
    
    @IBOutlet var constraintNavOpenHeight   : NSLayoutConstraint!
    @IBOutlet var constraintCloseHeight     : NSLayoutConstraint!
    @IBOutlet var constraintMinHeight       : NSLayoutConstraint!
    
    @IBOutlet var constraintNavFooterHeight : NSLayoutConstraint!
    
    @IBOutlet var constraintNavBackButtonViewBottom : NSLayoutConstraint!
    @IBOutlet var constraintNavFuncButtonViewBottom : NSLayoutConstraint!
    @IBOutlet var constraintNavNextButtonViewBottom : NSLayoutConstraint!
    
    
    @IBOutlet var constraintImageViewBottomToMessage: NSLayoutConstraint!
    @IBOutlet var constraintImageViewBottomToFooter : NSLayoutConstraint!
    
    @IBOutlet var constraintHyperLinkTextBottomToImage      : NSLayoutConstraint!
    @IBOutlet var constraintHyperLinkTextBottomToFooter     : NSLayoutConstraint!
    @IBOutlet var constraintHyperLinkTextBottomToSuperView  : NSLayoutConstraint!
    
    @IBOutlet var constraintImageBottomToFooter             : NSLayoutConstraint!
    @IBOutlet var constraintImageBottomToSuperView          : NSLayoutConstraint!

    @IBOutlet var constraintFooterBottomToSuperView         : NSLayoutConstraint!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    var navTextFlg : Bool = false
    
    fileprivate func commonInit() {
        
        guard let view = UINib(nibName: "templateView", bundle: nil).instantiate(withOwner: self, options: nil).first as? UIView else {
            return
        }

        view.frame = self.bounds
        
        // flexible
        view.autoresizingMask   = [.flexibleHeight, .flexibleWidth]
        
        // initial setting
        self.hideContentsView(bool: false)
        self.hideImageView(bool: true)
        self.hideFooterView(bool: false)
        self.hideNavView(bool: true)
        self.hideRightIconLabel(bool: true)

        // color
        self.contentsView.backgroundColor       = commonFunc.white
        self.headerView.backgroundColor         = commonFunc.deepGreen
        self.headerLabel.textColor              = commonFunc.white
        self.imgView.backgroundColor            = commonFunc.clear
        self.imgIcon.backgroundColor            = commonFunc.white
        self.iconCoverView.backgroundColor      = commonFunc.brightLime.withAlphaComponent(0.5)
        self.imgUnderLineView.backgroundColor   = commonFunc.brightLime.withAlphaComponent(0.5)
        self.navView.backgroundColor            = commonFunc.clear
        self.navBackView.backgroundColor        = commonFunc.brightLime.withAlphaComponent(0.5)
        self.navMessageLabel.backgroundColor    = commonFunc.deepBlue
        self.titleFooterLine.backgroundColor    = commonFunc.deepGreen
        self.titleLabel.backgroundColor         = commonFunc.white
        self.hyperLinkTextView.backgroundColor  = commonFunc.white
        self.navFooterView.backgroundColor      = commonFunc.clear
        self.navBackButtonView.backgroundColor  = commonFunc.clear
        self.navFuncButtonView.backgroundColor  = commonFunc.clear
        self.navFuncButton2View.backgroundColor = commonFunc.clear
        self.navFuncButton3View.backgroundColor = commonFunc.clear
        self.navNextButtonView.backgroundColor  = commonFunc.clear
        self.navBackLabel.backgroundColor       = commonFunc.deepGreen
        self.navFuncLabel.backgroundColor       = commonFunc.brightYellow
        self.navFuncLabel2.backgroundColor      = commonFunc.brightYellow
        self.navFuncLabel3.backgroundColor      = commonFunc.brightYellow
        self.navNextLabel.backgroundColor       = commonFunc.deepGreen
        self.backButtonView.backgroundColor     = commonFunc.clear
        self.funcButtonView.backgroundColor     = commonFunc.clear
        self.nextButtonView.backgroundColor     = commonFunc.clear
        self.backLabel.backgroundColor          = commonFunc.deepGreen
        self.funcLabel.backgroundColor          = commonFunc.brightYellow
        self.nextLabel.backgroundColor          = commonFunc.deepGreen
        self.rightIconLabel.backgroundColor     = commonFunc.deepPink
        self.frontFooterView.backgroundColor    = commonFunc.deepGreen

        // style
        self.navBackLabel.clipsToBounds         = true
        
//        self.navBackButtonView.layer.cornerRadius = view.frame.height / 50
//        self.navBackButtonView.layer.maskedCorners   = [.layerMinXMaxYCorner, .layerMinXMinYCorner]
        
        self.navFuncLabel.clipsToBounds         = true
        self.navFuncLabel.layer.cornerRadius    = view.frame.height / 50
        self.navFuncLabel.layer.maskedCorners   = [.layerMinXMaxYCorner, .layerMaxXMinYCorner]
        
        self.navFuncLabel2.clipsToBounds        = true
        self.navFuncLabel2.layer.cornerRadius   = view.frame.height / 50
        self.navFuncLabel2.layer.maskedCorners  = [.layerMinXMaxYCorner, .layerMaxXMinYCorner]
        
        self.navFuncLabel3.clipsToBounds        = true
        self.navFuncLabel3.layer.cornerRadius   = view.frame.height / 50
        self.navFuncLabel3.layer.maskedCorners  = [.layerMinXMaxYCorner, .layerMaxXMinYCorner]
        
        self.navNextLabel.clipsToBounds             = true
        
//        self.navNextButtonView.layer.cornerRadius   = view.frame.height / 50
//        self.navNextButtonView.layer.maskedCorners  = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner]

        self.backLabel.clipsToBounds            = true
        self.backLabel.layer.cornerRadius       = 10
        self.funcLabel.clipsToBounds            = true
        self.funcLabel.layer.cornerRadius       = 10
        self.nextLabel.clipsToBounds            = true
        self.nextLabel.layer.cornerRadius       = 10

        self.rightIconLabel.clipsToBounds       = true
        self.rightIconLabel.layer.cornerRadius  = self.rightIconLabel.frame.height / 2
        
        self.iconCoverView.layer.maskedCorners  = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        self.iconCoverView.layer.cornerRadius   = 10

        // title mark icon setting
        self.markIcon.layer.borderWidth         = 8
        self.markIcon.layer.borderColor         = commonFunc.deepGreen.cgColor
        self.markIcon.backgroundColor           = commonFunc.white

        // nav message label setting
        self.navMessageLabel.numberOfLines      = 0
        self.navMessageLabel.sizeToFit()
        
        // link text setting
        self.hyperLinkTextView.isSelectable     = true
        self.hyperLinkTextView.isEditable       = false
        self.hyperLinkTextView.isUserInteractionEnabled = false
        self.hyperLinkTextView.delegate         = self
        
        // set shadow
        self.backButtonView.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.backButtonView.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.backButtonView.layer.shadowRadius  = 3
        self.showBackButtonShadow()

        self.funcButtonView.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.funcButtonView.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.funcButtonView.layer.shadowRadius  = 3
        self.showFuncButtonShadow()

        self.nextButtonView.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.nextButtonView.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.nextButtonView.layer.shadowRadius  = 3
        self.showNextButtonShadow()

        self.navBackButtonView.backgroundColor      = commonFunc.deepGreen
        self.navBackButtonView.layer.shadowColor    = commonFunc.deepBlack.cgColor
        self.navBackButtonView.layer.shadowOffset   = CGSize(width: 3, height: 5)
        self.navBackButtonView.layer.shadowRadius   = 3
        self.showNavBackButtonShadow()

        self.navFuncButtonView.layer.shadowColor    = commonFunc.deepBlack.cgColor
        self.navFuncButtonView.layer.shadowOffset   = CGSize(width: 3, height: 5)
        self.navFuncButtonView.layer.shadowRadius   = 3
        self.showNavFuncButtonShadow()
        
        self.navFuncButton2View.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.navFuncButton2View.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.navFuncButton2View.layer.shadowRadius  = 3
        self.showNavFuncButtonShadow()
        
        self.navFuncButton3View.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.navFuncButton3View.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.navFuncButton3View.layer.shadowRadius  = 3
        self.showNavFuncButtonShadow()

        self.navNextButtonView.backgroundColor      = commonFunc.deepGreen
        self.navNextButtonView.layer.shadowColor    = commonFunc.deepBlack.cgColor
        self.navNextButtonView.layer.shadowOffset   = CGSize(width: 3, height: 5)
        self.navNextButtonView.layer.shadowRadius   = 3
        self.showNavNextButtonShadow()

        // define of tapping action
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickImg), button: self.imgView)
        
        self.hyperLinkTextView.isScrollEnabled  = false
        
        self.constraintContentsHeight.constant  = UIScreen.main.bounds.size.height
        
        //self.hideExplanationIcon(bool: true)
        
        self.addSubview(view)

    }

    // hide bottom nav
    func hideNavView(bool : Bool){
        self.navView.isHidden       = bool
    }
    
    // hide bottom nav
    func hideImageView(bool : Bool){
        self.imageView.isHidden     = bool
    }

    // hide nav
    func hideContentsView(bool : Bool){
        self.contentsView.isHidden  = bool
    }
    
    // hide footer
    func hideFooterView(bool : Bool){
        self.footerView.isHidden    = bool
    }
    
    // hide home icon
    func hideHomeIcon(bool : Bool){
        self.homeIcon.isHidden = bool
    }

    // hide explanation icon
    func hideExplanationIcon(bool : Bool){
        self.explanationIcon.isHidden = bool
    }

    // set title text
    func setHeaderText(str:String){
        self.headerLabel.text       = str
    }

    // set title text
    func setTitle(str:String){
        self.titleLabel.text        = str
    }
    
    // set menu label text
    func setNavMessageText(str:String){
        self.navMessageLabel.text   = str
    }
    
    // hide nav message
    func hideNavMessageLabel(bool:Bool){
        self.navMessageLabel.isHidden = bool
    }
    
    // set link text
    func setLinkText(str: NSMutableAttributedString){
        self.hyperLinkTextView.attributedText = str
        self.hyperLinkTextView.layoutIfNeeded()
        self.hyperLinkTextView.sizeToFit()
    }
    
    // set menu label text
    func setNavBackText(str:String){
        self.navBackLabel.text      = str
    }

    // set menu label text
    func setNavFuncText(str:String){
        self.navFuncLabel.text      = str
    }

    // set next action label text
    func setNavNextText(str:String){
        self.navNextLabel.text      = str
    }
    
    // hide back button
    func hideBackButton(bool:Bool){
        self.backButtonView.isHidden    = bool
    }
    
    // hide func button
    func hideFuncButton(bool:Bool){
        self.funcButtonView.isHidden    = bool
    }

    // hide next button
    func hideNextButton(bool:Bool){
        self.nextButtonView.isHidden    = bool
    }
    
    // hide back button
    func hideNavBackButton(bool:Bool){
        self.navBackButtonView.isHidden = bool
    }
    
    // hide func button
    func hideNavFuncButton(bool:Bool){
        self.navFuncButtonView.isHidden = bool
    }
    
    // hide next button
    func hideNavNextButton(bool:Bool){
        self.navNextButtonView.isHidden = bool
    }

    // hide next button
    func hideRightIconLabel(bool:Bool){
        self.rightIconLabel.isHidden = bool
    }

    // hide frontFooter
    func hideFrontFooterView(bool:Bool){
        self.frontFooterView.isHidden = bool
    }
    
    // set back Label text
    func setBackLabelText(str:String){
        self.backLabel.text         = str
    }

    // set back Label text
    func setFuncLabelText(str:String){
        self.funcLabel.text         = str
    }

    // set next Label text
    func setNextLabelText(str:String){
        self.nextLabel.text         = str
    }
    
    // set next Label text
    func setImage(str:String){
        self.imageView.image        = UIImage(named: str)
    }

    func showBackButtonShadow(){
        self.backButtonView.layer.shadowOpacity  = 0.6
    }
    
    func hideBackButtonShadow(){
        self.backButtonView.layer.shadowOpacity  = 0
    }

    func showFuncButtonShadow(){
        self.funcButtonView.layer.shadowOpacity  = 0.6
    }
    
    func hideFuncButtonShadow(){
        self.funcButtonView.layer.shadowOpacity  = 0
    }

    func showNextButtonShadow(){
        self.nextButtonView.layer.shadowOpacity  = 0.6
    }
    
    func hideNextButtonShadow(){
        self.nextButtonView.layer.shadowOpacity  = 0
    }

    func showNavBackButtonShadow(){
        self.navBackButtonView.layer.shadowOpacity  = 0.6
    }
    
    func hideNavBackButtonShadow(){
        self.navBackButtonView.layer.shadowOpacity  = 0
    }
    
    func showNavFuncButtonShadow(){
        self.navFuncButtonView.layer.shadowOpacity  = 0.6
        self.navFuncButton2View.layer.shadowOpacity = 0.6
        self.navFuncButton3View.layer.shadowOpacity = 0.6
    }
    
    func hideNavFuncButtonShadow(){
        self.navFuncButtonView.layer.shadowOpacity  = 0
        self.navFuncButton2View.layer.shadowOpacity = 0
        self.navFuncButton3View.layer.shadowOpacity = 0
    }
    
    func showNavNextButtonShadow(){
        self.navNextButtonView.layer.shadowOpacity  = 0.6
    }
    
    func hideNavNextButtonShadow(){
        self.navNextButtonView.layer.shadowOpacity  = 0
    }
    
    func setHeaderHeight(height:CGFloat){
        self.constraintHeaderHeight.constant     = height
    }

    func setTitleHeight(height:CGFloat){
        self.constraintTitleHeight.constant      = height
    }

    func setContentsHeight(height:CGFloat){
        self.constraintContentsHeight.constant   = height
    }

    func setFooterHeight(height:CGFloat){
        self.constraintFooterHeight.constant     = height
    }

    func setNavFooterHeight(height:CGFloat){
        self.constraintNavFooterHeight.constant  = height
    }

//    func setNavOpenHeight(height:CGFloat){
//        self.constraintNavOpenHeight.constant  = height + self.constraintCloseHeight.constant + 25
//    }

    func setNavOpenHeight(){
        self.constraintNavOpenHeight.constant = self.constraintNavOpenHeight.constant + 70
    }

    func calcContentsHeight(){
        
        var contentsHeight: CGFloat = 0

        print("top margin of title : \(self.constraintTitleTop.constant)")
        contentsHeight += self.constraintTitleTop.constant

        print("height of title : \(self.constraintTitleHeight.constant)")
        contentsHeight += self.constraintTitleHeight.constant

        print("bottom margin of title : \(self.constraintTitleBottom.constant)")
        contentsHeight += self.constraintTitleBottom.constant

        print("aaaaaa : \(self.hyperLinkTextView.frame)")

        print("height of hyperLinkTextView : \(hyperLinkTextView.frame.height)")
        contentsHeight += self.hyperLinkTextView.frame.height
        
        if(constraintHyperLinkTextBottomToImage.isActive){
            print("bottom margin of hyperLinkTextView to imageView : \(constraintHyperLinkTextBottomToImage.constant)")
            contentsHeight += constraintHyperLinkTextBottomToImage.constant
        }

        if(self.constraintHyperLinkTextBottomToFooter.isActive){
            print("bottom margin of hyperLinkTextView to footerView : \(constraintHyperLinkTextBottomToFooter.constant)")
            contentsHeight += constraintHyperLinkTextBottomToFooter.constant
        }
        
        if(self.constraintHyperLinkTextBottomToSuperView.isActive){
            print("bottom margin of hyperLinkTextView : \(constraintHyperLinkTextBottomToSuperView.constant)")
            contentsHeight += constraintHyperLinkTextBottomToSuperView.constant
        }
        
        if(self.constraintImageBottomToFooter.isActive){
            print("bottom margin of image to footerView : \(constraintImageBottomToFooter.constant)")
            contentsHeight += constraintImageBottomToFooter.constant
        }
        
        if(self.constraintImageBottomToSuperView.isActive){
            print("bottom margin of imageView : \(constraintImageBottomToSuperView.constant)")
           contentsHeight += constraintImageBottomToSuperView.constant
        }
        
        if(self.constraintFooterBottomToSuperView.isActive){
            print("bottom margin of footerView : \(constraintFooterBottomToSuperView.constant)")
            contentsHeight += constraintFooterBottomToSuperView.constant
        }

        if(!self.imageView.isHidden){
            print("height of imageView : \(self.imageView.image!.size.height)")
            contentsHeight += self.imageView.image!.size.height
        }

        if(!self.footerView.isHidden){
            print("height of footerView : \(self.constraintFooterHeight.constant)")
            contentsHeight += self.constraintFooterHeight.constant
        }
                
        print("height of contents : \(contentsHeight)")
        self.constraintContentsHeight.constant  = contentsHeight
        
    }
    
    
    func checkStyle(){
        
        print("imageView.isHidden : \(self.imageView.isHidden)")
        print("footerView.isHidden : \(self.footerView.isHidden)")
        print("navView.isHidden : \(self.navView.isHidden)")

        // image:hide, footer:hide
        if(self.imageView.isHidden && self.footerView.isHidden){
            print("[checkStyle] image:hide, footer:hide")
            self.constraintHyperLinkTextBottomToImage.isActive      = false
            self.constraintHyperLinkTextBottomToFooter.isActive     = false
            self.constraintHyperLinkTextBottomToSuperView.isActive  = true
            self.constraintImageBottomToFooter.isActive             = false
            self.constraintImageBottomToSuperView.isActive          = false
            self.constraintFooterBottomToSuperView.isActive         = false
        }
        // image:show, footer:show
        else if(!self.imageView.isHidden && !self.footerView.isHidden){
            print("[checkStyle] image:show, footer:show")
            self.constraintHyperLinkTextBottomToImage.isActive      = true
            self.constraintHyperLinkTextBottomToFooter.isActive     = false
            self.constraintHyperLinkTextBottomToSuperView.isActive  = false
            self.constraintImageBottomToFooter.isActive             = true
            self.constraintImageBottomToSuperView.isActive          = false
            self.constraintFooterBottomToSuperView.isActive         = true
        }
        // image:hide, footer:show
        else if(self.imageView.isHidden){
            if(!self.footerView.isHidden){
                print("[checkStyle] image:hide, footer:show")
                self.constraintHyperLinkTextBottomToImage.isActive      = false
                self.constraintHyperLinkTextBottomToFooter.isActive     = true
                self.constraintHyperLinkTextBottomToSuperView.isActive  = false
                self.constraintImageBottomToFooter.isActive             = false
                self.constraintImageBottomToSuperView.isActive          = false
                self.constraintFooterBottomToSuperView.isActive         = true
            }
        }
        // image:show, footer:hide
        else if(!self.imageView.isHidden){
            
            if(self.footerView.isHidden){
                print("[checkStyle] image:show, footer:hide")
                self.constraintHyperLinkTextBottomToImage.isActive      = true
                self.constraintHyperLinkTextBottomToFooter.isActive     = false
                self.constraintHyperLinkTextBottomToSuperView.isActive  = false
                self.constraintImageBottomToFooter.isActive             = false
                self.constraintImageBottomToSuperView.isActive          = true
                self.constraintFooterBottomToSuperView.isActive         = false
            }
            
        }
        
        // nav view
        if(!self.navView.isHidden){
            print("[checkStyle] nav:show")
            self.openNavView()
        }
        else{
            print("[checkStyle] nav:hide")
        }
        
    }
    
    // adjust view size
    func adjustViewStyle(displayHeight:CGFloat){
        
        self.setHeaderHeight(height: displayHeight * 0.08)
        self.setTitleHeight(height: displayHeight * 0.06)
        self.setFooterHeight(height: displayHeight * 0.05)
        //self.setNavFooterHeight(height: displayHeight * 0.05)
        //self.setNavOpenHeight(height: displayHeight * 0.05)
        self.setNavOpenHeight()

        self.checkStyle()
        self.calcContentsHeight()

    }

    // open or close bottom nav when click img
    @objc func didClickImg(gesture: UILongPressGestureRecognizer){
        
        // handle touch down and touch up events separately
        if gesture.state == .began {
            
        }
        else if gesture.state == .ended { // optional for touch up event catching

            print("")
            print("constraintOpenHeight : \(self.constraintNavOpenHeight.isActive)")
            print("constraintCloseHeight : \(self.constraintCloseHeight.isActive)")
            print("constraintMinHeight : \(self.constraintMinHeight.isActive)")
            print("constraintImageViewBottomToMessage : \(self.constraintImageViewBottomToMessage.isActive)")
            print("constraintNavNextButtonViewBottom : \(self.constraintNavNextButtonViewBottom.isActive)")
//            print("constraintNavFuncButtonViewBottom : \(self.constraintNavFuncButtonViewBottom.isActive)")
            print("constraintNavBackButtonViewBottom : \(self.constraintNavBackButtonViewBottom.isActive)")
            print("OpenHeight.constant : \(self.constraintNavOpenHeight.constant)")
            print("CloseHeight.constant : \(self.constraintCloseHeight.constant)")
            print("MinHeight.constant : \(self.constraintMinHeight.constant)")


            // when nav view is opened
            if self.constraintNavOpenHeight.isActive {
                self.closeNavView()
            }
            // when nav view is closed
            else {
                self.openNavView()
            }
            
        }
        
    }

    func openNavView(){
        
        print("open nav view")
        
        self.constraintNavOpenHeight.isActive               = true
        self.constraintCloseHeight.isActive                 = false
        //self.constraintMinHeight.isActive                   = false
        self.constraintImageViewBottomToMessage.isActive    = true
        self.constraintNavBackButtonViewBottom.isActive     = true
        // self.constraintNavFuncButtonViewBottom.isActive     = true
        self.constraintNavNextButtonViewBottom.isActive     = true
        
        self.imgIcon.image                          = UIImage(named: "closeNav")
        self.navFooterView.isHidden                 = false
        self.navFunctionView.isHidden               = false
        self.navMessageLabel.isHidden               = true
        
    }

    func closeNavView(){
        
        print("close nav view")
        
        self.constraintNavOpenHeight.isActive               = false
        self.constraintImageViewBottomToMessage.isActive    = false
        self.constraintNavBackButtonViewBottom.isActive     = false
        //self.constraintNavFuncButtonViewBottom.isActive     = false
        self.constraintNavNextButtonViewBottom.isActive     = false
        
        self.imgIcon.image                          = UIImage(named: "openNav")
        self.navFooterView.isHidden                 = true
        self.navFunctionView.isHidden               = true
        self.navMessageLabel.isHidden               = true
        
        
        if self.navView.frame.height * self.constraintCloseHeight.multiplier < self.constraintMinHeight.constant {
            self.constraintCloseHeight.isActive     = false
            self.constraintMinHeight.isActive       = true
        }
        else {
            self.constraintCloseHeight.isActive     = true
            self.constraintMinHeight.isActive       = false
        }
        
    }
}

