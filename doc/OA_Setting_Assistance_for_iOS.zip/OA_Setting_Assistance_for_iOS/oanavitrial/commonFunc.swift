import UIKit
import Alamofire
import Firebase

class commonFunc:UIViewController {
    
    // singleton
    static let shared       = commonFunc()
    
    // for reading property file (.plist)
    static let plist        = shared.getPList()
    
    // color
    static let brightRed    = shared.getColor(colorName: "brightRed")
    static let brightYellow = shared.getColor(colorName: "brightYellow")
    static let brightGreen  = shared.getColor(colorName: "brightGreen")
    static let brightBlue   = shared.getColor(colorName: "brightBlue")
    static let brightPurple = shared.getColor(colorName: "brightPurple")
    static let brightPink   = shared.getColor(colorName: "brightPink")
    static let brightGray   = shared.getColor(colorName: "brightGray")
    static let brightBlack  = shared.getColor(colorName: "brightBlack")
    static let deepRed      = shared.getColor(colorName: "deepRed")
    static let deepYellow   = shared.getColor(colorName: "deepYellow")
    static let deepGreen    = shared.getColor(colorName: "deepGreen")
    static let deepBlue     = shared.getColor(colorName: "deepBlue")
    static let deepPurple   = shared.getColor(colorName: "deepPurple")
    static let deepPink     = shared.getColor(colorName: "deepPink")
    static let deepGray     = shared.getColor(colorName: "deepGray")
    static let deepBlack    = shared.getColor(colorName: "deepBlack")
    static let deepLime     = shared.getColor(colorName: "deepLime")
    static let brightLime   = shared.getColor(colorName: "brightLime")
    static let creamYellow  = shared.getColor(colorName: "creamYellow")
    static let gold         = shared.getColor(colorName: "gold")
    static let silver       = shared.getColor(colorName: "silver")
    static let bronze       = shared.getColor(colorName: "bronze")
    static let cream        = shared.getColor(colorName: "cream")
    static let white        = shared.getColor(colorName: "default")
    static let clear        = shared.getColor(colorName: "transparent")
    static let iosGray      = shared.getColor(colorName: "iosGray")
    static let iosBlue      = shared.getColor(colorName: "iosBlue")
    static let salmon       = shared.getColor(colorName: "salmon")
    static let mame         = shared.getColor(colorName: "mame")
    static let devMode      = commonFunc.plist.value(forKey: "development") as! Bool
    static let analystic    = commonFunc.plist.value(forKey: "firebaseAnalytics") as! Bool
    
    static let tfFontSize: CGFloat  = 18.0
    
    // get property list
    func getPList() -> NSDictionary{
        let constPlistFilePath = Bundle.main.path(forResource: "const", ofType: "plist")
        let plist = NSDictionary(contentsOfFile: constPlistFilePath!)!
        return plist
    }
    
    // get color
    func getColor(colorName: String) -> UIColor{


        switch colorName {
            
        case "deepGray":
            return UIColor(red: 215/255, green: 215/255, blue: 215/255, alpha: 1)
            
        case "brightGray":
            return UIColor(red: 238/255, green: 236/255, blue: 237/255, alpha: 1)
            
        case "deepBlack":
            return UIColor(red: 73/255, green: 87/255, blue: 103/255, alpha: 1)
            
        case "brightBlack":
            return UIColor(red: 123/255, green: 133/255, blue: 144/255, alpha: 1)
            
        case "deepRed":
            return UIColor(red: 240/255, green: 49/255, blue: 51/255, alpha: 1)
            
        case "brightRed":
            return UIColor(red: 245/255, green: 97/255, blue: 98/255, alpha: 1)
            
        case "deepYellow":
            return UIColor(red: 212/255, green: 170/255, blue: 0/255, alpha: 1)
            
        case "brightYellow":
            return UIColor(red: 243/255, green: 208/255, blue: 66/255, alpha: 1)
            
        case "creamYellow":
            return UIColor(red: 237/255, green: 237/255, blue: 145/255, alpha: 1)
            
        case "deepGreen":
            return UIColor(red: 66/255, green: 204/255, blue: 179/255, alpha: 1)
            
        case "brightGreen":
            return UIColor(red: 91/255, green: 198/255, blue: 190/255, alpha: 1)
            
        case "deepBlue":
            return UIColor(red: 48/255, green: 150/255, blue: 207/255, alpha: 1)
            
        case "brightBlue":
            return UIColor(red: 58/255, green: 197/255, blue: 241/255, alpha: 1)
            
        case "deepPurple":
            return UIColor(red: 102/255, green: 96/255, blue: 164/255, alpha: 1)
            
        case "brightPurple":
            return UIColor(red: 147/255, green: 112/255, blue: 219/255, alpha: 1)
            
        case "deepPink":
            return UIColor(red: 255/255, green: 105/255, blue: 180/255, alpha: 1)
            
        case "brightPink":
            return UIColor(red: 255/255, green: 183/255, blue: 192/255, alpha: 1)
            
        case "deepLime":
            return UIColor(red: 50/255, green: 205/255, blue: 50/255, alpha: 1)
            
        case "brightLime":
            return UIColor(red: 144/255, green: 238/255, blue: 144/255, alpha: 1)
            
        case "gold":
            return UIColor(red: 255/255, green: 215/255, blue: 0/255, alpha: 1)
            
        case "silver":
            return UIColor(red: 215/255, green: 215/255, blue: 215/255, alpha: 1)
            
        case "bronze":
            return UIColor(red: 167/255, green: 112/255, blue: 68/255, alpha: 1)
            
        case "cream":
            return UIColor(red: 255/255, green: 255/255, blue: 230/255, alpha: 1)
            
        case "transparent":
            return UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 0)

        case "iosGray":
            return UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1)
            
        case "iosBlue":
            return UIColor(red: 0/255, green: 123/255, blue: 255/255, alpha: 1)

        case "salmon":
            return UIColor(red: 250/255, green: 128/255, blue: 114/255, alpha: 1)

        case "mame":
            return UIColor(red: 213/255, green: 229/255, blue: 242/255, alpha: 1)

        default :
            return UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        }
        
    }
    
    // for transparent
    let alpha   : CGFloat   = 0.5
    
    func setSettingIcon(navString: String) -> NSMutableAttributedString {
        
        let attachment      = NSTextAttachment()
        attachment.image    = UIImage(named: "iosSetting")
        attachment.bounds   = CGRect(x: 0, y: -3, width: 18, height: 18)
        let attributedImage = NSMutableAttributedString(attachment: attachment)
        
        let navMessageBody  = " 設定　\n" + navString
        let navMessage      = NSMutableAttributedString(string: navMessageBody, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        // font style
        navMessage.addAttributes(
            [
                .foregroundColor: commonFunc.iosBlue,
                .backgroundColor: commonFunc.iosGray
            ],
            range: NSString(string: navMessageBody).range(of: navString)
        )
        
        attributedImage.append(navMessage)
        
        return attributedImage
        
    }
    
    func setHyperLink(url:String, linkString: String) -> NSMutableAttributedString {
        
        let attributedString    = NSMutableAttributedString(string      : linkString,
                                                            attributes  : [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]
        )

        attributedString.addAttribute(.link,
                                      value: url,
                                      range: NSString(string: linkString).range(of: linkString)
        )

        let attributedSpace     = NSMutableAttributedString(string      : " ",
                                                            attributes  : [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]
        )
        
        let attachment          = NSTextAttachment()
        attachment.image        = UIImage(named: "newWindow")
        attachment.bounds       = CGRect(x: 0, y: -3, width: 18, height: 18)

        let attributedImage     = NSMutableAttributedString(attachment: attachment)
        
        attributedString.append(attributedSpace)
        attributedString.append(attributedImage)
        
        return attributedString
        
    }
    
    func setAttention(message: String) -> NSMutableAttributedString {
        
        let attention   = NSMutableAttributedString(string: message, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        // font style
        attention.addAttributes(
            [
                .foregroundColor: commonFunc.brightRed,
                .font: UIFont.boldSystemFont(ofSize: commonFunc.tfFontSize)
            ],
            range: NSString(string: message).range(of: message)
        )
        
        return attention
        
    }

    func addBreak() -> NSMutableAttributedString {
        let newLine     = NSMutableAttributedString(string: "\n", attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        return newLine
    }

    func addNewLine() -> NSMutableAttributedString {
        let newLine     = NSMutableAttributedString(string: "\n\n", attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        return newLine
    }
    
    
    // send Log to firebase analystic
    func sendAnalysticLog(eventName:String){
        
        var logKey  = eventName
        
        // check if analystic is ON
        if commonFunc.analystic {

            if commonFunc.devMode {
                logKey  = "Dev_" + eventName
            }
            
            // Send log asynchronously
            DispatchQueue.global(qos: .default).async {
                Analytics.logEvent(logKey, parameters: nil)
                self.cp("send analystic Log: \(logKey)")
            }
            
        }
        
    }
    
    // call alamofire
    func callAlamofire(apiURL: String, apiParams: [String: Any]){
        
        // request header
        let headers: HTTPHeaders = [
            "ACCEPT": "application/json"
        ]
        
        // json post
        afSingleton.shared.getAfManager().request(apiURL, method: .post, parameters: apiParams, encoding: JSONEncoding.default, headers: headers).responseJSON() { response in
            
//            if let rst = response.result.value as? [String: Any] {
//                self.cp("[debug] response : \(rst)")
//            }
            
        }
        
    }
    
    enum logKey:    String {
        
        // topmenu
        case tutorial       = "Tutorial"
        case intro          = "Intro"
        case mdm            = "MDM"
        case gmail          = "Gmail"
        case vpn            = "VPN"
        case anySetting     = "AnySetting"
        case reset          = "Reset"
        case inquiry        = "Inquiry"
        case all            = "ALL"
        
        //
        case back           = "back"
        case function       = "func"
        case next           = "next"

        // content
        case mmsSetting     = "MMS_Setting"
        case mmsInput       = "MMS_Input"
        case mmsOpen        = "MMS_Open"
        
        case pwHint         = "PW_Hint"
        case wifiSpot       = "WiFi_Spot"
        case SafetyConfirm  = "SafetyConfirm"
        case appStore       = "AppStore"
        case hangout        = "Hangout"
        case googleCalender = "Calender"
        case smile          = "Smile"
        case survey         = "Survey"      // アンケート
        case recomApp       = "RecomApp"    // 推奨アプリ

        // action
        case tapMenu        = "TapMenu_"
        case done           = "Done_"
        case click          = "Click_"
        case first          = "First_"
        
    }
    
}

// local user default class
class myUserDefault {
    
    let userDefaults = UserDefaults.standard
    
    // singleton
    static let shared = myUserDefault()
    
    // initialize
    init() {
        // default value
        userDefaults.register(defaults: [
            "tutorial"          : false,
            "reload"            : false,
            "enableNino"        : false,
            "enableMdm"         : false,
            "enableGmail"       : false,
            "enableVpn"         : false,
            "enableAnySetting"  : false,
            "allDone"           : false,
            "gmailAddress"      : "",
            "firstLaunch"       : true
       ])
    }
    
    // set value (string)
    func set(key:String, value:Any){
        userDefaults.set(value, forKey: key)
        userDefaults.synchronize()
    }
    
    // set value (bool)
    func setBool(key:String, value:Bool){
        userDefaults.set(value, forKey: key)
        userDefaults.synchronize()
    }
    
    // get value (string)
    func get(key:String) -> String{
        return userDefaults.string(forKey: key)!
    }
    
    // get value (Int)
    func getInt(key:String) -> Int{
        return userDefaults.integer(forKey: key)
    }
    
    // get value (bool)
    func getBool(key:String) -> Bool{
        return userDefaults.bool(forKey: key)
    }
    
}

extension UITextField {
    
    func useUnderLine() {
        
        superview?.backgroundColor = .clear
        
        let view = superview?.superview
        view?.subviews.first?.alpha = 0
        view?.backgroundColor = .clear
        
    }
    
}

// alamofire manager singleton
final class afSingleton {
    
    private var afManager = Alamofire.Session()
    
    private init() {
        
        self.afManager  = Alamofire.Session(configuration: URLSessionConfiguration.default)
        
    }
    
    func getAfManager() -> Session {
        return self.afManager
    }
    
    // singleton
    static let shared = afSingleton()
    
}
