import UIKit
import Firebase

class topViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UINavigationControllerDelegate {
    
    @IBOutlet weak var header           : UIView!
    @IBOutlet weak var headerLabel      : UILabel!
    @IBOutlet weak var footer           : UILabel!
    @IBOutlet weak var tableView        : UITableView!
    @IBOutlet weak var titleView        : UIView!
    @IBOutlet weak var titleLabel       : UILabel!
    @IBOutlet weak var resetView        : UIView!
    @IBOutlet weak var resetLabel       : UILabel!
    @IBOutlet weak var resetBackLabel   : UILabel!
    @IBOutlet weak var progressView     : UIView!
    @IBOutlet weak var unitImg          : UIImageView!
    @IBOutlet weak var oRankImg         : UIImageView!
    @IBOutlet weak var tRankImg         : UIImageView!
    @IBOutlet weak var hRankImg         : UIImageView!
    @IBOutlet weak var versionLabel     : UILabel!
    
    var progressBar     : UIView!
    
    var tableData:[indexRecord]    = []
    var selectChapter   = 0
    
    let tutorialTitle   = commonFunc.plist.value(forKeyPath: "title.tutorial") as! String
    let introTitle      = commonFunc.plist.value(forKeyPath: "title.intro") as! String
    let mdmTitle        = commonFunc.plist.value(forKeyPath: "title.mdm") as! String
    let gmailTitle      = commonFunc.plist.value(forKeyPath: "title.gmail") as! String
    let vpnTitle        = commonFunc.plist.value(forKeyPath: "title.vpn") as! String
    let anySettingTitle = commonFunc.plist.value(forKeyPath: "title.anySetting") as! String

    override func viewDidLoad() {
        
        super.viewDidLoad()
                
        // set data
        tableData    = [

            indexRecord(title   : self.tutorialTitle,
                        segue   : "toTutorialSegue",
                        url     : "",
                        enable  : true,
                        check   : true
            ),
            indexRecord(title   : self.introTitle,
                        segue   : "toCoverViewSegue",
                        url     : "",
                        enable  : true,
                        check   : myUserDefault.shared.getBool(key: "enableMdm")
            ),
            indexRecord(title   : self.mdmTitle,
                        segue   : "toCoverViewSegue",
                        url     : "",
                        enable  : myUserDefault.shared.getBool(key: "enableMdm"),
                        check   : myUserDefault.shared.getBool(key: "enableGmail")
            ),
            indexRecord(title   : self.gmailTitle,
                        segue   : "toCoverViewSegue",
                        url     : "",
                        enable  : myUserDefault.shared.getBool(key: "enableGmail"),
                        check   : myUserDefault.shared.getBool(key: "enableVpn")
            ),
            indexRecord(title   : self.vpnTitle,
                        segue   : "toCoverViewSegue",
                        url     : "",
                        enable  : myUserDefault.shared.getBool(key: "enableVpn"),
                        check   : myUserDefault.shared.getBool(key: "enableAnySetting")
            ),
            indexRecord(title   : self.anySettingTitle,
                        segue   : "toCoverViewSegue",
                        url     : "",
                        enable  : myUserDefault.shared.getBool(key: "enableAnySetting"),
                        check   : myUserDefault.shared.getBool(key: "allDone")
            ),
            indexRecord(title   : constLocal.reset.rawValue,
                        segue   : "",
                        url     : "",
                        enable  : true,
                        check   : true
            ),
            indexRecord(title   : constLocal.inquiry.rawValue,
                        segue   : "",
                        url     : "",
                        enable  : true,
                        check   : true
            ),
//            indexRecord(title   : "テスト用",
//                        segue   : "toCoverViewSegue",
//                        url     : "",
//                        enable  : true,
//                        check   : true
//            ),

        ]
        
        // no bound
        tableView.bounces   = true
        
        // set delegate
        self.tableView.dataSource           = self
        self.tableView.delegate             = self
        navigationController?.delegate      = self
        
        // set color
        self.header.backgroundColor         = commonFunc.deepBlack
        self.headerLabel.textColor          = commonFunc.white
        self.footer.backgroundColor         = commonFunc.deepGreen
        self.tableView.tintColor            = commonFunc.clear
        self.tableView.layer.borderColor    = commonFunc.clear.cgColor
        self.tableView.backgroundColor      = commonFunc.white
        self.tableView.separatorColor       = commonFunc.clear
        self.titleView.backgroundColor      = commonFunc.deepGreen
        self.titleLabel.backgroundColor     = commonFunc.clear
        self.resetView.backgroundColor      = commonFunc.clear
        self.resetBackLabel.backgroundColor = commonFunc.brightYellow
        self.resetLabel.backgroundColor     = commonFunc.clear
        self.resetLabel.textColor           = commonFunc.white
        self.progressView.backgroundColor   = commonFunc.brightBlack

        // hide button
        self.resetView.isHidden = true
        
        // set style
        self.resetBackLabel.clipsToBounds        = true
        self.resetBackLabel.layer.cornerRadius   = 10
        
        // set shadow
        self.resetView.layer.shadowColor   = commonFunc.deepBlack.cgColor
        self.resetView.layer.shadowOffset  = CGSize(width: 3, height: 5)
        self.resetView.layer.shadowRadius  = 3
        self.showResetButtonShadow()
        
        // set text
        self.headerLabel.text              = constLocal.title.rawValue + " (TEST Mode)"
        
        if !commonFunc.devMode {
            self.headerLabel.text          = constLocal.title.rawValue
        }
        
        self.headerLabel.sizeToFit()
        
        // z-index
        self.unitImg.layer.zPosition       = 10
        self.oRankImg.layer.zPosition      = 10
        self.tRankImg.layer.zPosition      = 10
        self.hRankImg.layer.zPosition      = 10
        
        // set version
        self.versionLabel.text = "ver " + (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String)
        //self.versionLabel.text = "ver FY20 iPhone Replace"

        // define of nav view tapping action
        self.resetView.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickResetButton), button: self.resetView)
        
        // generate progress bar
        self.progressBar                    = UIView(frame: CGRect(x: 0, y: 5, width: 0, height: self.progressView.frame.height - 10))
        self.progressBar.backgroundColor    = commonFunc.brightYellow
        self.progressView.addSubview(progressBar)
        
        // calculate progress
        let current_ratio = self.setRatio()
        //print("current ratio : \(current_ratio)")
        self.setProgress(current_ratio)

        if(current_ratio == 0){
            
            // when first launch
            if(myUserDefault.shared.getBool(key: "firstLaunch")){
                // show popup to navigate tutorial
                self.showPopup()
            }
        }
        else{
            print("current ratio nonzero")
        }
//        self.setProgress(self.setRatio())
    }
    
    @objc func didClickResetButton(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.hideResetButtonShadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.showResetButtonShadow()
            self.resetTable()
        }
        
    }

    func showPopup(){
        
        let this_title = "設定補助アプリにようこそ！"
        let this_message = """
        端末の設定を始める前に
        アプリの操作方法を学びましょう！
        """
        
        // create alert
        let alert: UIAlertController = UIAlertController(title: this_title, message: this_message, preferredStyle:  UIAlertController.Style.alert)
        
        // ok action
        let defaultAction: UIAlertAction = UIAlertAction(title: "はい", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in
            
            // change first launch flag
            myUserDefault.shared.setBool(key: "firstLaunch", value: false)
            
            // send log
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.tutorial.rawValue)

            // goto tutorial
            self.performSegue(withIdentifier: self.tableData[0].segue, sender: nil)
        })
        
        let cancelAction: UIAlertAction = UIAlertAction(title: "いいえ", style: UIAlertAction.Style.cancel, handler:{
            // ボタンが押された時の処理を書く（クロージャ実装）
            (action: UIAlertAction!) -> Void in
            // do nothing
        })
        
        // add action
        alert.addAction(defaultAction)
        alert.addAction(cancelAction)

        // show alert
        present(alert, animated: true, completion: nil)
        
    }
    
    func hideResetButtonShadow(){
        self.resetView.layer.shadowOpacity  = 0
    }
    
    func showResetButtonShadow(){
        self.resetView.layer.shadowOpacity  = 0.6
    }
    
    func resetTable(){
        
        // create alert
        let alert: UIAlertController = UIAlertController(title: constLocal.alertTitle.rawValue, message: constLocal.alertMessage.rawValue, preferredStyle:  UIAlertController.Style.alert)
        
        // ok action
        let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in

            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.reset.rawValue)

            myUserDefault.shared.setBool(key: "tutorial", value: false)
            myUserDefault.shared.setBool(key: "enableNino", value: false)
            myUserDefault.shared.setBool(key: "enableMdm", value: false)
            myUserDefault.shared.setBool(key: "enableGmail", value: false)
            myUserDefault.shared.setBool(key: "enableVpn", value: false)
            myUserDefault.shared.setBool(key: "enableAnySetting", value: false)
            myUserDefault.shared.setBool(key: "allDone", value: false)
            myUserDefault.shared.setBool(key: "firstLaunch", value: true)
            self.loadView()
            self.viewDidLoad()
        })
        
        // cancel action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in
            // do nothing
        })
        
        // add action
        alert.addAction(cancelAction)
        alert.addAction(defaultAction)

        // show alert
        present(alert, animated: true, completion: nil)
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //print(self.headerLabel.frame.height)
    }
    
    func setProgress(_ progress: CGFloat) {
        
        let fullWidth: CGFloat  = self.view.frame.width
        let newWidth            = progress * fullWidth
        
        self.progressBar.layer.maskedCorners    = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        self.progressBar.layer.zPosition        = 5
        UIView.animate(withDuration: 2.0) {
            self.progressBar.frame.size = CGSize(width: newWidth, height: self.progressBar.frame.height)
            
//            if progress < 1 {
//                self.progressBar.layer.cornerRadius     = self.progressBar.frame.height / 2
//            }
        }

    }
    
    func setRatio() -> CGFloat {
        
        var done  : CGFloat = 0
        let count : CGFloat = 5
        var ratio : CGFloat = 0

        if myUserDefault.shared.getBool(key: "enableMdm") {
            done += 1
        }
        
        if myUserDefault.shared.getBool(key: "enableGmail") {
            done += 1
        }
        
        if myUserDefault.shared.getBool(key: "enableVpn") {
            done += 1
        }
        
        if myUserDefault.shared.getBool(key: "enableAnySetting") {
            done += 1
        }
        
        if myUserDefault.shared.getBool(key: "allDone") {
            done += 1
        }
        
        ratio   = done / count
        
        // calc percent
        let number  = Int(floor((ratio) * 100))
        var oRank   = 0
        var tRank   = 0
        var hRank   = 0
        
        if number >= 100 {

            // set value
            hRank   = 1

            // set Image
            self.oRankImg.image     = UIImage(named: "number-w-" + String(oRank))
            self.tRankImg.image     = UIImage(named: "number-w-" + String(tRank))
            self.hRankImg.image     = UIImage(named: "number-w-" + String(hRank))

        }
        else{
            
            // hide hundred rank image
            self.hRankImg.isHidden  = true
            
            // set value
            oRank  = number % 10
            
            // set Image
            self.oRankImg.image     = UIImage(named: "number-w-" + String(oRank))
            
            if number < 10 {
                
                // hide ten rank image
                self.tRankImg.isHidden  = true
            }
            else {
                
                // set value
                tRank  = (number - oRank) / 10
                
                // set Image
                self.tRankImg.image     = UIImage(named: "number-w-" + String(tRank))
            }
            
        }
        
        // progress bar color
        if number >= 100 {
            self.progressBar.backgroundColor    = commonFunc.deepLime
        }

        return ratio
    }
    
    // only when necessary, reload point data
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        if viewController is topViewController {
            
            if myUserDefault.shared.getBool(key: "reload") {
                
                // reload table data
                self.tableView.reloadData()
                myUserDefault.shared.setBool(key: "reload", value: false)
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    // set value of each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : customCell = tableView.dequeueReusableCell(withIdentifier: "indexTableCell", for: indexPath) as! customCell
        
        // set color
        cell.backgroundColor    = commonFunc.clear
        cell.tintColor          = commonFunc.clear
        cell.layer.borderColor  = commonFunc.clear.cgColor
        
        cell.indexMark.isHidden = true
        
        // 選択された背景色を白に設定
        let cellSelectedBgView  = UIView()
        cellSelectedBgView.backgroundColor      = commonFunc.clear
        cell.selectedBackgroundView             = cellSelectedBgView
        
        // set text
        cell.titleLabel.text    = self.tableData[indexPath.row].title
        
        // check if can be tapped
        if self.tableData[indexPath.row].enable {

            cell.selectionStyle                 = .none

            if(self.tableData[indexPath.row].title == constLocal.reset.rawValue || self.tableData[indexPath.row].title == constLocal.inquiry.rawValue){
                // support menu
                cell.indexMark.layer.borderColor    = commonFunc.deepGray.cgColor
                cell.underLine.backgroundColor      = commonFunc.deepGray
            }
            else{
                // enable
                cell.indexMark.layer.borderColor    = commonFunc.deepGreen.cgColor
                cell.underLine.backgroundColor      = commonFunc.deepGreen
            }
        }
        else {
            // disable
            cell.selectionStyle                 = .none
            cell.backgroundColor                = commonFunc.deepGreen.withAlphaComponent(0.2)
            cell.indexMark.layer.borderColor    = commonFunc.deepGreen.cgColor
            cell.underLine.backgroundColor      = commonFunc.deepGreen.withAlphaComponent(0.2)
            cell.titleLabel.textColor           = commonFunc.deepGray
        }
        
        // check if show image
        if self.tableData[indexPath.row].check {
            // show image
            cell.checkImg.isHidden  = false
        }
        else {
            // show image
            cell.checkImg.isHidden  = true
        }
        
        // specified cell setting
        if tableData[indexPath.row].title  == constLocal.inquiry.rawValue {
            cell.checkImg.isHidden  = true
            cell.indexImg.image     = UIImage(named: "phone")
        }
        else if tableData[indexPath.row].title  == constLocal.reset.rawValue {
            cell.checkImg.isHidden  = true
            cell.indexImg.image     = UIImage(named: "power")
        }
        else if tableData[indexPath.row].title  == self.tutorialTitle {
            cell.checkImg.isHidden  = true
            cell.indexImg.image     = UIImage(named: "beginner")
        }
        // while developing
        else if tableData[indexPath.row].title.prefix(3)  == "OLD" {
            cell.checkImg.isHidden  = true
            cell.indexImg.image     = UIImage(named: "close")
        }
        else if tableData[indexPath.row].title  == "" {
            cell.checkImg.isHidden  = true
            cell.indexImg.isHidden  = true
            cell.underLine.isHidden = true
            cell.backgroundColor    = commonFunc.deepBlack
        }
        else if tableData[indexPath.row].enable {
            if !tableData[indexPath.row].check {
                cell.checkImg.isHidden  = false
                cell.checkImg.image     = UIImage(named: "arrow_left")
            }
            
            // let imageName               = "number-" + String(indexPath.row + 1)
            let imageName               = "number-" + String(indexPath.row)
            cell.indexImg.image         = UIImage(named: imageName)
        }
        else {
            // let imageName               = "number-d-" + String(indexPath.row + 1)
            let imageName               = "number-d-" + String(indexPath.row)
            cell.indexImg.image         = UIImage(named: imageName)
        }

        return cell
    }
    
    // height of cell
    func tableView(_ table: UITableView,heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  100
    }
    
    // tap cell
    func tableView(_ table: UITableView,didSelectRowAt indexPath: IndexPath) {

        // when tap cell is disabled
        if !self.tableData[indexPath.row].enable {
            // do nothing
        }
        // tap reset cell
        else if self.tableData[indexPath.row].title == constLocal.reset.rawValue {
            //commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.reset.rawValue)
            self.resetTable()
        }
        // tap other cells
        else {
            
            // if segue is existed
            if self.tableData[indexPath.row].segue  != "" {
                
                switch self.tableData[indexPath.row].title{
                    case self.tutorialTitle:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.tutorial.rawValue)
                    case self.introTitle:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.intro.rawValue)
                    case self.mdmTitle:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.mdm.rawValue)
                    case self.gmailTitle:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.gmail.rawValue)
                    case self.vpnTitle:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.vpn.rawValue)
                    case self.anySettingTitle:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.anySetting.rawValue)
                    default:
                        commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + "undefinedMenu")
                }

                self.selectChapter = indexPath.row
                //print("self.selectChapter \(self.selectChapter)")
                self.performSegue(withIdentifier: self.tableData[indexPath.row].segue, sender: nil)
            }
            // if url is existed
            else if self.tableData[indexPath.row].url   != "" {
                
                // set url
                let openURL = URL(string: self.tableData[indexPath.row].url)

                // open browser
                if UIApplication.shared.canOpenURL(openURL!) {
                    UIApplication.shared.open(openURL!)
                }
                
            }
            // if title is inquiry
            else if self.tableData[indexPath.row].title == constLocal.inquiry.rawValue {
                
                commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.tapMenu.rawValue + commonFunc.logKey.inquiry.rawValue)

                var url = NSURL(string: constLocal.telNoDummy.rawValue)!

                if !commonFunc.devMode {
                    url = NSURL(string: constLocal.telNo.rawValue)!
                }
                
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(url as URL)
                }
                else {
                    UIApplication.shared.openURL(url as URL)
                }
            
            }
            // else
            else {
                // do nothing
                self.cp("[" + String(indexPath.row) + "] undefined menu (do nothing)")
            }
            
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // if it can't get segue id, end process
        guard segue.identifier != nil else {
            return
        }
        
        if segue.identifier == "toCoverViewSegue" {
            let nextVC = segue.destination as! coverView
            nextVC.chapter = selectChapter
        }
        
    }
    
    private enum constLocal: String {
        
        case title          = "iPhone設定補助アプリ"
        case inquiry        = "お問い合わせ"
        case reset          = "最初からやり直す"
        case alertTitle     = "確認"
        case alertMessage   = "最初からやり直します\nよろしいですか？"
        case telNoDummy     = "tel://01234567890"
        case telNo          = "tel://08009199900"
        
    }
        
}

struct indexRecord {
    
    // menber
    let title   : String
    let segue   : String
    let url     : String
    let enable  : Bool
    let check   : Bool
    
}

extension indexRecord {
    
    // initializer
    init() {
        title   = "default"
        segue   = "default"
        url     = "default"
        enable  = false
        check   = false
    }
    
}

class customCell : UITableViewCell {
    
    @IBOutlet weak var indexMark    : UILabel!
    @IBOutlet weak var underLine    : UIView!
    @IBOutlet weak var titleLabel   : UILabel!
    @IBOutlet weak var checkImg     : UIImageView!
    @IBOutlet weak var indexImg     : UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // set color
        self.indexMark.layer.borderWidth    = 8
        self.indexMark.layer.borderColor    = commonFunc.deepGreen.cgColor
        self.indexMark.backgroundColor      = commonFunc.white
        self.underLine.backgroundColor      = commonFunc.deepGreen
        
        // initialize
        self.checkImg.isHidden              = true
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
