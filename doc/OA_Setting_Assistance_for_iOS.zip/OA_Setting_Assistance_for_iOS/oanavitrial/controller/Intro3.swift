import UIKit

class Intro3: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        
        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)
        
        attributedString.append(commonFunc.shared.addBreak())
        attributedString.append(attention)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)

        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "setting_name")

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title              = "確認事項 2"
        case message            = """
        iPhoneの名前は半角英数のみにしてください
        """
        case settingNavigation  = "＞　一般　＞　情報　＞　名前"
        case colorMessage       = "!! 漢字・記号はできません !!"
        
    }
}
