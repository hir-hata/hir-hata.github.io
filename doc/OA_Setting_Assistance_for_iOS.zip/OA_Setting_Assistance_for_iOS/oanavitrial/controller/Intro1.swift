import UIKit

class Intro1: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: true)
        self.templateView.setImage(str: "sim")

        // hide nav view
//        self.templateView.hideNavView(bool: true)]
        
        
        // テスト用
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)
        
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        self.templateView.setNavFuncButton1Image(str: "open_window")
        
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)

    }

    // テスト用
    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()

//            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.mmsSetting.rawValue)
//            UIApplication.shared.open(NSURL(string: constLocal.mmsSettingUrl.rawValue)! as URL)
            
//            // このアプリそのものの設定画面に飛ぶ
//            if let url = URL(string: UIApplication.openSettingsURLString) {
//                print("click intro1")
//                UIApplication.shared.open(url, options: [:], completionHandler: nil)
//            }
            
//            let url = URL(string: "App-Prefs:root=WIFI")
//            UIApplication.shared.open(url!)
            
//            if let url = URL(string:"App-Prefs:root") {
//                  if #available(iOS 10.0, *) {
//                        UIApplication.shared.open(url, options: [:], completionHandler: nil)
//                  } else {
//                        UIApplication.shared.openURL(url)
//                  }
//            }

            if let url = URL(string:"App-Prefs:root=General") {
                  if #available(iOS 10.0, *) {
                        UIApplication.shared.open(url, options: [:], completionHandler: nil)
                  } else {
                        UIApplication.shared.openURL(url)
                  }
            }

            
        }
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title      = "注意事項"
        case message    = """
        FY20業端Aリプレース対応では、
        ninoでの受領確認は不要です
        """
        
        case funcButton1Text    = "MMS設定"
    }
}
