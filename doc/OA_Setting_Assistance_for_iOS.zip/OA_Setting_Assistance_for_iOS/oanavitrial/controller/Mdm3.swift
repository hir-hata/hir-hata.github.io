import UIKit

class Mdm3: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "intuneAccess")

        // hide nav view
        self.templateView.hideNavView(bool: true)
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title      = "設定手順 3"
        case message    = """
        intuneポータルアプリを起動し
        「開始」をタップ後に「続行」を押下します
        
        次の画面で「完了」を押下します
        
        「アクセス〜」が表示されたら「OK」を
        押下し、次画面で「許可」を押下します
        """
        
    }
}
