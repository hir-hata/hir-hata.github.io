import UIKit

class Optional3: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)
        
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "sleep")

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    
    private enum constLocal: String {
        
        case title      = "端末不具合の予防設定"
        
        case message    = """
        業務端末Aにて端末が、初期化される事象が発生しています
        
        手前に傾けてスリープ解除をOFFにしてください
        """
        
        case settingNavigation  = "＞　画面表示と明るさ　＞　手前に傾けてスリープ解除"
        
//        case dialogTitle        = "アンケートへのご協力のお願い"
//        case dialogMessage      = """
//        設定お疲れ様でした！
//
//        さらなる、アプリ品質向上の為
//        アンケートへのご協力をお願いいたします
//
//        件名：iPhone設定補助アプリ PC準備情報
//        5．アンケート回答　からご回答ください
//        """
    }

}
