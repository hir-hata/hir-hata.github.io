import UIKit

class Optional1: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // hide image on this view
        self.templateView.hideImageView(bool: true)

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title      = "Smileアプリ電話帳設定"
        case message    = """
        Smileアプリ電話帳を設定します

        Smileアプリを起動後、「Smile電話帳」を押下
        
        「Smile電話帳のデータを最新化する」
        「更新」「OK」を押下

        設定 ＞ 電話 ＞ 着信拒否設定と着信ID
        SmileアプリをOFFにした後、ONにします
        """
        
        case message2    = """
        """
        
    }
}
