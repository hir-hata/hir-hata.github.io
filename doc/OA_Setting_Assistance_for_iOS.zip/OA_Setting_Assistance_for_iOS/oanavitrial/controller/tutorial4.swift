import UIKit
import Instructions

class tutorial4: UIViewController, CoachMarksControllerDataSource {

    @IBOutlet weak var templateView: swipeTemplateView!

    var coachController = CoachMarksController()
    var showCoachFlag   = true

    // マークのメッセージ配列
    let coachMessages = [
        """
        各手順の最後には完了ボタンが表示されます
        完了ボタンをタップすることで
        次の手順へ進むことができるようになります
        """
    ]

    // UIViewを配列にしておきます
    var targetCoachViews:[Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.coachController.dataSource = self
        self.coachController.overlay.color = commonFunc.deepBlue.withAlphaComponent(0.8)
        
        let message = "チュートリアル " + constLocal.message.rawValue

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)
        
        // set message
        let messageBody         = message
        let attributedString    = NSMutableAttributedString(string: messageBody, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        self.templateView.setLinkText(str: attributedString)
        
        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "done")
        
        // hide nav view
        self.templateView.hideNavView(bool: true)
                
        // use next Button
        self.templateView.hideNextButtonView(bool: false)

        // define of footer view tapping action
        self.templateView.nextButtonView.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickNextButton), button: self.templateView.nextButtonView)

        self.targetCoachViews = [self.templateView.nextButtonView]

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if(self.showCoachFlag) {
            self.coachController.start(in: .window(over: self))
            self.showCoachFlag = false
        }

    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.coachController.stop(immediately: true)
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    @objc func didClickNextButton(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNextButtonShadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNextButtonShadow()
            
            var logKey = commonFunc.logKey.done.rawValue + commonFunc.logKey.tutorial.rawValue

            if !myUserDefault.shared.getBool(key: "tutorial") {
                logKey = commonFunc.logKey.first.rawValue + logKey
            }

            commonFunc.shared.sendAnalysticLog(eventName: logKey)
            
            myUserDefault.shared.setBool(key: "tutorial", value: true)
            
            self.performSegue(withIdentifier: "tutorialToTopSegue", sender: nil)
        }
        
    }

    // 表示する文章を設定する
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkViewsAt index: Int, madeFrom coachMark: CoachMark) -> (bodyView: CoachMarkBodyView, arrowView: CoachMarkArrowView?) {
        let coachViews = coachMarksController.helper.makeDefaultCoachViews(withArrow: true, arrowOrientation: coachMark.arrowOrientation)
        coachViews.bodyView.hintLabel.text = self.coachMessages[index] // ここで文章を設定
        coachViews.bodyView.nextLabel.text = "OK" // 「次へ」などの文章

        return (bodyView: coachViews.bodyView, arrowView: coachViews.arrowView)
    }
    
    // マークの座標を設定する
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkAt index: Int) -> CoachMark {
        return self.coachController.helper.makeCoachMark(for: self.targetCoachViews[index] as? UIView, pointOfInterest: nil, cutoutPathMaker: nil)
        // for: にUIViewを指定すれば、マークがそのViewに対応します
    }
    
    // マークの数を返す
    func numberOfCoachMarks(for coachMarksController: CoachMarksController) -> Int {
        self.coachMessages.count
    }

    private enum constLocal: String {
        
        case title      = "チュートリアル4"
        case message    = """
        の手順は終了となります
        
        完了ボタンをタップしてください
        """
        
    }
}
