import UIKit

class Intro7: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
                
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: true)

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
        // show right Icon
        self.templateView.hideRightIconLabel(bool: false)
        
    }

    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title              = "PCでの事前準備 2"
        
        case message            = """
        iPhone設定補助アプリ PC準備情報
        を受領したら、PCでメールを開き
        1.VPN利用申請を実施します

        以下は本アプリ内の各工程で実施します
        2.MDM設定／３.GoogleSync申請
        """

        case settingNavigation  = """
        """
        
        case backButtonLabel    = "BACK"
        case funcButtonLabel    = "MMS設定"
        case nextButtonLabel    = "OK"
        
        case mmsSettingUrl      = "https://www.softbank.jp/mobile/support/mail/setting/iphone/mms-setting/"
        
    }
}
