import UIKit

class Mdm4: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        // let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage1.rawValue)

        let attributedString    = NSMutableAttributedString(string: constLocal.message1.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
//        attributedString.append(commonFunc.shared.addNewLine())
//        attributedString.append(attention)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]))
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        
        // hide image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "safetyContactInfo")

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 2)
        
        // set func button 1
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        self.templateView.setNavFuncButton1Image(str: "open_window")

        // set func button 2
        self.templateView.setNavFuncButton2Text(str: constLocal.funcButton2Text.rawValue)
        self.templateView.setNavFuncButton2Image(str: "open_window")

        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton2), button: self.templateView.navFuncButton2View)

    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.SafetyConfirm.rawValue)
            UIApplication.shared.open(NSURL(string: constLocal.SafetyConfirmUrl1.rawValue)! as URL)
        }
        
    }
    
    @objc func didClickFuncButton2(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.SafetyConfirm.rawValue)
            UIApplication.shared.open(NSURL(string: constLocal.SafetyConfirmUrl2.rawValue)! as URL)
        }
        
    }
    
    private enum constLocal: String {
        
        case title      = "安否確認設定 1"

        case message1   = """
        安否確認ボタンを押下し、ログインします
        ※ID : 社員番号を入力
        ※安否確認1に接続しづらい場合は、
          安否確認2から接続してください
        """
        
        case message2    = """
        「ユーザ情報」を選択し、「緊急連絡先情報」のNO.1 と NO.2 を空白にしてください
        
        その後、画面最下部にある「変更」を押下します
        """
        
        
//        case colorMessage1       = """
//        ※安否確認1に接続しづらい場合は、
//        !! 安否確認2から接続してください !!
//        """

        case funcButton1Text = "安否確認2"
        case funcButton2Text = "安否確認1"

        case SafetyConfirmUrl1     = "https://asp4.emc-call2nd.jp/softbank/emcuser/showindexpage.do"
        case SafetyConfirmUrl2     = "https://asp4.emc-call.jp/softbank/emcuser/showindexpage.do"
    }
}
