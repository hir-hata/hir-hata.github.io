import UIKit

class Intro5: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        let attributedString2   = NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attributedString2)
        
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "mms")

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)
        
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        self.templateView.setNavFuncButton1Image(str: "open_window")
        
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)

    }
 
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()

            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.mmsSetting.rawValue)
            UIApplication.shared.open(NSURL(string: constLocal.mmsSettingUrl.rawValue)! as URL)
        }
        
    }
    
    private enum constLocal: String {
        
        case title              = "確認事項 4"
        
        case message            = """
        MMSメッセージをONにしてください
        """

        case message2            = """
        MMS未設定時には
        MMS設定ボタンを押下します
        """

        case settingNavigation  = """
        ＞　メッセージ　＞　MMSメッセージ
        """
        
        case funcButton1Text    = "MMS設定"
        case mmsSettingUrl      = "https://www.softbank.jp/mobile/support/mail/setting/iphone/mms-setting/"
        
    }
}
