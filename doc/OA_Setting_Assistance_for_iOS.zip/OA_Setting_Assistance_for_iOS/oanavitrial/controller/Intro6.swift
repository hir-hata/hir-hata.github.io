import UIKit
import MessageUI

class Intro6: UIViewController, MFMessageComposeViewControllerDelegate {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
                
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "navi_faq")

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)
        
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        self.templateView.setNavFuncButton1Image(str: "mms_icon")
        
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
        
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        //... handle sms screen actions
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            
            self.templateView.showNavFuncButton1Shadow()
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.mmsInput.rawValue)
            showAlert()
            
        }
        
    }
    
    func showAlert(){
        
        // text field Objects
        var firstTextField  :UITextField    = UITextField.init()
        var secondTextField :UITextField    = UITextField.init()
        var textFieldsArray :Array<UITextField>?
        
        let alert       = UIAlertController(
            title           : constLocal.alertTitle.rawValue,
            message         : constLocal.alertMessage.rawValue,
            preferredStyle  : .alert
        )
        
        let okAction    = UIAlertAction(title: constLocal.alertRightButton.rawValue, style: .default, handler: { action in
            
            if (MFMessageComposeViewController.canSendText()) {

                commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.mmsOpen.rawValue)

                // アドレスの@より左側の文字列
                var username = firstTextField.text!
                
                // 入力値にドメインが含まれているかチェック
                if(firstTextField.text!.lowercased().contains("@")){
                    
                    // 含まれていたら@で分割する
                    let moji = firstTextField.text!.components(separatedBy: "@")
                    
                    // 分割した最初の文字列を取得(最初の@より左側の文字列）
                    username = moji[0]
                }

                // address@g.softbank.co.jp の形に成形
                let sendTo  = username + secondTextField.text!

                // save input string
                myUserDefault.shared.set(key: "gmailAddress", value: firstTextField.text!)
                
                let msgController                       = MFMessageComposeViewController()
                msgController.subject                   = constLocal.msgTitle.rawValue
                msgController.body                      = constLocal.msgBody.rawValue
                msgController.recipients                = [sendTo]
                msgController.messageComposeDelegate    = self
                self.present(msgController, animated: true, completion: nil)
            }
            
        })
        
        let cancelAction    = UIAlertAction(title: constLocal.alertLeftButton.rawValue, style: .cancel, handler: nil)
        
        // first text field
        alert.addTextField(configurationHandler: {(text:UITextField!) -> Void in
            
            text.placeholder        = constLocal.alertPlaceholder.rawValue
            text.clearButtonMode    = .always
            text.keyboardType       = .emailAddress
            
            if myUserDefault.shared.get(key: "gmailAddress") != "" {
                text.text           = myUserDefault.shared.get(key: "gmailAddress")
            }
            
            // check if text is empty
            NotificationCenter.default.addObserver(forName: UITextField.textDidChangeNotification, object: text, queue: OperationQueue.main) { (notification) in
                
                let textCount = text.text?.trimmingCharacters(in: .whitespacesAndNewlines).count ?? 0
                let textIsNotEmpty  = textCount > 0
                
                okAction.isEnabled  = textIsNotEmpty
                
            }
            
        })
        
        // second text field as label
        alert.addTextField(configurationHandler: {(text:UITextField!) -> Void in
            text.isEnabled          = false
            text.text               = constLocal.alertLabel.rawValue
        })
        
        textFieldsArray             = alert.textFields as Array<UITextField>?
        var count                   = 1
        
        for textField in textFieldsArray! {
            
            if count == 1 {
                firstTextField  = textField
            }
            else {
                secondTextField = textField
            }
            
            count += 1
            
        }
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        // initialize
        if firstTextField.text! == "" {
            okAction.isEnabled  = false
        }

        
        present(alert, animated: true, completion: {
            secondTextField.useUnderLine()
        })
        
    }
    
    
    
    private enum constLocal: String {
        
        case title              = "PCでの事前準備 1"
        
        case message            = """
        ご自身のGmail宛に事前準備情報を送信します
        MMS送信ボタンを押下してください

        MMS送信できない場合は、OAPC上で
        OAサポートナビFAQ:「F210308001」を検索し対応します
        """
        
        case funcButton1Text    = "MMS送信"
        
        case alertTitle         = "MMSを送信します"
        case alertMessage       = """
        ご自身のGmailアドレスを入力して
        MMSを開くボタンを押してください
        """

        case alertPlaceholder   = "Input your Gmail address"
        case alertLabel         = "@g.softbank.co.jp"
        case alertRightButton   = "MMSを開く"
        case alertLeftButton    = "キャンセル"

        case msgTitle           = "iPhone設定補助アプリ PC準備情報"
        case msgBody            = """
        
        １．nino受領確認
        　　nino（http://pureterminal-oa/cellphone-ap/menu/）へ接続し、
        　　「申請関連メニュー」→「受領確認」を押下

        ２．VPN利用申請
        　　Tarte（http://portal.tarte.bb.local/Tarte/tarteMain）へ接続し、
        　　「VPN申請」－「iPhone/iPad(SB)」選択し「OK」を押下
        　　VPN申請区分選択画面で「新規」を押下、
        　　内容申請内の「デバイス」を選択後、IMEIを入力し「承認情報登録」を押下
        　　!! IMEIは「主回線内のIMEI」を入力してください !!
        
        以降の手順は必ず、設定補助アプリ内のMDM設定時に行ってください
        3． MDM設定
        　　コード入力画面（https://microsoft.com/devicelogin）から
        　　設定補助アプリのMDM設定「■設定手順 1」で表示させているコードを入力し、「次へ」を押下
        　　「ご自身のGmailアドレス（～＠g.softbank.co.jp）」を入力し、「次へ」を押下
        　　!! SBKKのGmailアドレス入力してください !!
                 
        以降の手順は必ず、設定補助アプリ内のGmail設定時に行ってください
        4．GoogleSync申請
        　　Gargoyle（http://gargoyle.bb.local/user-menu/ ）へ接続し、
        　　「GoogleSync申請（SB/WCP）」を選択
        　　該当端末を選択し、IMEIを入力後「申請する」を押下
        　　!! IMEIは「主回線内のIMEI」を入力してください !!
        　　※Google Sync PW変更手順は、以下を参照します
        　　https://sites.google.com/a/g.softbank.co.jp/helpg/discussion-board/googlesync/06-002

        ※ メッセージをそのまま送信してください
        """
        
    }


}
