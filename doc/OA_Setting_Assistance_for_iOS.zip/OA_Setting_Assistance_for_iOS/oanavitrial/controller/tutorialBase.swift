import UIKit
import Parchment
import Instructions

class tutorialBase: UIViewController, CoachMarksControllerDataSource {
        
    let cities = [
        "Page1",
        "Page2",
        "Page3",
        "End"
    ]
    
    var coachController = CoachMarksController()
    var controllers:[UIViewController] = []
    
    @IBOutlet weak var headerView   : UIView!
    @IBOutlet weak var headerLabel  : UILabel!
    @IBOutlet weak var homeIcon     : UIImageView!
    @IBOutlet weak var contentsView : UIView!
    
    // マークのメッセージ配列
    let coachMessages = [
        "この手順のタイトルです",
        """
        ホームボタンをタップすると
        トップページに戻ります
        """,
        """
        手順の詳細はこちらに表示されます
        左右にスライド(スワイプ)すると
        画面の切り替えが行えます
        """,
        """
        この手順内のページ数が表示されます
        ページ番号をタップすることでも
        画面を切り替えが行えます
        """
    ]
    
    // UIViewを配列にしておきます
    var targetCoachViews:[Any] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.coachController.dataSource = self
        self.coachController.overlay.color = commonFunc.deepBlue.withAlphaComponent(0.8)
        
        self.headerView.backgroundColor         = commonFunc.deepGreen
        self.headerLabel.textColor              = commonFunc.white
        self.headerLabel.text                   = commonFunc.plist.value(forKeyPath: "title.tutorial") as? String

        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller1 = storyboard.instantiateViewController(withIdentifier: "tutorial1")
        let controller2 = storyboard.instantiateViewController(withIdentifier: "tutorial2")
        let controller3 = storyboard.instantiateViewController(withIdentifier: "tutorial3")
        let controller4 = storyboard.instantiateViewController(withIdentifier: "tutorial4")

        self.controllers = [
            controller1,
            controller2,
            controller3,
            controller4
        ]
        
        let pagingViewController = PagingViewController(viewControllers: controllers)
        
        pagingViewController.dataSource = self
        pagingViewController.menuItemSize = .sizeToFit(minWidth: 150, height: 40)
        pagingViewController.backgroundColor = commonFunc.brightGray        
//        pagingViewController.selectedBackgroundColor = UIColor.white
        pagingViewController.selectedBackgroundColor = commonFunc.deepLime.withAlphaComponent(0.7)
        pagingViewController.selectedTextColor = commonFunc.white
        pagingViewController.indicatorColor = commonFunc.brightBlack
        pagingViewController.borderColor = commonFunc.brightGray

        
        addChild(pagingViewController)
        view.addSubview(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
        pagingViewController.view.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
          pagingViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
          pagingViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
          pagingViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -5),
          pagingViewController.view.topAnchor.constraint(equalTo: self.headerView.bottomAnchor)
        ])
        
        // define of footer view tapping action
        self.homeIcon.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickHomeIcon), button: self.homeIcon)
        
        // set coaching target
        self.targetCoachViews = [
            self.headerLabel,
            self.homeIcon,
            self.contentsView,
            pagingViewController.collectionView
        ]
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.coachController.start(in: .window(over: self))
        //self.showDialog()

    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.coachController.stop(immediately: true)
    }
    
    
    @objc func didClickHomeIcon(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
        } else if gesture.state == .ended { // optional for touch up event catching
            self.cp("did click home button")
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    // 表示する文章を設定する
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkViewsAt index: Int, madeFrom coachMark: CoachMark) -> (bodyView: CoachMarkBodyView, arrowView: CoachMarkArrowView?) {
        let coachViews = coachMarksController.helper.makeDefaultCoachViews(withArrow: true, arrowOrientation: coachMark.arrowOrientation)
        coachViews.bodyView.hintLabel.text = self.coachMessages[index] // ここで文章を設定
        coachViews.bodyView.nextLabel.text = "OK" // 「次へ」などの文章

        return (bodyView: coachViews.bodyView, arrowView: coachViews.arrowView)
    }
    
    // マークの座標を設定する
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkAt index: Int) -> CoachMark {
        return self.coachController.helper.makeCoachMark(for: self.targetCoachViews[index] as? UIView, pointOfInterest: nil, cutoutPathMaker: nil)
        // for: にUIViewを指定すれば、マークがそのViewに対応します
    }
    
    // マークの数を返す
    func numberOfCoachMarks(for coachMarksController: CoachMarksController) -> Int {
        self.coachMessages.count
    }

    func showDialog(){
        
        // create alert
        let alert: UIAlertController = UIAlertController(title: "aaaaa", message: "bbbb", preferredStyle:  UIAlertController.Style.alert)

        let okAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in
        })
        
        // add action
        alert.addAction(okAction)

        // show alert
        present(alert, animated: true, completion: nil)
    }

}

extension tutorialBase: PagingViewControllerDataSource {
    func numberOfViewControllers(in pagingViewController: PagingViewController) -> Int {
        return cities.count
    }

    func pagingViewController(_: PagingViewController, viewControllerAt index: Int) -> UIViewController {
        return controllers[index]
    }

    func pagingViewController(_: PagingViewController, pagingItemAt index: Int) -> PagingItem {
        return PagingIndexItem(index: index, title: cities[index])
    }
}
