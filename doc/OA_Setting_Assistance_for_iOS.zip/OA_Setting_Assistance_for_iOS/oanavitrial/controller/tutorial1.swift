import UIKit

class tutorial1: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)
        
        // set message
        let messageBody         = constLocal.message.rawValue
        let attributedString    = NSMutableAttributedString(string: messageBody, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        self.templateView.setLinkText(str: attributedString)
        
        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "tutorial0")
        
        // hide nav view
        self.templateView.hideNavView(bool: true)

        // define of footer view tapping action
        self.templateView.navFuncButton1View.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickNavFuncButton1), button: self.templateView.navFuncButton1View)

        self.templateView.navFuncButton2View.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickNavFuncButton2), button: self.templateView.navFuncButton2View)

        self.templateView.navFuncButton3View.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickNavFuncButton3), button: self.templateView.navFuncButton3View)

    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    @objc func didClickNavFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
            self.cp("did click func button 1")
        }
        
    }
        
    @objc func didClickNavFuncButton2(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton2Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton2Shadow()
            self.cp("did click func button 2")
        }
        
    }
    
    @objc func didClickNavFuncButton3(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton3Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton3Shadow()
            self.cp("did click func button 3")
        }
        
    }

//    func showDialog(){
//
//        // create alert
//        let alert: UIAlertController = UIAlertController(title: constLocal.dialogTitle.rawValue, message: constLocal.dialogMessage.rawValue, preferredStyle:  UIAlertController.Style.alert)
//
//        let okAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:{
//            (action: UIAlertAction!) -> Void in
//            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.gmail.rawValue)
//            UIApplication.shared.open(NSURL(string: constLocal.intuneUrl.rawValue)! as URL)
//        })
//
//        let cancelAction: UIAlertAction = UIAlertAction(title: "キャンセル", style: UIAlertAction.Style.default, handler:{
//            (action: UIAlertAction!) -> Void in
//            // do nothing
//        })
//
//        // add action
//        alert.addAction(cancelAction)
//        alert.addAction(okAction)
//
//        // show alert
//        present(alert, animated: true, completion: nil)
//    }
    
    private enum constLocal: String {
        
        case title      = "チュートリアル1"
        case message    = """
        スワイプして次のページへ進みましょう
        """
        
        case backButtonLabel    = "BACK"
        case funcButtonLabel    = "Storeを開く"
        case nextButtonLabel    = "OK"
        
        case dialogTitle        = "Intune ポータルサイト アプリをダウンロード"
        case dialogMessage      = ""
        case intuneUrl          = "https://apps.apple.com/jp/app/intune-%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB-%E3%82%B5%E3%82%A4%E3%83%88/id719171358?mt=8"
    }

}
