import UIKit

class Optional6: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message1.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]))
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention)
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: true)
        self.templateView.setImage(str: "sleep")

        // hide nav view
        self.templateView.hideNavView(bool: true)    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    
    private enum constLocal: String {
        
        case title      = "旧端末返却時の設定 2"
        
        case message1    = """
        旧端末側で以下の操作を行います
        """
        
        case message2   = """
        パスコードを入力し、「iPhoneを消去」を2回タップします

        初期化が済んだら端末を返却してください

        機能制限をかけている場合は、
        機能制限パスコードが求められるので入力します
        """
        
        case aaa = """

        """
        case colorMessage      = """
        !! AppleIDのパスワード入力ダイアログが
           表示された場合、
           「iPhone（iPad）を探す」機能が
           「オン」になっています
        
           その場合は「■旧端末返却時の設定 1」
           を再度実施ください !!
        """
        
        case settingNavigation  = "＞ 一般 ＞ リセット ＞ すべてのコンテンツと設定を消去"
        
    }

}
