import UIKit

class Install_Zoom: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)
        let attention2          = commonFunc.shared.setAttention(message: constLocal.colorMessage2.rawValue)

        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]))
//        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention2)
        attributedString.append(NSMutableAttributedString(string: constLocal.message3.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]))
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // hide image on this view
        self.templateView.hideImageView(bool: true)

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)
        
        // set func button 1
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        self.templateView.setNavFuncButton1Image(str: "open_window")

        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
        
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
//            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.SafetyConfirm.rawValue)
//            UIApplication.shared.open(NSURL(string: constLocal.SafetyConfirmUrl1.rawValue)! as URL)
        }
        
    }
    
    private enum constLocal: String {
        
        case title      = "ZOOMアプリインストール"
        case message    = """
        ホームからintune ポータルアプリを開いて、
        ログインをします
        """
        
        case message2    = """
        検索で「ZOOM」を検索し「インストール」をタップします
        
        ZOOMサインイン時には「SSO」を選択し、
        「g-softbank-co-jp」を入力後
        
        """
        case message3    = """
        OAアカウントとパスワードを入力しログインします
        """

        case colorMessage      = """
        !! サインインが必要な場合は、
        OAアカウント or SBKKGmailアドレスを入力 !!
        """
        
        case colorMessage2      = """
        !! "ドット"ではなく"ハイフン" !!
        
        """

        case funcButton1Text = "Zoomアプリ"
    }

}
