import UIKit

class Mdm1: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "intuneIntro")

        // hide nav view
        self.templateView.hideNavView(bool: true)
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        self.templateView.constraintFooterHeight.constant   = self.view.safeAreaInsets.bottom
//    }

    private enum constLocal: String {
        
        case title      = "設定手順 1"
        case message    = """
        自動インストールされた
        intuneポータルアプリを起動します
        
        ホームからintune ポータルアプリを
        タップし、サインイン画面にて
        「別のデバイスからサインインする」
        を選択します

        コードが表示されたら、サインイン画面を閉じずに表示させたまま次へ進みます
        """
        
        case backButtonLabel    = "BACK"
        case funcButtonLabel    = "Storeを開く"
        case nextButtonLabel    = "OK"
        
        case dialogTitle        = "Intune ポータルサイト アプリをダウンロード"
        case dialogMessage      = ""
        case intuneUrl          = "https://apps.apple.com/jp/app/intune-%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB-%E3%82%B5%E3%82%A4%E3%83%88/id719171358?mt=8"
    }
}
