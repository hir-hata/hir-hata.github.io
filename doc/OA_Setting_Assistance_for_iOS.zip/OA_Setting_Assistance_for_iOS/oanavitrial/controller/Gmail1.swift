import UIKit

class Gmail1: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        
        let attributedString2   = NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        

        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attributedString2)
        
        
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
        
        // hide image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "setting")

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)

        // set func button 1
        self.templateView.setNavFuncButton1Text(str: constLocal.dialogTitle.rawValue)
        self.templateView.setNavFuncButton1Image(str: "info")
        
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.pwHint.rawValue)
            showAlert()
        }
        
    }

    func showAlert(){
        
        // create alert
        let alert: UIAlertController = UIAlertController(title: constLocal.dialogTitle.rawValue, message: constLocal.dialogMessage.rawValue, preferredStyle:  UIAlertController.Style.alert)
        
        // ok action
        let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in
            // do nothing
        })
        
        // add action
        alert.addAction(defaultAction)

        // show alert
        present(alert, animated: true, completion: nil)
    }
    
    private enum constLocal: String {
        
        case title      = "設定確認"
        
        case message    = """
        以下からGmail設定を選択します
        """
        
        case message2   = """
        5箇所を入力・確認してください
        
        1. メール： ご自身の@g.softbank.co.jp
        2. サーバ： m.google.com
        3. ドメイン： 空白
        4. ユーザ名： ご自身の@g.softbank.co.jp
        5. パスワード： Google Sync PW が入っていること
        """
        
        case settingNavigation  = "＞　メール　＞ アカウント ＞　Exchange　＞ アカウント"
        case funcButtonLabel    = "PWとは？"
        
        case dialogTitle = "Google Sync PWとは？"
        case dialogMessage = """
        Google Syncから申請したPWです
        PWが不明な場合は
        OAPCから再設定ください
        
        事前準備で送信しているメール内の
        Google Sync PW変更リンクから
        PW変更可能です
        """
    }
}
