import UIKit

class EndChapter: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    // recieve from cover view
    var chapterTitle    :String?
    var chapterNumber   :Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let message = chapterNumber == 5 ? (self.chapterTitle ?? "") + constLocal.finish.rawValue : (self.chapterTitle ?? "") + constLocal.message.rawValue

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)
        
        // set message
        let messageBody         = message
        let attributedString    = NSMutableAttributedString(string: messageBody, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        self.templateView.setLinkText(str: attributedString)
        
        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "done")
        
        // hide nav view
        self.templateView.hideNavView(bool: true)
                
        // use next Button
        self.templateView.hideNextButtonView(bool: false)

        // define of footer view tapping action
        self.templateView.nextButtonView.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickNextButton), button: self.templateView.nextButtonView)
        
        //print("this chapter is : " + String(self.chapterNumber ?? 0))
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    @objc func didClickNextButton(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNextButtonShadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNextButtonShadow()
            activateNextChapter(chapterNumber: self.chapterNumber ?? 0)
            self.performSegue(withIdentifier: "toTopSegue", sender: nil)
        }
        
    }
    
    func activateNextChapter(chapterNumber: Int) {
        
        var logKey  = ""
        
        switch chapterNumber {
            
            // Intro
            case 1 :
            
                logKey = commonFunc.logKey.done.rawValue + commonFunc.logKey.intro.rawValue
                
                if !myUserDefault.shared.getBool(key: "enableMdm") {
                    logKey = commonFunc.logKey.first.rawValue + logKey
                }
                
                commonFunc.shared.sendAnalysticLog(eventName: logKey)
                
                myUserDefault.shared.setBool(key: "enableMdm", value: true)
                myUserDefault.shared.setBool(key: "reload", value: true)

            // MDM
            case 2 :
                
                logKey = commonFunc.logKey.done.rawValue + commonFunc.logKey.mdm.rawValue
            
                if !myUserDefault.shared.getBool(key: "enableGmail") {
                    logKey = commonFunc.logKey.first.rawValue + logKey
                }
            
                commonFunc.shared.sendAnalysticLog(eventName: logKey)
            
                myUserDefault.shared.setBool(key: "enableGmail", value: true)
                myUserDefault.shared.setBool(key: "reload", value: true)

            // Gmail
            case 3 :
                
                logKey = commonFunc.logKey.done.rawValue + commonFunc.logKey.gmail.rawValue
                
                if !myUserDefault.shared.getBool(key: "enableVpn") {
                    logKey = commonFunc.logKey.first.rawValue + logKey
                }
                
                commonFunc.shared.sendAnalysticLog(eventName: logKey)
                
                myUserDefault.shared.setBool(key: "enableVpn", value: true)
                myUserDefault.shared.setBool(key: "reload", value: true)

            // VPN
            case 4 :
                
                logKey = commonFunc.logKey.done.rawValue + commonFunc.logKey.vpn.rawValue
                
                if !myUserDefault.shared.getBool(key: "enableAnySetting") {
                    logKey = commonFunc.logKey.first.rawValue + logKey
                }
                
                commonFunc.shared.sendAnalysticLog(eventName: logKey)
                
                myUserDefault.shared.setBool(key: "enableAnySetting", value: true)
                myUserDefault.shared.setBool(key: "reload", value: true)
            
            // Optional
            case 5 :
                
                logKey = commonFunc.logKey.done.rawValue + commonFunc.logKey.all.rawValue

                // first time
                if !myUserDefault.shared.getBool(key: "allDone") {
                    logKey = commonFunc.logKey.first.rawValue + logKey
                    commonFunc.shared.sendAnalysticLog(eventName: logKey)
                    
                    //don't use on Phone Replace -> new page deploy
                    //self.showDialog()
                    self.doneAction()
                }
                //  after the second time
                else {
                    commonFunc.shared.sendAnalysticLog(eventName: logKey)
                    self.doneAction()
                }
            
            default :
                
                print("do nothing")
        }
        
    }
    
    func showDialog(){
        
        // create alert
        let alert: UIAlertController = UIAlertController(title: constLocal.dialogTitle.rawValue, message: constLocal.dialogMessage.rawValue, preferredStyle:  UIAlertController.Style.alert)

        let okAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in
            self.doneAction()
            self.performSegue(withIdentifier: "toTopSegue", sender: nil)
        })
        
        // add action
        alert.addAction(okAction)

        // show alert
        present(alert, animated: true, completion: nil)
    }
    
    func doneAction(){
        myUserDefault.shared.setBool(key: "allDone", value: true)
        myUserDefault.shared.setBool(key: "reload", value: true)
    }
    
    private enum constLocal: String {
        
        case title      = "手順の完了"
        case message    = """
         の手順は終了です
        
        完了ボタンをタップして、次の手順に進んでください
        """
        
        case finish     = """
         の手順は終了です
        
        以上で、全ての手順が完了しました
        最後に完了ボタンをタップし終了してください
        """
        
        case dialogTitle        = "アンケートへのご協力のお願い"
        case dialogMessage      = """
        設定お疲れ様でした！

        さらなる、アプリ品質向上の為
        アンケートへのご協力をお願いいたします
        
        件名：iPhone設定補助アプリ PC準備情報
        5．アンケート回答　からご回答ください
        """
        
    }
}
