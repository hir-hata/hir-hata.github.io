import UIKit

class Vpn1: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // hide image on this view
        self.templateView.hideImageView(bool: true)

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
        // show right icon
        self.templateView.hideRightIconLabel(bool: false)
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title      = "申請確認"
        case message    = """
        事前準備でVPN申請は行いましたか？
        
        未申請であれば、MMSで送信した
        メールを参照し申請をします
        
        iPhone設定補助アプリ PC準備情報
        
        1．VPN利用申請
        """
        
    }
}
