import UIKit

class Optional4: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)
//        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]))
        
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "iphoneSearchOff")

        // hide nav view
        self.templateView.hideNavView(bool: true)    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    
    private enum constLocal: String {
        
        case title      = "旧端末返却時の設定 1"
        
        case message    = """
        旧端末側で以下の操作を行います
        """

        case message2   = """
        をオフにします
        
        AppleIDのパスワード要求があるので入力してください
        """

        case settingNavigation  = "＞　画面最上部のApple ID～　＞　探す　＞　iPhoneを探す"
        
    }

}
