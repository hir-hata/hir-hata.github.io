import UIKit
import Instructions

class tutorial2: UIViewController, CoachMarksControllerDataSource {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    var coachController = CoachMarksController()
    var showCoachFlag   = true

    // マークのメッセージ配列
    let coachMessages = [
        """
        PCで設定する作業の場合には
        PCのアイコンが表示されます
        """,
        """
        PCで設定する作業の場合には
        背景色も変更されます
        """,
        """
        手順によってはこちらに
        追加のボタンが表示されます
        """,
        """
        ボタンにより説明が見えない場合には
        こちらをタップすることで
        表示・非表示にすることができます
        """]

    // UIViewを配列にしておきます
    var targetCoachViews:[Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)
        
        self.coachController.dataSource = self
        self.coachController.overlay.color = commonFunc.deepBlue.withAlphaComponent(0.8)
        
        // set message
        let messageBody         = constLocal.message.rawValue
        let attributedString    = NSMutableAttributedString(string: messageBody, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        self.templateView.setLinkText(str: attributedString)
        
        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "tutorial1")
        
        // use nav message
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 3)
        
        self.templateView.hideRightIconLabel(bool: false)

        // define of footer view tapping action
//        self.templateView.funcButtonView.isUserInteractionEnabled   = true
//        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton), button: self.templateView.navFuncButtonView)
        
        // set coaching target
        self.targetCoachViews = [
            self.templateView.imgRightIcon,
            self.templateView.contentsView,
            self.templateView.navSubFieldView,
            self.templateView.iconCoverView
        ]
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if(self.showCoachFlag) {
            self.coachController.start(in: .window(over: self))
            self.showCoachFlag = false
        }
        
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.coachController.stop(immediately: true)
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    @objc func didClickFuncButton(gesture: UILongPressGestureRecognizer) {
        
//        if gesture.state == .began {
//            self.templateView.hideFuncButtonShadow()
//        } else if gesture.state == .ended { // optional for touch up event catching
//            self.templateView.showFuncButtonShadow()
//            showDialog()
//        }
        
    }
    
    // 表示する文章を設定する
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkViewsAt index: Int, madeFrom coachMark: CoachMark) -> (bodyView: CoachMarkBodyView, arrowView: CoachMarkArrowView?) {
        let coachViews = coachMarksController.helper.makeDefaultCoachViews(withArrow: true, arrowOrientation: coachMark.arrowOrientation)
        coachViews.bodyView.hintLabel.text = self.coachMessages[index] // ここで文章を設定
        coachViews.bodyView.nextLabel.text = "OK" // 「次へ」などの文章

        return (bodyView: coachViews.bodyView, arrowView: coachViews.arrowView)
    }
    
    // マークの座標を設定する
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkAt index: Int) -> CoachMark {
        return self.coachController.helper.makeCoachMark(for: self.targetCoachViews[index] as? UIView, pointOfInterest: nil, cutoutPathMaker: nil)
        // for: にUIViewを指定すれば、マークがそのViewに対応します
    }
    
    // マークの数を返す
    func numberOfCoachMarks(for coachMarksController: CoachMarksController) -> Int {
        self.coachMessages.count
    }
    
    private enum constLocal: String {
        
        case title      = "チュートリアル2"
        case message    = """
        スワイプして次のページへ進みましょう
        """
        
    }
}
