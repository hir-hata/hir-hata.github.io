import UIKit

class Mdm6: UIViewController {
    
    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        // let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)

        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        attributedString.append(commonFunc.shared.addNewLine())
        //attributedString.append(attention)
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
        
        // show image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "recom_app_not_avail")

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)
        
        // set func button 1
        self.templateView.setNavFuncButton1Text(str: constLocal.dialogTitle.rawValue)
        self.templateView.setNavFuncButton1Image(str: "info")
        
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.recomApp.rawValue)
            showPopup()
        }
        
    }

    func showPopup(){
        
        // create alert
        let alert: UIAlertController = UIAlertController(title: constLocal.dialogTitle.rawValue, message: constLocal.dialogMessage.rawValue, preferredStyle:  UIAlertController.Style.alert)
        
        // ok action
        let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:{
            (action: UIAlertAction!) -> Void in
            // do nothing
        })
        
        // add action
        alert.addAction(defaultAction)

        // show alert
        present(alert, animated: true, completion: nil)
    }
    
    private enum constLocal: String {
        
        case title      = "設定手順 4"
        case message    = """
        ここまでの手順が完了したら、
        Gmailなどの推奨アプリがインストールされています
        
        推奨アプリはログイン時にVPN接続が必要です
        
        GmailなどのアプリはVPN設定後にご利用ください
        """
        
        case colorMessage       = "※推奨アプリはログイン時にVPN接続が必要です"
        
        case dialogTitle = "推奨アプリとは？"
        
        case dialogMessage = """
        社内では以下のアプリの
        インストールが推奨されています
        
        Gmail
        Gカレンダー
        Smile
        安否確認
        接触確認アプリ
        """
    }

}
