import UIKit

class Optional5: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
                
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: true)

        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 1)
        
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNavFuncButton1Shadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNavFuncButton1Shadow()
            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.survey.rawValue)
            UIApplication.shared.open(NSURL(string: constLocal.SafetyConfirmSettingUrl.rawValue)! as URL)
        }
        
    }
    
    private enum constLocal: String {
        
        case title      = "アンケートにご協力ください"
        
        case message    = """
        設定お疲れ様でした！
        設定完了後に、アンケートへご回答を
        お願いします
        """
        
        case funcButton1Text = "アンケート"
        case SafetyConfirmSettingUrl = "https://docs.google.com/forms/d/e/1FAIpQLScwIZpj1ofqQOFJAVedekMYy6v7XQZuBF4OV2NF0jDMuEFBVw/viewform"
        
    }

}
