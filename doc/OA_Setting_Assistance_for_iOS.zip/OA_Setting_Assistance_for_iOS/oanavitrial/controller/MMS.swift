import UIKit
import MessageUI

class MMS: UIViewController, MFMessageComposeViewControllerDelegate {
    
    @IBOutlet weak var templateView: templateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set header
        self.templateView.setHeaderText(str: commonFunc.plist.value(forKeyPath: "title.intro") as! String)
        
        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)
        
        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: 18.0)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
        
        // unuse image on this view
        self.templateView.hideImageView(bool: true)
        
        // use footer on this view
        self.templateView.hideFooterView(bool: false)
        
        // use func button on this view
        self.templateView.hideFuncButton(bool: false)
        self.templateView.setFuncLabelText(str: constLocal.funcButtonLabel.rawValue)
        
        // unuse nav message
        self.templateView.hideNavView(bool: true)
        
        // define of footer view tapping action
        self.templateView.backButtonView.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickBackButton), button: self.templateView.backButtonView)
        
        self.templateView.funcButtonView.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton), button: self.templateView.funcButtonView)
        
        self.templateView.nextButtonView.isUserInteractionEnabled   = true
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickNextButton), button: self.templateView.nextButtonView)
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        //... handle sms screen actions
        self.dismiss(animated: true, completion: nil)
    }
    
    func showAlert(){
        
        // text field Objects
        var firstTextField  :UITextField    = UITextField.init()
        var secondTextField :UITextField    = UITextField.init()
        var textFieldsArray :Array<UITextField>?

        let alert       = UIAlertController(
                            title           : constLocal.alertTitle.rawValue,
                            message         : constLocal.alertMessage.rawValue,
                            preferredStyle  : .alert
                            )
        
        let okAction    = UIAlertAction(title: constLocal.alertRightButton.rawValue, style: .default, handler: { action in
            
            let sendTo  = firstTextField.text! + secondTextField.text!

            if (MFMessageComposeViewController.canSendText()) {

                let msgController       = MFMessageComposeViewController()
                msgController.subject   = constLocal.msgTitle.rawValue
                msgController.body      = constLocal.msgBody.rawValue
                msgController.recipients = [sendTo]
                msgController.messageComposeDelegate = self
                self.present(msgController, animated: true, completion: nil)
            }
            
            
        })
        
        let cancelAction    = UIAlertAction(title: constLocal.alertLeftButton.rawValue, style: .cancel, handler: nil)
        
        // initialize
        okAction.isEnabled  = false

        // first text field
        alert.addTextField(configurationHandler: {(text:UITextField!) -> Void in
            
            text.placeholder        = constLocal.alertPlaceholder.rawValue
            text.clearButtonMode    = .always
            text.keyboardType       = .emailAddress
            
            // check if text is empty
            NotificationCenter.default.addObserver(forName: UITextField.textDidChangeNotification, object: text, queue: OperationQueue.main) { (notification) in
                
                let textCount = text.text?.trimmingCharacters(in: .whitespacesAndNewlines).count ?? 0
                let textIsNotEmpty  = textCount > 0
                
                okAction.isEnabled  = textIsNotEmpty
            }

        })

        // second text field as label
        alert.addTextField(configurationHandler: {(text:UITextField!) -> Void in
            text.isEnabled          = false
            text.text               = constLocal.alertLabel.rawValue
        })

        textFieldsArray             = alert.textFields as Array<UITextField>?
        var count                   = 1
        
        for textField in textFieldsArray! {
            
            if count == 1 {
                firstTextField  = textField
            }
            else {
                secondTextField = textField
            }
            
            count += 1
            
        }
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: {
            secondTextField.useUnderLine()
        })

    }

    
    // back to previous page
    @objc func didClickBackButton(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideBackButtonShadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showBackButtonShadow()
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    @objc func didClickFuncButton(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideFuncButtonShadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            
            self.templateView.showFuncButtonShadow()
            showAlert()
            
        }
        
    }
    
    // go to top page
    @objc func didClickNextButton(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .began {
            self.templateView.hideNextButtonShadow()
        } else if gesture.state == .ended { // optional for touch up event catching
            self.templateView.showNextButtonShadow()
            self.performSegue(withIdentifier: "MMStoTopSegue", sender: nil)
        }
        
    }
    
    
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        
        self.templateView.setHeaderHeight(height: displayHeight * 0.08)
        self.templateView.setTitleHeight(height: displayHeight * 0.06)
        self.templateView.setFooterHeight(height: displayHeight * 0.05)
        self.templateView.setNavFooterHeight(height: displayHeight * 0.05)
        
        print("nav footer height : \(displayHeight * 0.05)")
        //print("self.templateView.constraintOpenHeight.constant : \(self.templateView.constraintOpenHeight.constant)")
        
        self.templateView.checkStyle()
        self.templateView.calcContentsHeight()
        
        //self.templateView.setNavOpenHeight(height: displayHeight * 0.05)
        //print("self.templateView.constraintOpenHeight.constant : \(self.templateView.constraintOpenHeight.constant)")
        
    }
    
    private enum constLocal: String {
        
        case title      = "MMSテスト画面"
        case message    = """
        PCから作業するシステムへのリンクを
        一覧にしたメッセージ（MMS）をご自身の
        Gmailに送信することができます
        
        以下の宛先入力ボタンより
        ご自身のGmailアドレスを入力ください
        """
        case backButtonLabel    = "BACK"
        case funcButtonLabel    = "宛先入力"
        case nextButtonLabel    = "OK"
        
        case alertTitle         = "MMSを送信します"
        case alertMessage       = """
        ご自身のGmailアドレスを入力して
        MMSを開くボタンを押してください
        """
        
        case alertPlaceholder   = "hiroyuki01.hata"
        case alertLabel         = "@g.softbank.co.jp"
        case alertRightButton   = "MMSを開く"
        case alertLeftButton    = "cancel"
        
        case msgTitle           = "【iPhone設定】PC作業リンク一覧"
        case msgBody            = """
        ※ そのまま送信してください
        
        この作業はPCで行なってください
        
        1.ninoへ接続し、受領確認をしてください
        http://pureterminal-oa/cellphone-ap/menu/
        
        2.Gargoyleへ接続し「GoogleSync申請」を実行してください
        http://gargoyle.bb.local/user-menu/
        
        3.Tarteへ接続し、VPN申請をしてください
        http://portal.tarte.bb.local/Tarte/tarteMain
        """
        
    }


}

//extension UITextField {
//    
//    func useUnderLine() {
//        
//        superview?.backgroundColor = .clear
//        
//        let view = superview?.superview
//        view?.subviews.first?.alpha = 0
//        view?.backgroundColor = .clear
//        
//    }
//    
//}
