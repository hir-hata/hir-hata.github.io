import UIKit

class Vpn2: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message1.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention)
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
        

        
        // hide image on this view
        self.templateView.hideImageView(bool: true)

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    private enum constLocal: String {
        
        case title      = "設定手順"
        case message1   = """
        件名：[iPhone/iPad-VPN]証明書発行のお知らせ IMEI: ・・・
        
        メールに従い設定してください
        """
        
        case colorMessage       = "!! 上長承認の翌日にメールが届きます !!"
        
        case message2   = """
        設定後は以降の工程に戻ってください
        """

    }

}
