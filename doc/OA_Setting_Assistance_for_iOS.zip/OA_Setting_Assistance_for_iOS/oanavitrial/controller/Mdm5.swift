import UIKit

class Mdm5: UIViewController {
    
    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)

        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention)
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
        
        // show image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "safetyConfirmApp")

        // hide nav view
        self.templateView.hideNavView(bool: true)
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title      = "安否確認設定 2"
        case message    = """
        上部の「ユーザメニュー」を選択し、
        「スマートデバイス用アプリ」を選択します
        
        その後、「起動または初期設定」を
        選択するとアプリに遷移しますので
        ID/PWを入力後、「ログイン」を押下しアプリを閉じます
        """
        
        case colorMessage      = """
        !! 安否確認アプリに遷移しない場合は、
           アプリがインストールされるまで
           5分ほどお待ちください !!
        """
    }

}
