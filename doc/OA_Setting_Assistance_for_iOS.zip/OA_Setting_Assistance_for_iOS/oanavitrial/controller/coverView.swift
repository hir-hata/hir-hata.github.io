import UIKit
import Parchment

class coverView: UIViewController {

    @IBOutlet weak var headerView: headerTemplateView!
    @IBOutlet weak var SafeAreaTop: UIView!
    @IBOutlet weak var SafeAreaBottom: UIView!
    
    var pages:[String] = []
    var controllers:[UIViewController] = []
    var chapter:Int?

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setChapterInfo(self.chapter ?? 0)
        
        self.SafeAreaTop.backgroundColor = commonFunc.deepGreen
        self.SafeAreaBottom.backgroundColor = commonFunc.deepGreen
        
        print("chapter is \(String(describing: chapter))")
        
        let pagingViewController = PagingViewController(viewControllers: controllers)
        
        pagingViewController.dataSource = self
        pagingViewController.menuItemSize = .sizeToFit(minWidth: 150, height: 40)
        pagingViewController.backgroundColor = commonFunc.brightGray
//        pagingViewController.selectedBackgroundColor = UIColor.white
        pagingViewController.selectedBackgroundColor = commonFunc.deepLime.withAlphaComponent(0.7)
        pagingViewController.selectedTextColor = commonFunc.white
        pagingViewController.indicatorColor = commonFunc.brightBlack
        pagingViewController.borderColor = commonFunc.brightGray

        addChild(pagingViewController)
        view.addSubview(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
        pagingViewController.view.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
          pagingViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
          pagingViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
          pagingViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -5),
          pagingViewController.view.topAnchor.constraint(equalTo: self.headerView.bottomAnchor)
        ])
        
        // define of tapping action
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickHomeIcon), button: self.headerView.homeIcon)

    }
    

    // open or close bottom nav when click img
    @objc func didClickHomeIcon(gesture: UILongPressGestureRecognizer){
        
        // handle touch down and touch up events separately
        if gesture.state == .began {
        }
        else if gesture.state == .ended { // optional for touch up event catching
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    func setChapterInfo(_: Int){

        let storyboard          = UIStoryboard(name: "Main", bundle: nil)
        var displayChapterInfo  :chapterInfo
        let endChapterViewController    = storyboard.instantiateViewController(withIdentifier: "EndChapter") as! EndChapter

        switch chapter {
            
            // Intro
            case 1 :
                
                displayChapterInfo  = chapterInfo(
                    title: commonFunc.plist.value(forKeyPath: "title.intro") as! String,
                    pages: [
                        "Page1",
                        "Page2",
                        "Page3",
                        "Page4",
                        "Page5",
                        "Page6",
                        "End"
                    ],
                    controllers: [
                        //storyboard.instantiateViewController(withIdentifier: "Intro1"),
                        storyboard.instantiateViewController(withIdentifier: "Intro2"),
                        storyboard.instantiateViewController(withIdentifier: "Intro3"),
                        storyboard.instantiateViewController(withIdentifier: "Intro4"),
                        storyboard.instantiateViewController(withIdentifier: "Intro5"),
                        storyboard.instantiateViewController(withIdentifier: "Intro6"),
                        storyboard.instantiateViewController(withIdentifier: "Intro7"),
                        endChapterViewController
                    ]
                )
            
            // MDM
            case 2 :
                
                displayChapterInfo  = chapterInfo(
                    title: commonFunc.plist.value(forKeyPath: "title.mdm") as! String,
                    pages: [
                        "Page1",
                        "Page2",
                        "Page3",
                        "Page4",
                        "End"
                    ],
                    controllers: [
                        storyboard.instantiateViewController(withIdentifier: "Mdm1"),
                        storyboard.instantiateViewController(withIdentifier: "Mdm2"),
                        storyboard.instantiateViewController(withIdentifier: "Mdm3"),
                        storyboard.instantiateViewController(withIdentifier: "Mdm6"),
                        endChapterViewController
                    ]
                )

            // Gmail
            case 3 :
                
                displayChapterInfo  = chapterInfo(
                    title: commonFunc.plist.value(forKeyPath: "title.gmail") as! String,
                    pages: [
                        "Page1",
                        "Page2",
                        "Page3",
                        "End"
                    ],
                    controllers: [
                        storyboard.instantiateViewController(withIdentifier: "Gmail1"),
                        storyboard.instantiateViewController(withIdentifier: "Gmail2"),
                        storyboard.instantiateViewController(withIdentifier: "Gmail3"),
                        endChapterViewController
                    ]
                )

            // VPN
            case 4 :
                
                displayChapterInfo  = chapterInfo(
                    title: commonFunc.plist.value(forKeyPath: "title.vpn") as! String,
                    pages: [
                        "Page1",
                        "Page2",
                        "Page3",
                        "End"
                    ],
                    controllers: [
                        storyboard.instantiateViewController(withIdentifier: "Vpn1"),
                        storyboard.instantiateViewController(withIdentifier: "Vpn2"),
                        storyboard.instantiateViewController(withIdentifier: "Vpn3"),
                        endChapterViewController
                    ]
                )

            // Optional
            case 5 :
                
                displayChapterInfo  = chapterInfo(
                    title: commonFunc.plist.value(forKeyPath: "title.anySetting") as! String,
                    pages: [
                        "Page1",
                        "Page2",
                        "Page3",
                        "Page4",
                        "Page5",
                        "Page6",
                        "Page7",
                        "Page8",
                        "Page9",
                        "Page10",
                        "End"
                    ],
                    controllers: [
                        storyboard.instantiateViewController(withIdentifier: "Install_Slack"),
                        storyboard.instantiateViewController(withIdentifier: "Install_Zoom"),
                        storyboard.instantiateViewController(withIdentifier: "Optional1"),
                        storyboard.instantiateViewController(withIdentifier: "Mdm4"),
                        storyboard.instantiateViewController(withIdentifier: "Mdm5"),
                        storyboard.instantiateViewController(withIdentifier: "Optional2"),
                        storyboard.instantiateViewController(withIdentifier: "Optional3"),
                        storyboard.instantiateViewController(withIdentifier: "Optional4"),
                        storyboard.instantiateViewController(withIdentifier: "Optional6"),
                        storyboard.instantiateViewController(withIdentifier: "Optional5"),
                        endChapterViewController
                    ]
                )

            default :
                displayChapterInfo = chapterInfo()
        }

        // set info
        self.headerView.setHeaderTitlea(str: displayChapterInfo.title)
        self.pages = displayChapterInfo.pages
        self.controllers = displayChapterInfo.controllers
        
        // send chapter info
        endChapterViewController.chapterTitle   = displayChapterInfo.title
        endChapterViewController.chapterNumber  = chapter

    }
}

extension coverView: PagingViewControllerDataSource {
    func numberOfViewControllers(in pagingViewController: PagingViewController) -> Int {
        return pages.count
    }

    func pagingViewController(_: PagingViewController, viewControllerAt index: Int) -> UIViewController {
        return controllers[index]
    }

    func pagingViewController(_: PagingViewController, pagingItemAt index: Int) -> PagingItem {
        return PagingIndexItem(index: index, title: pages[index])
    }
}

struct chapterInfo {
    
    // menber
    let title       : String
    let pages       : [String]
    let controllers : [UIViewController]
    
}

extension chapterInfo {
    
    // initializer
    init() {
        title       = "default title"
        pages       = []
        controllers = []
    }
    
}


