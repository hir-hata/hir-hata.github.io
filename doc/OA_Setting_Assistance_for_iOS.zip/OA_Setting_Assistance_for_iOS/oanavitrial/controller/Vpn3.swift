import UIKit

class Vpn3: UIViewController {


    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message1.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
                
        // show image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "recom_app_avail")

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    private enum constLocal: String {
        
        case title      = "確認事項"
        case message1   = """
        VPN接続が可能になったら、
        Gmail、Gカレンダー、Smile等のアプリが利用できます
        """
    }

}
