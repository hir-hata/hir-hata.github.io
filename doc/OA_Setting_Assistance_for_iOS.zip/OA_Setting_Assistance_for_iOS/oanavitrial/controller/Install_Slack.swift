import UIKit

class Install_Slack: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)

        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention)
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(NSMutableAttributedString(string: constLocal.message2.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)]))
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // hide image on this view
        self.templateView.hideImageView(bool: true)
        
        // show nav view
        self.templateView.hideNavView(bool: false)
        self.templateView.setNavFuncCount(num: 2)
        
        // set func button 1
        self.templateView.setNavFuncButton1Text(str: constLocal.funcButton1Text.rawValue)
        self.templateView.setNavFuncButton1Image(str: "open_window")

        // set func button 2
        self.templateView.setNavFuncButton2Text(str: constLocal.funcButton2Text.rawValue)
        self.templateView.setNavFuncButton2Image(str: "open_window")

        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton1), button: self.templateView.navFuncButton1View)
        gestureParts().uiViewGestureInit(target: self, action: #selector(self.didClickFuncButton2), button: self.templateView.navFuncButton2View)
    }
    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
        @objc func didClickFuncButton1(gesture: UILongPressGestureRecognizer) {
            
            if gesture.state == .began {
                self.templateView.hideNavFuncButton1Shadow()
            } else if gesture.state == .ended { // optional for touch up event catching
                self.templateView.showNavFuncButton1Shadow()
    //            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.SafetyConfirm.rawValue)
    //            UIApplication.shared.open(NSURL(string: constLocal.SafetyConfirmUrl1.rawValue)! as URL)
            }
            
        }
        
        @objc func didClickFuncButton2(gesture: UILongPressGestureRecognizer) {
            
            if gesture.state == .began {
                self.templateView.hideNavFuncButton2Shadow()
            } else if gesture.state == .ended { // optional for touch up event catching
                self.templateView.showNavFuncButton2Shadow()
    //            commonFunc.shared.sendAnalysticLog(eventName: commonFunc.logKey.click.rawValue + commonFunc.logKey.SafetyConfirm.rawValue)
    //            UIApplication.shared.open(NSURL(string: constLocal.SafetyConfirmUrl2.rawValue)! as URL)
                if let url = URL(string: "jp.co.softbank.smile://Main@SmileArc") {
                    UIApplication.shared.open(url)
                }
            }
            
        }
    
    private enum constLocal: String {
        
        case title      = "Slackアプリインストール"
        case message    = """
        ホームからintune ポータルアプリを開いて、
        ログインをします
        """
        
        case message2    = """
        検索で「Slack」を検索し「インストール」をタップします

        「Slack設定手順」ボタンを押下後に設定してください
        """

        case colorMessage      = """
        !! サインインが必要な場合は、
        OAアカウント or SBKKGmailアドレスを入力 !!
        """

        case funcButton1Text = "Slack設定手順"
        case funcButton2Text = "Slackアプリ"
        
        case SafetyConfirmUrl1     = "http://oa.bb.local/curator_web/oasupport/?jumpurl=http://oa.bb.local/oasupport/%3Fpost_type%3Dpost%26p%3D38258"
    }

}
