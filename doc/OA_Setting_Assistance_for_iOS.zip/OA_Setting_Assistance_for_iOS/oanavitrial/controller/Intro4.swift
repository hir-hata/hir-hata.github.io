import UIKit

class Intro4: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        
        let navMessage          = commonFunc.shared.setSettingIcon(navString: constLocal.settingNavigation.rawValue)
        
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(navMessage)
        
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()

        // use image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "swupdate")

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
    }

    
    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }
    
    private enum constLocal: String {
        
        case title              = "確認事項 3"
        
        case message            = """
        iOSアップデートをダウンロード
        をOFFにしてください
        """
        
        case settingNavigation  = """
        ＞　一般　＞ ソフトウェア・アップデート ＞ 自動アップデート
        """
        
    }
}
