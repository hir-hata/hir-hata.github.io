import UIKit

class Gmail2: UIViewController {

    @IBOutlet weak var templateView: swipeTemplateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set title
        self.templateView.setTitle(str: constLocal.title.rawValue)

        // set message
        let attention           = commonFunc.shared.setAttention(message: constLocal.colorMessage.rawValue)
        
        let attributedString    = NSMutableAttributedString(string: constLocal.message.rawValue, attributes: [ .font : UIFont.systemFont(ofSize: commonFunc.tfFontSize)])
        attributedString.append(commonFunc.shared.addNewLine())
        attributedString.append(attention)
        self.templateView.setLinkText(str: attributedString)
        self.templateView.hyperLinkTextView.sizeToFit()
        
        // show image on this view
        self.templateView.hideImageView(bool: false)
        self.templateView.setImage(str: "gsync")

        // hide nav view
        self.templateView.hideNavView(bool: true)
        
        // show right icon
        self.templateView.hideRightIconLabel(bool: false)
                
    }

    override func viewWillLayoutSubviews() {
        let displayHeight = (UIScreen.main.bounds.size.height - self.view.safeAreaInsets.top - self.view.safeAreaInsets.bottom)
        self.templateView.adjustViewStyle(displayHeight: displayHeight)
    }

    private enum constLocal: String {
        
        case title      = "申請手順"
        case message    = """
        MMSで送信したメールを参照しPCにて、
        以下の申請をします
        
        iPhone設定補助アプリ PC準備情報
        
        4．GoogleSync申請
        """
                
        case colorMessage       = """
        !! 本設定「GoogleSync申請」を
           行わないと、メールが利用出来ません !!
        """
    }

}
