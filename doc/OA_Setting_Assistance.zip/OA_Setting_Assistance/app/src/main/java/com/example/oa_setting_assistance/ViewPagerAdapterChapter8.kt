package com.example.oa_setting_assistance

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapterChapter8(fm: FragmentManager) : FragmentPagerAdapter(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    // for Log
    private val classTag = ViewPagerAdapterChapter8::class.java.simpleName

    override fun getItem(position: Int): Fragment {

        var tabFragment:Fragment     = TabFragment()
        var frBundle        = Bundle()
        var pageIndex  = position + 1

        when (pageIndex) {

            1 -> {
                tabFragment = Chapter7_7()
            }

            2 -> {
                tabFragment = Chapter7_6()
            }

            3 -> {
                tabFragment = Chapter7_5()
            }

            4 -> {
                tabFragment = Chapter7_2()
            }

            5 -> {
                tabFragment = Chapter_slack_install()
            }

            6 -> {
                tabFragment = Chapter_zoom_install()
            }

            7 -> {
                tabFragment = Chapter7_3()
            }

            8 -> {
                tabFragment = Chapter7_8()
            }

//            7 -> {
//                tabFragment = Chapter7_4()
//            }

            9 -> {
                tabFragment = Chapter_survey()
            }

            10 -> {
                tabFragment = ChapterEnd(MAIN_CHAPTER_CODE[8])
            }

            else -> {
                frBundle.putString("message", "Fragment$pageIndex")
                tabFragment.arguments = frBundle
            }

        }

        return tabFragment
    }

    override fun getCount(): Int {
        return 10
    }

    override fun getPageTitle(position: Int): CharSequence? {

        var pageIndex = position + 1

        if(pageIndex == count){
            return "End"
        }
        else {
            return "Page ${(pageIndex)}"
        }

    }


}