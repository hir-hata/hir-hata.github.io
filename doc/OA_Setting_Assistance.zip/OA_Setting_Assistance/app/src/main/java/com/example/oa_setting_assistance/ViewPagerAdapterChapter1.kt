package com.example.oa_setting_assistance

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapterChapter1(fm: FragmentManager) : FragmentPagerAdapter(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    // for Log
    private val classTag = ViewPagerAdapterChapter1::class.java.simpleName

    override fun getItem(position: Int): Fragment {

        var tabFragment:Fragment     = TabFragment()
        var frBundle        = Bundle()
        var pageIndex  = position + 1

        when (pageIndex) {

//            1 -> {
//                tabFragment = Chapter1_1()
//            }

            1 -> {
                tabFragment = Chapter1_5()
            }

            2 -> {
                tabFragment = Chapter1_2()
            }

            3 -> {
                tabFragment = Chapter1_3()
            }

            4 -> {
                tabFragment = Chapter1_4()
            }

            5 -> {
                tabFragment = ChapterEnd(MAIN_CHAPTER_CODE[0])
            }

            else -> {
                frBundle.putString("message", "Fragment$pageIndex")
                tabFragment.arguments = frBundle
            }

        }

        return tabFragment
    }

    override fun getCount(): Int {
        return 5
    }

    override fun getPageTitle(position: Int): CharSequence? {
        var pageIndex = position + 1

        if(pageIndex == count){
            return "End"
        }
        else {
            return "Page ${(pageIndex)}"
        }

    }

}