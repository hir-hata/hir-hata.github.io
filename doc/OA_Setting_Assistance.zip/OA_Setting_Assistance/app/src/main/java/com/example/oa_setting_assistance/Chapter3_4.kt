package com.example.oa_setting_assistance

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter3_4 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter3_4::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }
    }

    override fun setOnClickNavFuncButton1() {
        val intent = Intent()
        intent.action = Settings.ACTION_SETTINGS
        startActivity(intent)
    }

    // copy accuount to clipboard
    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.add_google_account_5 -> {
                currentImage = R.drawable.add_google_account_6
            }
            R.drawable.add_google_account_6 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.add_google_account_5
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Chapter3_4::class.java.simpleName
        val const_title         = "アプリインストール用 アカウント作成 3"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = true
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.setting_icon, "text" to "アカウント確認"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = true

        val const_showDetailTextIcon    = true

        var const_message = """
            「PW」ボタンを押下後、
            コピーされたPWをペーストし、「次へ」をタップします
            
            GooglePlay User01画面が表示されたら、
            「同意する」をタップします
            
            Googleサービス画面が表示されたら、
            下へスライドし「同意する」をタップします
            
            Google Apps Device Policy（端末ポリシー）画面では、
            「スキップ」をタップします
            
            「アカウント」ボタンを押下後、
            「アカウント」をタップし、アカウントの画面に「Google」が
            表示されていることを確認してください
        """.trimIndent()

        var const_bottomMessage = """
        「アカウント確認」ボタンを押下し、<BR>
        以降は画像をタップし手順に従い設定します
        """.trimIndent()

        val const_detailText = """
        「アカウント確認」ボタンを押下後、<BR>
        「アカウント」をタップし、アカウントの画面に「Google」が
        表示されていることを確認してください
        """.trimIndent()

        var const_pw = "20150423"

        var const_alert_message = "パスワードをコピーしました"


    }

}