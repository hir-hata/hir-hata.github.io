package com.example.oa_setting_assistance

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapterChapter3(fm: FragmentManager) : FragmentPagerAdapter(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    // for Log
    private val classTag = ViewPagerAdapterChapter3::class.java.simpleName

    override fun getItem(position: Int): Fragment {

        var tabFragment:Fragment     = TabFragment()
        var frBundle        = Bundle()
        var pageIndex  = position + 1

        when (pageIndex) {

            1 -> {
                tabFragment = Chapter3_1()
            }

            2 -> {
                tabFragment = Chapter3_2()
            }

            3 -> {
                tabFragment = Chapter3_3()
            }

            4 -> {
                tabFragment = Chapter3_4()
            }

            5 -> {
                tabFragment = Chapter3_5()
            }

            6 -> {
                tabFragment = Chapter3_6()
            }

            7 -> {
                tabFragment = Chapter3_7()
            }

            8 -> {
                tabFragment = Chapter3_8()
            }

            9 -> {
                tabFragment = Chapter3_9()
            }

            10 -> {
                tabFragment = Chapter3_10()
            }

            11 -> {
                tabFragment = Chapter3_11()
            }

//            12 -> {
//                tabFragment = Chapter3_12()
//            }
//
//            13 -> {
//                tabFragment = Chapter3_13()
//            }
//
//            14 -> {
//                tabFragment = Chapter3_14()
//            }

            12 -> {
                tabFragment = ChapterEnd("3")
            }

            else -> {
                frBundle.putString("message", "Fragment$pageIndex")
                tabFragment.arguments = frBundle
            }

        }

        return tabFragment
    }

    override fun getCount(): Int {
        return 12
    }

    override fun getPageTitle(position: Int): CharSequence? {

        var pageIndex = position + 1

        if(pageIndex == count){
            return "End"
        }
        else {
            return "Page ${(pageIndex)}"
        }

    }


}