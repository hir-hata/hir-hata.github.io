package com.example.oa_setting_assistance

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapterTutorial(fm: FragmentManager) : FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    // for Log
    private val classTag = ViewPagerAdapterTutorial::class.java.simpleName

    private var pIndex = 0

    override fun getItem(position: Int): Fragment {

        var tabFragment:Fragment     = TabFragment()
        var frBundle        = Bundle()
        var pageIndex  = position + 1

        pIndex = pageIndex

        when (pageIndex) {

            1 -> {
                tabFragment = Tutorial_1()
            }

            2 -> {
                tabFragment = Tutorial_2()
            }

            3 -> {
                tabFragment = Tutorial_3()
            }

            4 -> {
                tabFragment = Tutorial_4()
            }

            5 -> {
                tabFragment = Tutorial_5()
            }

            6 -> {
                tabFragment = ChapterEnd(OPTION_CHAPTER_CODE[0])
            }

            else -> {
                frBundle.putString("message", "Fragment$pageIndex")
                tabFragment.arguments = frBundle
            }

        }

        return tabFragment
    }

    override fun getCount(): Int {
        return 6
    }

    override fun getPageTitle(position: Int): CharSequence? {

        var pageIndex = position + 1

        if(pageIndex == count){
            return "End"
        }
        else {
            return "Page ${(pageIndex)}"
        }

    }

}