package com.example.oa_setting_assistance

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.INVISIBLE
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter1_1 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage)
,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter1_1::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        val androidOS10 = Build.VERSION_CODES.Q
        val ownOSver   = Build.VERSION.SDK_INT

        val messageBodyView = view.findViewById<TextView>(R.id.messageBody)
        val navView = view.findViewById<ConstraintLayout>(R.id.navView)

        // os version check & change text
        if(ownOSver >= androidOS10){
            const_message       = const_os_OK_message
            navView.visibility  = INVISIBLE
            imageView.visibility = INVISIBLE
            bottomMessage.visibility = INVISIBLE
        } else{
            const_message       = const_os_NG_message
        }

        messageBodyView.text = const_message

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }

    }

    private fun callPhone() {

        var number = PHONE_NUMBER[0]

        val devFlag = resources.getBoolean(R.bool.development)

        if(devFlag){
            number = PHONE_NUMBER[1]
        }

        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))

        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            Log.w("callPhone", "permission is not granted")
        }
        else{
            Log.w("callPhone", "permission is granted")
            startActivity(intent)
        }

    }

    // permission request
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {

        // check request code
        if (requestCode != 9434) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            return
        }

        // check permission request
        if (grantResults.any { it != PackageManager.PERMISSION_GRANTED }) {
            // when reuqest is denyed
            Log.w(classTag, "permission request denyed. terminate activity")
            return
        }

        // call phone
        callPhone()
    }

    override fun setOnClickNavFuncButton1() {

        val intent = Intent()
        intent.action = Settings.ACTION_SETTINGS
        startActivity(intent)

//        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CALL_PHONE)
//            != PackageManager.PERMISSION_GRANTED) {
//            // Permission is not granted
//            Log.w(classTag, "permission is not granted")
//
//            AlertDialog.Builder(requireContext())
//                .setMessage("このアプリでの電話の利用を許可しますか？")
//                .setPositiveButton(android.R.string.ok) { _, _ ->
//                    ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CALL_PHONE), 9434)
//                    Log.d(classTag, "dialog select ok")
//                }
//                .setNegativeButton(android.R.string.cancel) { _, _ ->
//                    Log.d(classTag, "dialog select cancel")
//                }
//                .show()
//        }
//        else{
//            Log.d(classTag, "permission is granted")
//            callPhone()
//        }
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }
    private fun changeImage() {

        when (currentImage) {
            R.drawable.os_update_1 -> {
                currentImage = R.drawable.os_update_2
            }
            R.drawable.os_update_2 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.os_update_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Chapter1_1::class.java.simpleName
        val const_title         = "AndroidOS 確認"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = true
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.setting_icon, "text" to "設定を開く"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )
        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = false

        var const_message = """
        OS確認をします
        """.trimIndent()

        var const_bottomMessage = """
        「設定を開く」ボタンを押下します<BR>
        <BR>
        システム ＞ 詳細設定 ＞システム アップデート<BR>
        をタップします<BR>
        <BR>
        以降は画面内の指示に従い、進めてください
        """.trimIndent()

        val const_os_OK_message = """
        AndroidのOSバージョンは問題ありません
        このまま手順を進めてください
        """.trimIndent()

        val const_os_NG_message = """
        AndroidのバージョンはOS9となっていますので、
        OS10以上へバージョンアップしてください
        """.trimIndent()

    }
}
