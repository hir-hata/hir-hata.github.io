package com.example.oa_setting_assistance

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.takusemba.spotlight.Spotlight
import com.takusemba.spotlight.Target
import com.takusemba.spotlight.shape.RoundedRectangle
import kotlinx.android.synthetic.main.fragment_swipe_template.*


class Tutorial_3 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Tutorial_3::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    // for spotlight
    private var spotlight : Spotlight? = null
    private var targets = ArrayList<Target>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }

    }

    fun makeTarget(layerType : Int, target : View, description : String, next: Boolean) : Target {

        // 1st coach mark
        val rootContext = ConstraintLayout(context)
        var coachLayout = layoutInflater.inflate(layerType, rootContext)
        val coachTargetView = target
        val coachInfo = Target.Builder()
            .setAnchor(coachTargetView)
            .setShape(RoundedRectangle(coachTargetView.height.toFloat() + 10f, coachTargetView.width.toFloat() + 10f, 10f))
            .setOverlay(coachLayout)
            .build()

        // disable child view
        coachLayout.setOnClickListener {
        }

        coachLayout.findViewById<TextView>(R.id.coach_mark_text).text = description

        val nextTarget      = View.OnClickListener { spotlight!!.next() }
        val closeSpotlight  = View.OnClickListener { spotlight!!.finish() }

        if(next) {
            coachLayout.findViewById<View>(R.id.close_target).setOnClickListener(nextTarget)
        }
        else{
            coachLayout.findViewById<View>(R.id.close_target).setOnClickListener(closeSpotlight)
        }

        return coachInfo

    }

    fun showSpotlight(){

    //    targets.add(makeTarget(R.layout.coach_mark_target_center, templateView!!.findViewById<View>(R.id.titleLabel), const_coach_message1, true))
        targets.add(makeTarget(R.layout.coach_mark_target_center, templateView!!.findViewById<View>(R.id.oapcLabel), const_coach_message2, true))
        targets.add(makeTarget(R.layout.coach_mark_target_bottom, templateView!!.findViewById<View>(R.id.imageView), const_coach_message3, true))
        targets.add(makeTarget(R.layout.coach_mark_target_center, templateView!!.findViewById<View>(R.id.helpIcon), const_coach_message4, true))
        targets.add(makeTarget(R.layout.coach_mark_target_center, templateView!!.findViewById<View>(R.id.navBackView), const_coach_message5, true))
        targets.add(makeTarget(R.layout.coach_mark_target_center, templateView!!.findViewById<View>(R.id.opencloseImageBack), const_coach_message6, false))

        // create spotlight
        spotlight = Spotlight.Builder(activity as Activity)
            .setTargets(targets)
            .setBackgroundColor(R.color.deepBlackTr)
            .setDuration(100L)
            .setAnimation(DecelerateInterpolator(2f))
            .build()

        spotlight!!.start()

    }


    override fun onResume() {
        super.onResume()

        Log.d(classTag,"onResume : ${classTag}")
        showSpotlight()
    }

    override fun onPause() {
        super.onPause()
        Log.d(classTag,"onPause : ${classTag}")
        spotlight!!.finish()

//        // always open nav
//        var preferences =
//            this.requireActivity().getSharedPreferences(const_class, Context.MODE_PRIVATE)
//
//        var editor = preferences.edit()
//        editor?.putBoolean(const_userAgentKey, false)
//        editor?.apply()
//
//        swipeTemplate.openClose()

    }

    override fun setOnClickNavFuncButton1() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {

    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.tutorial_sample_image_1 -> {
                currentImage = R.drawable.tutorial_sample_image_2
            }
            R.drawable.tutorial_sample_image_2 -> {
                currentImage = R.drawable.tutorial_sample_image_3
            }
            R.drawable.tutorial_sample_image_3 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.tutorial_sample_image_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Tutorial_3::class.java.simpleName
        val const_title         = "チュートリアル3"
        val const_showPCicon    = true
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = true
        val const_numOfNavIcon  = 3
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.app_open_icon, "text" to "Button 3"),
            mapOf("imageId" to R.drawable.setting_icon, "text" to "Button 2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "Button 1")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = true
        val const_showDetailTextIcon    = true

        var const_message = """
            スワイプして次のページに進みましょう
        """.trimIndent()

        var const_bottomMessage = """
            スワイプして次のページに進みましょう
        """.trimIndent()

        val const_detailText = """
            こちらにも手順が文章で表示されます
        """.trimIndent()

        var const_coach_message1 = """
            この手順のタイトルです
        """.trimIndent()

        var const_coach_message2 = """
            PCでの作業の場合は、
            このマークが表示されますので、
            PCで設定を行ってください
        """.trimIndent()

        var const_coach_message3 = """
            一部の画像はタップをすることで
            画像の切り替えが行えます
        """.trimIndent()

        var const_coach_message4 = """
            画像でわかりにくい場合には
            こちらから設定手順を文書で確認ができます
        """.trimIndent()

        var const_coach_message5 = """
            手順によってはこちらに
            追加のボタンが表示されます
        """.trimIndent()

        var const_coach_message6 = """
            ボタンにより説明が見えない場合には
            こちらをタップすることで
            表示・非表示にすることができます
        """.trimIndent()

    }

}