package com.example.oa_setting_assistance

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter4_3 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter4_3::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }
    }

    override fun setOnClickNavFuncButton1() {
//        // update device policy
//        val intent = Intent(Intent.ACTION_VIEW).apply {
//
//            data = Uri.parse(
//                "https://play.google.com/store/apps/details?id=com.google.android.apps.enterprise.dmagent"
//            )
//            setPackage("com.android.vending")
//        }
//        startActivity(intent)
        val clipboard = requireActivity().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        val clip = ClipData.newPlainText("email", const_server)
        clipboard.setPrimaryClip(clip)

        val toast = Toast.makeText(requireContext(), const_alert_message, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.dp_setting_1 -> {
                currentImage = R.drawable.dp_setting_2
            }
            R.drawable.dp_setting_2 -> {
                currentImage = R.drawable.dp_setting_3
            }
            R.drawable.dp_setting_3 -> {
                currentImage = R.drawable.dp_setting_4
            }
            R.drawable.dp_setting_4 -> {
                currentImage = R.drawable.dp_setting_5
            }
            R.drawable.dp_setting_5 -> {
                currentImage = R.drawable.dp_setting_6
            }
            R.drawable.dp_setting_6 -> {
                currentImage = R.drawable.dp_setting_7
            }
            R.drawable.dp_setting_7 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.dp_setting_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Chapter4_3::class.java.simpleName
        val const_title         = "Device Policy コピー"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = true
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.copy_icon, "text" to "Device Policy コピー"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = true
        val const_showDetailTextIcon    = true

        var const_message = """
        """.trimIndent()

        var const_bottomMessage = """
        「Device Policyコピー」ボタンを押下して、<BR>
    　  ホーム画面上のPlayストアを開き、検索箇所に貼りつけます<BR>
        <BR>
        以降は画像をタップし手順に従い設定してください<BR>
        <BR><font color=#ff0000><b>
        !! ダウンロードを保留していますが表示されたら、
        「×」をタップ後に「更新」をタップするを繰り返します !!</b></font>
        <BR>
        <BR>
        <font color=#ff0000><b>
        !! 適用を確定～が表示されたら、「適用」をタップしてください !!
        <BR>
        <BR>
        !!「Device Policy更新」ボタンを押下しても、<BR>
        Google Apps Device Policyが表示されない場合は<BR>
        Google Playの検索バー内の右上をタップしアカウントを切替ください !!
        <BR>
        <BR>
        </b></font>
        """.trimIndent()

        val const_detailText = """
        「Device Policyコピー」ボタンを押下して、<BR>
        ホーム画面上のPlayストアを開き、検索箇所に貼りつけます<BR>
        <BR>
        Google Apps Device Policyが開いたら「更新」をタップします<BR>
        <BR>
        <font color=#ff0000><b>!! ダウンロードを保留していますが表示されたら、<BR>
        「×」をタップ後に「更新」をタップするを繰り返します  !!</b></font><BR>
        <BR>
        更新が完了したら、「開く」をタップしてください<BR>
        <BR>
        「次へ」「許可」とタップします<BR>
        <BR>
        端末管理アプリの有効化が表示されたら、<BR>
        下へスライドし「この端末アプリを有効にする」<BR>
        「適用」とタップします<BR>
        <BR>
        <font color=#ff0000><b>!! 適用を確定～が表示されたら、「適用」をタップしてください !!
        <BR>
        <BR>
        !!「Device Policy更新」ボタンを押下しても、<BR>
        Google Apps Device Policyが表示されない場合は<BR>
        Google Playの検索バー内の右上をタップし<BR>
        アカウントを切替ください !!</b></font>
        <BR>
        <BR>
        """.trimIndent()

        var const_server = "Google Apps Device Policy"
        var const_alert_message = "検索用文字列をコピーしました"
    }

}