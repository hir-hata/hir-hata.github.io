package com.example.oa_setting_assistance

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context.CLIPBOARD_SERVICE
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter1_5 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter1_5::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

    }

    override fun setOnClickNavFuncButton1() {
        val intent = Intent()
        intent.action = Settings.ACTION_ACCESSIBILITY_SETTINGS
        startActivity(intent)
    }

    // copy accuount to clipboard
    override fun setOnClickNavFuncButton2() {
        val clipboard = requireActivity().getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

        val clip = ClipData.newPlainText("email",const_account)
        clipboard.setPrimaryClip(clip)

        val toast = Toast.makeText(requireContext(), const_alert_message, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    // constant
    companion object {

        val const_class         = Chapter1_5::class.java.simpleName
        val const_title         = "3ボタン復活手順"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.show_3buttons
        val const_showNavFooter = true
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.setting_icon, "text" to "ユーザ補助"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "メールアドレスコピー"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = false
        val const_showDetailTextIcon    = false

        var const_message = """
        設定時の利便性向上の為、<BR>
        ボタン（戻る・ホーム・履歴）復活させます<BR>
        <BR>
        「ユーザー補助」ボタンを押下し、<BR>
        「システムナビゲーション」をタップ後、<BR>
        「3ボタンナビゲーション」をタップしてください<BR>
        <BR>
        <font color=#ff0000><b>!! ジェスチャーナビゲーションをご利用されたい方は、
        「戻る」の際に「左側または右側からスワイプ」ください !!</b></font>
        """.trimIndent()

        var const_bottomMessage = """
        """.trimIndent()

        val const_detailText = """
        「メールアドレスコピー」ボタンを押下後に、「アカウント追加」ボタンを押下します<BR>
        <BR>
        アカウント追加が表示されたら、<BR>
        「Google」を選択しログイン画面が出たら<BR>
        コピーされたアドレスをメールアドレスの項目に<BR>
        ペーストし、「次へ」をタップします
        """.trimIndent()

        var const_account = "gplayuser01@f.dogslabo.com"
        var const_alert_message = "メールアドレスをコピーしました"
    }

}