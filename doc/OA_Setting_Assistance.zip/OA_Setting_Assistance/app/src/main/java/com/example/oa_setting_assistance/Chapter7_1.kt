package com.example.oa_setting_assistance

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter7_1 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter7_1::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        var bottomMessage = view.findViewById<TextView>(R.id.bottomMessage)
        bottomMessage.setTextIsSelectable(true)

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }
    }

    override fun setOnClickNavFuncButton1() {

        // open wifi-setting
        val intent = Intent(Intent.ACTION_VIEW).apply {

            data = Uri.parse(
                "https://sbgapp.bizconcier-dm.com/"
            )
        }
        startActivity(intent)
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.smile_app_install_1 -> {
                currentImage = R.drawable.smile_app_install_2
            }
            R.drawable.smile_app_install_2 -> {
                currentImage = R.drawable.smile_app_install_3
            }
            R.drawable.smile_app_install_3 -> {
                currentImage = R.drawable.smile_app_install_4
            }
            R.drawable.smile_app_install_4 -> {
                currentImage = R.drawable.smile_app_install_5
            }
            R.drawable.smile_app_install_5 -> {
                currentImage = R.drawable.smile_app_install_6
            }
            R.drawable.smile_app_install_6 -> {
                currentImage = R.drawable.smile_app_install_7
            }
            R.drawable.smile_app_install_7 -> {
                currentImage = R.drawable.smile_app_install_8
            }
            R.drawable.smile_app_install_8 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.smile_app_install_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Chapter7_1::class.java.simpleName
        val const_title         = "Smileアプリインストール"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = true
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.open_window, "text" to "ビジネスコンシェル起動"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = true
        val const_showDetailTextIcon    = true

        var const_message = """
        """.trimIndent()

        var const_bottomMessage = """
        「ビジネスコンシェル起動」ボタンを押下し、<BR>以下を入力します<BR>
        <BR> 
        DMコード：M5100001<BR>
        ログインID：user388<BR>
        パスワード：9996<BR>
        <BR>
        以降は画像をタップし手順に従い設定します
        """.trimIndent()

        val const_detailText = """
        「ビジネスコンシェル起動」ボタンを押下し、<BR>以下を入力します<BR>
        <BR>
        DMコード：M5100001<BR>
        ログインID：user388<BR>
        パスワード：9996<BR>
        <BR>
        SmileAndroid.apk。「ダウンロード」をタップします<BR>
        <BR>
        SmileAndroid.apk。「開く」をタップし、<BR>
        「設定」をタップ後「この提供元のアプリを許可」をタップします<BR>
        <BR>
        ＜（戻る）をタップし、<BR>
        「インストール」「開く」をタップし後<BR>
        smileがインストールされたことを確認してください
        """.trimIndent()
    }

}