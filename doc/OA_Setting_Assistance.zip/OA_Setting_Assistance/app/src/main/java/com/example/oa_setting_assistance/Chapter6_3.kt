package com.example.oa_setting_assistance

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context.CLIPBOARD_SERVICE
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter6_3 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter6_3::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var clipboard: ClipboardManager? = null

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }

        clipboard = requireActivity().getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

    }

    override fun setOnClickNavFuncButton1() {

        val clip = ClipData.newPlainText("emc-url2",const_url2)
        clipboard!!.setPrimaryClip(clip)

        val toast = Toast.makeText(requireContext(), const_alert_message2, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()

    }

    override fun setOnClickNavFuncButton2() {

        val clip = ClipData.newPlainText("emc-url1",const_url1)
        clipboard!!.setPrimaryClip(clip)

        val toast = Toast.makeText(requireContext(), const_alert_message1, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()

    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.emc_call_setup_1 -> {
                currentImage = R.drawable.emc_call_setup_2
            }
            R.drawable.emc_call_setup_2 -> {
                currentImage = R.drawable.emc_call_setup_3
            }
            R.drawable.emc_call_setup_3 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.emc_call_setup_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Chapter6_3::class.java.simpleName
        val const_title         = "安否確認アプリ設定"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = true
        val const_numOfNavIcon  = 2
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.copy_icon, "text" to "URL2コピー"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "URL1コピー"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = true
        val const_showDetailTextIcon    = true

        var const_message = """
        安否確認アプリを起動します<BR>
        <BR>
       「URL1コピー」ボタンを押下し、<BR>
        安否確認アプリ内の「URL(1)」にペースト<BR>
        <BR>
       「URL2コピー」ボタンを押下し、<BR>
        安否確認アプリ内の「URL(2)」にペーストします<BR>
        """.trimIndent()

        var const_bottomMessage = """
        安否確認アプリを起動し、<BR>
        以降は画像をタップし手順に従い設定してください<BR>
        <BR>
        <font color=#ff0000><b>※初回ログインID・PWは、ともに7桁の社員番号<BR>
        <BR>
        ※2回目以降のログインの場合、<BR>
        PWは各自で任意に設定したパスワード</b></font>
        <BR><BR><BR>
        """.trimIndent()

        val const_detailText = """
        安否確認アプリを起動します<BR>
        <BR>
        「URL1コピー」ボタンを押下し、<BR>
        安否確認アプリ内の「URL(1)」にペースト<BR>
        「URL2コピー」ボタンを押下し、<BR>
        安否確認アプリ内の「URL(2)」にペーストします<BR>
        <BR>
        ID,PWを入力しログインします<BR>
        <BR>
        <font color=#ff0000><b>※初回ログインID・PWは、ともに7桁の社員番号<BR>
        <BR>
        ※2回目以降のログインの場合、<BR>
        　PWは各自で任意に設定したパスワード</b></font>
        """.trimIndent()
    }

    var const_url1 = "asp4.emc-call.jp/softbank"
    var const_url2 = "asp4.emc-call2nd.jp/softbank"

    var const_alert_message1 = "URL1をコピーしました"
    var const_alert_message2 = "URL2をコピーしました"

}