package com.example.oa_setting_assistance

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import com.google.firebase.analytics.FirebaseAnalytics

class CommonFun private constructor() {

    // singleton
    companion object {

        // for log
        private val classTag = CommonFun::class.java.simpleName

        // for invoker activity
        private lateinit var context: Context

        // for firebase analytics
        private lateinit var firebaseAnalytics: FirebaseAnalytics
        private val bundle = Bundle()

        fun setContext(context: Context) {
            this.context = context
        }

        // send log to firebase
        fun sendLog(msg: String) {

            // send log to on / off flag
            val sendFlag = this.context.resources.getBoolean(R.bool.firebase_Analytics)

            // add string "Dev"
            val devFlag = this.context.resources.getBoolean(R.bool.development)

            var key = msg

            Log.d(classTag, "send sendFlag $sendFlag ")
            Log.d(classTag, "send devFlag $devFlag")

            // check if bool of firebase_Analytics is true
            if (sendFlag) {

                Log.d(classTag, "send Log $msg to firebase")

                // check if bool of development is true
                if (devFlag) {
                    key = "Dev_$msg"
                }

                // init firebase
                this.firebaseAnalytics = FirebaseAnalytics.getInstance(context)

                // send log to firebase
                this.firebaseAnalytics.logEvent(key, bundle)

            } else {
                Log.d(classTag, "sendLog is disable.")
            }
        }

    }

}

// check network status
//    val cm    = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//
//    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//
//        val networkCapabilities = cm.activeNetwork
//        val activeNw = cm.getNetworkCapabilities(networkCapabilities)
//
//        result = when {
//            activeNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
//            activeNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
//            activeNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
//            else -> "UNKNOWN"
//        }
//    }

// check package
//Log.d(classTag, "OS version : ${Build.VERSION.SDK_INT}")
//Log.d(classTag, "OS version sample : ${Build.VERSION_CODES.P}")
//
//val pm = packageManager
//val pckInfoList = pm.getInstalledPackages(
//    PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES
//)
//
//for (pckInfo in pckInfoList) {
//    if (pm.getLaunchIntentForPackage(pckInfo.packageName) != null) {
//
//        val packageName = pckInfo.packageName
//        val className =
//            pm.getLaunchIntentForPackage(pckInfo.packageName)!!.component!!.className + ""
//
//        Log.i("起動可能なパッケージ名", packageName)
//        Log.i("起動可能なクラス名", className)
//
//    } else {
////                Log.i("----------起動不可能なパッケージ名", pckInfo.packageName)
//    }
//}
//
///**
// * アプリのインストール確認
// * @param appPackage アプリのパッケージ名
// * @return アプリインストールの有無
// */
//fun isAppInstalled(appPackage: String?): Boolean {
//    val myIntent = packageManager.getLaunchIntentForPackage(appPackage!!)
//    return myIntent != null
//}
//
//// check if bcagent is existed
//val existApp = isAppInstalled("jp.co.axseed.bcagent")
//
//Log.i("classTag", "this app installed : ${existApp}")
