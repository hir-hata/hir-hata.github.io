package com.example.oa_setting_assistance

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class Chapter1_4 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter1_4::class.java.simpleName

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

    }

    override fun setOnClickNavFuncButton1() {
        Log.d(classTag, "navFuncButton1")
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    // constant
    companion object {

        val const_class         = Chapter1_4::class.java.simpleName
        val const_title         = "PCでの事前準備 2"
        val const_showPCicon    = true
        val const_showImageView = false
        val const_imageResource = R.drawable.android3
        val const_showNavFooter = false
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.phone_icon, "text" to "電話する"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )
        val const_showEndChapterButton  = false
        val const_showBottomMessage     = false
        val const_hideUpperMessage      = false

        var const_message = """
        PCでの事前準備 1で送付したメールを開きます<BR>
        <BR>
        件名がなしで送信されている為、<BR>
        「Android設定補助アプリ PC準備情報」を<BR>
        メール内検索してください<BR>
        <BR>
        メール内手順の以下を実施します<BR>
        1．VPN利用申請＆yellow接続用MACアドレス申請<BR>
        <BR>
        <font color=#ff0000><b>!! VPN証明書の発行に1週間程かかる場合が<BR>
        ありますので、本申請をお早目に対応ください !!</b></font><BR>
        <BR>
      　送信したメール内の<BR>
        「VPN設定」と「Gmail設定」項目は、<BR>
      　本アプリ内の各設定項目時に対応してください
        """.trimIndent()

        var const_bottomMessage = ""
    }

}