package com.example.oa_setting_assistance

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.takusemba.spotlight.Spotlight
import com.takusemba.spotlight.Target
import com.takusemba.spotlight.shape.RoundedRectangle
import kotlinx.android.synthetic.main.fragment_swipe_template.*


class Tutorial_5 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Tutorial_5::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    // for spotlight
    private var spotlight : Spotlight? = null
    private var targets = ArrayList<Target>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }

    }

    fun makeTarget(layerType : Int, target : View, description : String, next: Boolean) : Target {

        // 1st coach mark
        val rootContext = ConstraintLayout(context)
        var coachLayout = layoutInflater.inflate(layerType, rootContext)
        val coachTargetView = target
        val coachInfo = Target.Builder()
            .setAnchor(coachTargetView)
            .setShape(RoundedRectangle(coachTargetView.height.toFloat() + 10f, coachTargetView.width.toFloat() + 10f, 10f))
            .setOverlay(coachLayout)
            .build()

        // disable child view
        coachLayout.setOnClickListener {
        }

        coachLayout.findViewById<TextView>(R.id.coach_mark_text).text = description

        val nextTarget      = View.OnClickListener { spotlight!!.next() }
        val closeSpotlight  = View.OnClickListener { spotlight!!.finish() }

        if(next) {
            coachLayout.findViewById<View>(R.id.close_target).setOnClickListener(nextTarget)
        }
        else{
            coachLayout.findViewById<View>(R.id.close_target).setOnClickListener(closeSpotlight)
        }

        return coachInfo

    }

    fun showSpotlight(){

        targets.add(makeTarget(R.layout.coach_mark_target_bottom, templateView!!.findViewById<View>(R.id.imageView), const_coach_message1, false))

        // create spotlight
        spotlight = Spotlight.Builder(activity as Activity)
            .setTargets(targets)
            .setBackgroundColor(R.color.deepBlackTr)
            .setDuration(100L)
            .setAnimation(DecelerateInterpolator(2f))
            .build()

        spotlight!!.start()

    }


    override fun onResume() {
        super.onResume()

        Log.d(classTag,"onResume : ${classTag}")
        showSpotlight()
    }

    override fun onPause() {
        super.onPause()
        Log.d(classTag,"onPause : ${classTag}")
        spotlight!!.finish()
    }

    override fun setOnClickNavFuncButton1() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.tutorial_sample_image_1 -> {
                currentImage = R.drawable.tutorial_sample_image_2
            }
            R.drawable.tutorial_sample_image_2 -> {
                currentImage = R.drawable.tutorial_sample_image_3
            }
            else -> {
                currentImage = R.drawable.tutorial_sample_image_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Tutorial_5::class.java.simpleName
        val const_title         = "チュートリアル5"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tutorial_3
        val const_showNavFooter = false
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.app_open_icon, "text" to "ボタン1"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = false

        var const_message = """
            スワイプして次のページに進みましょう
            <BR>
        """.trimIndent()

        var const_bottomMessage = """
        """.trimIndent()

        var const_coach_message1 = """
            別の画面が起動した場合には
            左下の < ボタンから戻ることができます
        """.trimIndent()

    }

}