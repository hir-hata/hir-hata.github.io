package com.example.oa_setting_assistance

import android.Manifest
import android.animation.Animator
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.INVISIBLE
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat.checkSelfPermission
import androidx.core.content.ContextCompat.getColor
import com.google.firebase.analytics.FirebaseAnalytics
import kotlinx.android.synthetic.main.activity_top.*
import kotlinx.android.synthetic.main.fragment_header_template.*
import kotlin.math.floor

// list item class
class IndexRecord(val title : String, val intent : Intent, var indexImageId : Int, var checkImageId : Int, val enable  : Boolean, val check : Boolean)

class TopActivity : AppCompatActivity() {

    // for firebase
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    // for Log
    private val classTag = TopActivity::class.java.simpleName

    private var enableChapter:BooleanArray? = null
    private var dataStore: SharedPreferences? = null

    // number of menu to do OA Setting
    private val countOfMenu = MAIN_CHAPTER_TITLE.size

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_top)

        val listView = findViewById<ListView>(R.id.customList)

        resources.getBoolean(R.bool.firebase_Analytics)
        /*** from : get Shared Preferences ***/

        /*** get user stored information ***/
        dataStore = getSharedPreferences("UserDefault", Context.MODE_PRIVATE)

        enableChapter = booleanArrayOf(
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[0]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[1]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[2]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[3]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[4]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[5]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[6]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[7]}", false),
            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[8]}", false)
//            ,
//            dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[9]}", false)
        )

        /*** to : get Shared Preferences ***/

        /*** header text setting ***/
        if(resources.getBoolean(R.bool.development)){
            header.text = resources.getString(R.string.app_title) + "(TEST Mode)";
        }

        /*** progress bar setting ***/

        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        progressBar.max = 100

        val ratio = setRatio()
        onProgressAnimation(ratio)

        /*********/

        /** menu list **/
        val mainIntent = Intent(applicationContext, TabSwipeBase::class.java)

        val indexRecordList = arrayListOf<IndexRecord>()

        indexRecordList.add(
            IndexRecord(OPTION_CHAPTER_TITLE[0], mainIntent, R.drawable.beginner, R.drawable.transparent, enable = true, check = true)
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[0], mainIntent, R.drawable.number_sans_green_0, R.drawable.check, enable = true, check = enableChapter!![0])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[1], mainIntent, R.drawable.number_sans_green_1, R.drawable.check, enable = enableChapter!![0], check = enableChapter!![1])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[2], mainIntent, R.drawable.number_sans_green_2, R.drawable.check, enable = enableChapter!![1], check = enableChapter!![2])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[3], mainIntent, R.drawable.number_sans_green_3, R.drawable.check, enable = enableChapter!![2], check = enableChapter!![3])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[4], mainIntent, R.drawable.number_sans_green_4, R.drawable.check, enable = enableChapter!![3], check = enableChapter!![4])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[5], mainIntent, R.drawable.number_sans_green_5, R.drawable.check, enable = enableChapter!![4], check = enableChapter!![5])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[6], mainIntent, R.drawable.number_sans_green_6, R.drawable.check, enable = enableChapter!![5], check = enableChapter!![6])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[7], mainIntent, R.drawable.number_sans_green_7, R.drawable.check, enable = enableChapter!![6], check = enableChapter!![7])
        )

        indexRecordList.add(
            IndexRecord(MAIN_CHAPTER_TITLE[8], mainIntent, R.drawable.number_sans_green_8, R.drawable.check, enable = enableChapter!![7], check = enableChapter!![8])
        )

//        indexRecordList.add(
//            IndexRecord(MAIN_CHAPTER_TITLE[8], mainIntent, R.drawable.number_sans_green_8, R.drawable.check, enable = enableChapter!![7], check = enableChapter!![8])
//        )
//
//        indexRecordList.add(
//            IndexRecord(MAIN_CHAPTER_TITLE[9], mainIntent, R.drawable.number_sans_green_9, R.drawable.check, enable = enableChapter!![8], check = enableChapter!![9])
//        )

        indexRecordList.add(
            IndexRecord(OPTION_CHAPTER_TITLE[1], mainIntent, R.drawable.power_menu, R.drawable.transparent, enable = true, check = true)
        )

        indexRecordList.add(
            IndexRecord(OPTION_CHAPTER_TITLE[2], mainIntent, R.drawable.phone_menu, R.drawable.transparent, enable = true, check = true)
        )

        /***** from : set value to list view *******/
        val arrayAdapter = MyArrayAdapter(this, 0).apply {
            indexRecordList.forEachIndexed { index, indexRecord ->
                add(checkIndexRecord(indexRecord, index))
            }
        }

        listView.adapter = arrayAdapter
        /***** to : set value to list view *******/


        /***** from : click event listener *******/
        // listView.setOnItemClickListener { parent, view, position, id ->
        listView.setOnItemClickListener { _, _, position, _ ->

            CommonFun.setContext(this)
            var logKey = LOG_HEADER[1]

            // tap restart
            if(indexRecordList[position].indexImageId == R.drawable.power_menu) {
                Log.d(classTag, "power_menu")

                logKey += OPTION_CHAPTER_CODE[1]
                CommonFun.sendLog(logKey)

                // get layout
                val view = layoutInflater.inflate(R.layout.custom_dialog2, null)

                // set dialog title
                view.findViewById<TextView>(R.id.dialog_title).text = DIALOG_MESSAGE[0]

                // show dialog
                AlertDialog.Builder(this)
                    .setView(view)
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        Log.d(classTag, "dialog select ok : ${enableChapter!!.size}")
                        logKey = "${LOG_HEADER[2]}${OPTION_CHAPTER_CODE[1]}"
                        CommonFun.sendLog(logKey)
                        resetChapter()
                    }
                    .setNegativeButton(android.R.string.cancel) { _, _ ->
                        Log.d(classTag, "dialog select cancel")
                    }
                    .show()

            }
            // tap inquiry
            else if(indexRecordList[position].indexImageId == R.drawable.phone_menu){

                logKey += OPTION_CHAPTER_CODE[2]
                CommonFun.sendLog(logKey)

                if (checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED) {
                    // Permission is not granted
                    Log.w(classTag, "permission is not granted")

                    AlertDialog.Builder(this)
                        .setMessage("このアプリでの電話の利用を許可しますか？")
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 9434)
                            Log.d(classTag, "dialog select ok")
                        }
                        .setNegativeButton(android.R.string.cancel) { _, _ ->
                            Log.d(classTag, "dialog select cancel")
                        }
                        .setCancelable(false)
                        .show()
                }
                else{
                    Log.d(classTag, "permission is granted")

                    // get layout
                    val view = layoutInflater.inflate(R.layout.custom_dialog2, null)

                    // set dialog title
                    view.findViewById<TextView>(R.id.dialog_title).text = DIALOG_MESSAGE[1]

                    // show dialog
                    AlertDialog.Builder(this)
                        .setView(view)
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            logKey = "${LOG_HEADER[2]}${OPTION_CHAPTER_CODE[2]}"
                            CommonFun.sendLog(logKey)
                            callPhone()
                        }
                        .setNegativeButton(android.R.string.cancel) { _, _ ->
                        }
                        .show()
                }
            }
            else if(!indexRecordList[position].enable) {
                Log.d(classTag, "do nothing")
            }
            else {

                logKey += if(position==0){
                    OPTION_CHAPTER_CODE[0]
                } else {
                    MAIN_CHAPTER_CODE[position - 1]
                }

                CommonFun.sendLog(logKey)

                indexRecordList[position].intent.putExtra("pageIndex",position.toString())
                startActivity(indexRecordList[position].intent)
                overridePendingTransition(R.anim.in_right, R.anim.out_left)
            }
        }
        /***** from : click event listener *******/

        // when first launch app, show dialog to
        if(ratio == 0){

            // get first launch status
            val firstLaunch = dataStore!!.getBoolean(OTHER_CONSTANTS[0], true)

            // check first launch
            if(firstLaunch){

                // change first launch flag
                dataStore!!.edit().putBoolean(OTHER_CONSTANTS[0], false)
                    .apply()

                // get layout
                val view = layoutInflater.inflate(R.layout.custom_dialog4, null)

                // set dialog title and text
                view.findViewById<TextView>(R.id.dialog_title).text = DIALOG_MESSAGE[3]
                view.findViewById<TextView>(R.id.scrolltext).text = DIALOG_MESSAGE[4]

                // show dialog
                AlertDialog.Builder(this)
                    .setView(view)
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        Log.d(classTag, "dialog select ok : ${enableChapter!!.size}")

                        // send Log to firebase
                        val logKey = "${LOG_HEADER[2]}${OTHER_CONSTANTS[0]}"
                        CommonFun.sendLog(logKey)

                        // open tutorial
                        indexRecordList[0].intent.putExtra("pageIndex",0.toString())
                        startActivity(indexRecordList[0].intent)
                        overridePendingTransition(R.anim.in_right, R.anim.out_left)
                    }
                    .setNegativeButton(android.R.string.cancel) { _, _ ->
                        // do nothing
                    }
                    .setCancelable(false)
                    .show()
            }
        }
        else{
            // do nothing
        }
    }

    // permission request
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {

        // check request code
        if (requestCode != 9434) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            return
        }

        // check permission request
        if (grantResults.any { it != PackageManager.PERMISSION_GRANTED }) {
            // when reuqest is denyed
            Log.w(classTag, "permission request denyed. terminate activity")
            return
        }

        // call phone
        callPhone()
    }

    private fun callPhone() {

        var number = PHONE_NUMBER[0]

        val devFlag = resources.getBoolean(R.bool.development)

        if(devFlag){
            number = PHONE_NUMBER[1]
        }

        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))

        if (checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            Log.w("callPhone", "permission is not granted")
        }
        else{
            Log.w("callPhone", "permission is granted")
            startActivity(intent)
        }

    }

    // check if menu status is enable or disable or current
    private fun checkIndexRecord(indexRecord:IndexRecord, index:Int): IndexRecord {

        // disabled
        if(!indexRecord.enable || indexRecord.indexImageId == R.drawable.phone_menu || indexRecord.indexImageId == R.drawable.power_menu || indexRecord.indexImageId == R.drawable.beginner){

            indexRecord.checkImageId = R.drawable.transparent

            if(!indexRecord.enable) {
                indexRecord.indexImageId = getNumImage("gray", index-1)
            }

        }
        // current menu
        else if(!indexRecord.check) {
            indexRecord.checkImageId = R.drawable.arrow_left_yellow
        }
        // finished menu
        else {
            indexRecord.checkImageId = R.drawable.check
        }

        return indexRecord

    }

    // get number image
    private fun getNumImage(color:String, num: Int): Int{

        return when(color){
            "green" -> when(num){
                1 -> R.drawable.number_sans_green_1
                2 -> R.drawable.number_sans_green_2
                3 -> R.drawable.number_sans_green_3
                4 -> R.drawable.number_sans_green_4
                5 -> R.drawable.number_sans_green_5
                6 -> R.drawable.number_sans_green_6
                7 -> R.drawable.number_sans_green_7
                8 -> R.drawable.number_sans_green_8
                9 -> R.drawable.number_sans_green_9
                else -> R.drawable.number_sans_green_0
            }
            "gray" -> when(num){
                1 -> R.drawable.number_sans_gray_1
                2 -> R.drawable.number_sans_gray_2
                3 -> R.drawable.number_sans_gray_3
                4 -> R.drawable.number_sans_gray_4
                5 -> R.drawable.number_sans_gray_5
                6 -> R.drawable.number_sans_gray_6
                7 -> R.drawable.number_sans_gray_7
                8 -> R.drawable.number_sans_gray_8
                9 -> R.drawable.number_sans_gray_9
                else -> R.drawable.number_sans_gray_0
            }
            "white" -> when(num){
                1 -> R.drawable.number_sans_white_1
                2 -> R.drawable.number_sans_white_2
                3 -> R.drawable.number_sans_white_3
                4 -> R.drawable.number_sans_white_4
                5 -> R.drawable.number_sans_white_5
                6 -> R.drawable.number_sans_white_6
                7 -> R.drawable.number_sans_white_7
                8 -> R.drawable.number_sans_white_8
                9 -> R.drawable.number_sans_white_9
                else -> R.drawable.number_sans_white_0
            }
            else -> R.drawable.appicon
        }

    }

    // calc progress ratio
    private fun setRatio() : Int {

        var done    = 0

        // count up
        for(index in enableChapter!!.indices){
            if(dataStore!!.getBoolean("Chapter${MAIN_CHAPTER_CODE[index]}", false)){
                done += 1
            }
        }

        // calc percent
        val ratio   = (done.toDouble()) / (countOfMenu.toDouble())

        // convert percent to Int
        val number  = (floor((ratio) * 100)).toInt()
        Log.d(classTag, "percentage : $number")

        if(number >= 100){

            // set Image
            findViewById<ImageView>(R.id.highNumImage).setImageResource(getNumImage("white", 1))
            findViewById<ImageView>(R.id.middleNumImage).setImageResource(getNumImage("white", 0))
            findViewById<ImageView>(R.id.lowNumImage).setImageResource(getNumImage("white", 0))

            // change color
            val drawableFull  = getDrawable(R.drawable.progress_bar_full_layout)
            val progress    = findViewById<ProgressBar>(R.id.progressBar)
            progress.progressDrawable   = drawableFull

        }
        else{

            // hide highNum image
            findViewById<ImageView>(R.id.highNumImage).visibility  = INVISIBLE

            // set lowNumber value
            val lowRank = number % 10

            // set Image
            findViewById<ImageView>(R.id.lowNumImage).setImageResource(getNumImage("white", lowRank))

            if(number < 10){

                // hide middleNum image
                findViewById<ImageView>(R.id.middleNumImage).visibility  = INVISIBLE
            }
            else {

                // set middleNumber value
                val middleRank  = (number - lowRank) / 10

                // set Image
                findViewById<ImageView>(R.id.middleNumImage).setImageResource(getNumImage("white", middleRank))
            }

        }

        return number
    }

    // for progress bar animation
    private fun onProgressAnimation(percentage: Int) {
        val animation: Animator =
            ObjectAnimator.ofInt(progressBar, "progress", percentage)
        animation.duration = 1000 // ms
        animation.interpolator = DecelerateInterpolator()
        animation.start()
    }

    private fun resetChapter(){

        // reset value of each chapter to false
        for(index in enableChapter!!.indices){
            //Log.d(classTag, "resetChapter{${index+1}}: ${enableChapter!![index]}")
            //dataStore!!.edit().putBoolean("Chapter${index+1}", false)
            Log.d(classTag, "resetChapter{${MAIN_CHAPTER_CODE[index]}}: ${enableChapter!![index]}")
            dataStore!!.edit().putBoolean("Chapter${MAIN_CHAPTER_CODE[index]}", false)
                .apply()
        }

        // reset value of first launch to true
        dataStore!!.edit().putBoolean(OTHER_CONSTANTS[0], true)
            .apply()

        // back to top page
        val intent = Intent(this, TopActivity::class.java)
        startActivity(intent)
        //overridePendingTransition(R.anim.in_left, R.anim.out_right)

    }

    override fun onBackPressed() {
        // do nothing
    }

}

// view holder for reusing list item
data class ViewHolder(val indexImage: ImageView, val menuTitle: TextView, val checkImage: ImageView, val recordUnderLine : TextView)
//data class ViewHolder(val menuTitle: TextView)

// Array adapter for setting value to custom list
class MyArrayAdapter(context: Context, resource: Int) : ArrayAdapter<IndexRecord>(context, resource) {

    private var inflater : LayoutInflater? = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater?

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val viewHolder : ViewHolder?
        var view = convertView

        // reuse setting
        if (view == null) {

            view        = inflater!!.inflate(R.layout.custom_list, parent, false)
            viewHolder  = ViewHolder(view.findViewById(R.id.indexImage), view.findViewById(R.id.menuTitle), view.findViewById(R.id.checkImage), view.findViewById(R.id.recordUnderLine))
            view.tag    = viewHolder

        } else {
            viewHolder  = view.tag as ViewHolder
        }

        val listItem = getItem(position)
        viewHolder.menuTitle.text   = listItem!!.title

        // text & background color
        if(listItem.enable){
            viewHolder.menuTitle.setTextColor(getColor(context, R.color.deepBlack))
            viewHolder.recordUnderLine.setBackgroundColor(getColor(context, R.color.deepGreen))
            view?.setBackgroundColor(getColor(context, R.color.white))
        }
        else{
            viewHolder.menuTitle.setTextColor(getColor(context, R.color.deepGray))
            viewHolder.recordUnderLine.setBackgroundColor(getColor(context, R.color.disabledGreen))
            view?.setBackgroundColor(getColor(context, R.color.disabledGreen))
        }

        viewHolder.indexImage.setImageResource(listItem.indexImageId)
        viewHolder.checkImage.setImageResource(listItem.checkImageId)

        return view!!
    }
}
