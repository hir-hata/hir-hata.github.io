package com.example.oa_setting_assistance

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import kotlinx.android.synthetic.main.fragment_header_template.*

/**
 * A simple [Fragment] subclass.
 */
class headerTemplate : Fragment() {

    // for Log
    private val classTag = headerTemplate::class.java.simpleName

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_header_template, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        // get element
        val homeIcon    = view.findViewById<ImageView>(R.id.homeIcon)

        // listener of home icon to back to top activity
        homeIcon.setOnClickListener{
            Log.d(classTag, "homeIcon")

            val intent = Intent (activity, TopActivity::class.java)
            startActivity(intent)
            activity?.overridePendingTransition(R.anim.in_left, R.anim.out_right)
        }


    }

    fun setHeaderTitle(title:String){
        Log.d(classTag, "setHeaderTitle : str : ${title}")
        headerTitle.text = title
    }

}
