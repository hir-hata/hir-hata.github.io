package com.example.oa_setting_assistance

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.text.HtmlCompat
import androidx.core.view.isGone
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_swipe_template.*
import kotlinx.android.synthetic.main.fragment_swipe_template.imageView
import kotlinx.android.synthetic.main.fragment_swipe_template.messageBody
import kotlinx.android.synthetic.main.fragment_swipe_template.oapcLabel
import kotlinx.android.synthetic.main.fragment_swipe_template.titleLabel

/**
 * A simple [Fragment] subclass.
 */
open class swipeTemplate(
    ownClass            :String     = const_default,
    chapterTitle        :String     = const_default,
    messageBody         :String     = const_default,
    showImage           :Boolean    = false,
    imageId             :Int        = -1,
    showNavFooter       :Boolean    = false,
    numOfNavButton      :Int        = 3,
    navButtonInfo       :Array<out Map<String, Any>> = arrayOf(
        mapOf("imageId" to -1, "text" to const_default)
    ),
    showPCicon          :Boolean    = false,
    showEndButton       :Boolean    = false,
    showBottomMessage   :Boolean    = false,
    bottomMessageBody   :String     = const_default,
    hideUpperMessage    :Boolean    = false,
    showDetailTextIcon  :Boolean    = false,
    detailTextBody      :String     = const_default
) : Fragment() {

    // param
    private var callerClass             = ownClass
    private var title                   = chapterTitle
    private var message                 = messageBody
    private var showImageFlag           = showImage
    private var imageResource           = imageId
    private var showNavFooterFlag       = showNavFooter
    private var numberOfNavButton       = numOfNavButton
    private var navIconResources        = navButtonInfo
    private var pcIconFlag              = showPCicon
    private var showEndChapterButton    = showEndButton
    private var showMessgeBody2         = showBottomMessage
    private var message2                = bottomMessageBody
    private var hideUpperMessageFlag    = hideUpperMessage
    private var showDetailIcon          = showDetailTextIcon
    private var detailText              = detailTextBody

    // for Log
    private val classTag = swipeTemplate::class.java.simpleName

    private var onClickListener: OnClickListener? = null
    private var openFlag    = false
    private var thisContext = context

    var preferences: SharedPreferences?     = null
    var editor: SharedPreferences.Editor?   = null

    override fun onDetach() {
        super.onDetach()
        thisContext = null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view = inflater.inflate(R.layout.fragment_swipe_template, container, false)

        val titleView   = view.findViewById<TextView>(R.id.titleLabel)
        titleView?.text           = arguments?.getString("title")
        val messageBodyView = view.findViewById<TextView>(R.id.messageBody)
        messageBodyView?.text       = arguments?.getString("messageBody")

        return view

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        Log.d(classTag, "onViewCreated.title is $title , openflag : $openFlag")

        preferences =
            this.requireActivity().getSharedPreferences(callerClass, Context.MODE_PRIVATE)

        editor = preferences!!.edit()

        // set Title
        setTitle(title)

        // set message body
        setMessage(message)

        // image view visibility
        showImageView(showImageFlag)

        // when show imageView, set image
        if(showImageFlag){
            setImageView(imageResource)
        }

        // nav view visibility
        showNavFooter(showNavFooterFlag)

        // when use nav View, set icon image
        if(showNavFooterFlag){
            setNavButtonInfo(navIconResources)
        }

        // PC icon visibility
        showPCicon(pcIconFlag)

        // End Chapter Button visibility
        showEndChapterButton(showEndChapterButton)

        // when use bottom message, show bottom message
        showBottomMessage(showMessgeBody2)

        // set bottom message
        if(showMessgeBody2){
            setBottomMessage(message2)
        }

        // hide upper message
        if(hideUpperMessageFlag){
            hideUpperMessage(hideUpperMessageFlag)
        }

        // detail icon visibility
        if(showMessgeBody2) {
            showDetailTextIcon(showDetailIcon)
        }

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)
        val opencloseImage = view.findViewById<ImageView>(R.id.opencloseImage)

        //***** prepare for changing constraint programmatically *****/

        // get constraint from xml
        val constraintLayout = view.findViewById<ConstraintLayout>(R.id.navView)

        // initialize
        if(showNavFooterFlag) {
            openClose(constraintLayout, true)
        }

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            onClickListener?.setOnClickNavFuncButton1()
            Log.d(classTag, "swipeTemplate_navFuncButton1")
        }

        navFuncButton2.setOnClickListener {
            onClickListener?.setOnClickNavFuncButton2()
            Log.d(classTag, "swipeTemplate_navFuncButton2")
        }

        navFuncButton3.setOnClickListener {
            onClickListener?.setOnClickNavFuncButton3()
            Log.d(classTag, "swipeTemplate_navFuncButton3")
        }

        opencloseImage.setOnClickListener {
            onClickListener?.setOnClickOpenCloseImage()
            openClose(constraintLayout)
        }

        helpIcon.setOnClickListener{
            showDetailTextDialog()
        }

    }

    interface OnClickListener {
        fun setOnClickNavFuncButton1()
        fun setOnClickNavFuncButton2()
        fun setOnClickNavFuncButton3()
        fun setOnClickOpenCloseImage()
    }

    fun openClose(constraintLayout: ConstraintLayout, initFlag:Boolean = false){

        Log.d(classTag, "openClose : params initFlag is ${initFlag}")

        var userAgentOpenClose = preferences!!.getBoolean(const_userAgentKey,true)

        // if it is first time to show, invert boolean to draw nav
        if(initFlag){
            userAgentOpenClose = !userAgentOpenClose
        }

        Log.d(classTag, "openClose : userAgent is $userAgentOpenClose")

        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)

        var openHeight= calcOpenHeight(numberOfNavButton)

        // if nav is open, close nav
        if(userAgentOpenClose){

            // change constraint height
            constraintSet.constrainHeight(R.id.navView, 10)
            constraintSet.constrainHeight(R.id.navBackView, 10)
            constraintSet.applyTo(constraintLayout)

            // hide button
            view?.findViewById<TextView>(R.id.navFuncButton1)?.visibility = INVISIBLE
            view?.findViewById<TextView>(R.id.navFuncButton2)?.visibility = INVISIBLE
            view?.findViewById<TextView>(R.id.navFuncButton3)?.visibility = INVISIBLE

            // change image
            opencloseImage.setImageResource(R.drawable.open_icon)

            if(!initFlag) {
//                openFlag = false
                editor?.putBoolean(const_userAgentKey, false)
                editor?.apply()
                Log.d(classTag, "change user agent : open -> close")
            }
        }
        // if nav is close, open nav
        else{

            Log.d(classTag, "nav is close")

            // change constraint height
            constraintSet.constrainHeight(R.id.navView, 55)
            constraintSet.constrainHeight(R.id.navBackView, openHeight)
            constraintSet.applyTo(constraintLayout)

            // hide button
            view?.findViewById<TextView>(R.id.navFuncButton1)?.visibility = VISIBLE
            view?.findViewById<TextView>(R.id.navFuncButton2)?.visibility = VISIBLE
            view?.findViewById<TextView>(R.id.navFuncButton3)?.visibility = VISIBLE

            // change image
            opencloseImage.setImageResource(R.drawable.close_icon)

            if(!initFlag) {
//                openFlag = true
//                Log.d(classTag, "close -> open prefs : ${openFlag}")
                editor?.putBoolean(const_userAgentKey, true)
                editor?.apply()
                Log.d(classTag, "change user agent : close -> open")
            }
        }

    }

    /**
     * dpからpixelへの変換
     * @param dp
     * @param context
     * @return float pixel
     */
    open fun convertDpToPx(dp: Int, context: Context): Float {
        val metrics: DisplayMetrics = context.resources.displayMetrics
        return dp * metrics.density
    }

    /**
     * pixelからdpへの変換
     * @param px
     * @param context
     * @return float dp
     */
    open fun convertPxToDp(px: Int, context: Context): Float {
        val metrics: DisplayMetrics = context.resources.displayMetrics
        return px / metrics.density
    }

    // calculate nav height
    fun calcOpenHeight(num: Int): Int {

        val padding         = 10
        val buttonHeight    = 50

        val openHeight = ( buttonHeight * num ) + padding * ( num ) + 5

        return convertDpToPx(openHeight, requireContext()).toInt()

    }

    // set title label
    fun setTitle(text:String) {
        titleLabel.text     = text
    }

    // set message body
    fun setMessage(text:String) {
        val htmlText  = HtmlCompat.fromHtml(text, HtmlCompat.FROM_HTML_MODE_COMPACT)
        messageBody.text    = htmlText
    }

    // set message body
    fun setBottomMessage(text:String) {
        val htmlText  = HtmlCompat.fromHtml(text, HtmlCompat.FROM_HTML_MODE_COMPACT)
        bottomMessage.text    = htmlText
    }

    // show or hide oapc icon
    fun showPCicon(flag: Boolean) {

        if(flag) {
            oapcLabel.visibility = VISIBLE
        }
        else{
            oapcLabel.visibility = INVISIBLE
        }

    }

    // show or hide image
    fun showImageView(flag: Boolean) {

        if(flag) {
            imageView.visibility = VISIBLE
        }
        else{
            imageView.visibility = INVISIBLE
        }

    }

    // show or hide image
    fun setImageView(resource: Int) {
        if(resource >= 0) {
            imageView.setImageResource(resource)
        }
    }

    // show or hide image
    fun showNavFooter(flag: Boolean) {

        if(flag) {
            navView.visibility = VISIBLE
        }
        else{
            navView.visibility = INVISIBLE
        }

    }

    // set nav func button text & image
    fun setNavButtonInfo(infoList: Array<out Map<String, Any>>) {

        var cnt = infoList.size

        if(cnt >= 1) {
            if(infoList[0]["imageId"] is Int && infoList[0]["imageId"] != -1){
                navFuncIcon1.setImageResource(infoList[0]["imageId"] as Int)
            }
            if(infoList[0]["text"] is String && infoList[0]["text"] != "default"){
                navFuncButton1.text = infoList[0]["text"] as String
            }
        }

        if(cnt >= 2) {
            if(infoList[1]["imageId"] is Int && infoList[1]["imageId"] != -1){
                navFuncIcon2.setImageResource(infoList[1]["imageId"] as Int)
            }
            if(infoList[1]["text"] is String && infoList[1]["text"] != "default"){
                navFuncButton2.text = infoList[1]["text"] as String
            }
        }

        if(cnt >= 2) {
            if(infoList[2]["imageId"] is Int && infoList[2]["imageId"] != -1){
                navFuncIcon3.setImageResource(infoList[2]["imageId"] as Int)
            }
            if(infoList[2]["text"] is String && infoList[2]["text"] != "default"){
                navFuncButton3.text = infoList[2]["text"] as String
            }
        }

    }

    // show or hide image
    fun showEndChapterButton(flag: Boolean) {

        if(flag) {
            endChapterButton.visibility = VISIBLE
        }
        else{
            endChapterButton.visibility = INVISIBLE
        }

    }

    // show or hide image
    fun showBottomMessage(flag: Boolean) {

        if(flag) {
            bottomMessage.visibility = VISIBLE
        }
        else{
            bottomMessage.visibility = INVISIBLE
        }

    }

    fun hideUpperMessage(flag: Boolean){

        if(flag) {
            messageBody.isGone = flag
        }
        else{
            messageBody.isGone = flag
        }

    }

    fun showDetailTextIcon(flag: Boolean){

        if(flag) {
            helpIcon.visibility = VISIBLE
        }
        else{
            helpIcon.visibility = INVISIBLE
        }
    }

    fun showDetailTextDialog(){

        // get layout
        val view = layoutInflater.inflate(R.layout.custom_dialog4, null)

        // set dialog title
        view.findViewById<TextView>(R.id.dialog_title).text = "説明用ダイアログ"

        val const_surveyMessage2 = detailText

        // set dialog title
        val htmlText  = HtmlCompat.fromHtml(const_surveyMessage2, HtmlCompat.FROM_HTML_MODE_COMPACT)
        view.findViewById<TextView>(R.id.scrolltext).text    = htmlText

        // show dialog
        AlertDialog.Builder(requireActivity())
            .setView(view)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                Log.d(classTag, "click")
            }
            .show()

    }

    // constant
    companion object {

        val const_default       = "default"
        val const_userAgentKey  = "navOpenClose"

    }
}
