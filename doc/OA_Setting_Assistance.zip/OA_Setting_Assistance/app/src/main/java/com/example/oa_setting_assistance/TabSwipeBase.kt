package com.example.oa_setting_assistance

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.ViewGroup
import android.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout


class TabSwipeBase : AppCompatActivity() {

    // for Log
    private val classTag = TabSwipeBase::class.java.simpleName

    private var toolbar     : Toolbar?              = null
    private var myViewPager : ViewPager?            = null
    private var myTabLayout : TabLayout?            = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tab_swipe_base)

        // receive page number from top
        val pageIndex   = intent.getStringExtra("pageIndex").toInt()

        // set header title
        val header = supportFragmentManager.findFragmentById(R.id.headerTemplate)

        if (header != null &&  header is headerTemplate) {

            if(pageIndex == 0){
                header.setHeaderTitle(OPTION_CHAPTER_TITLE[pageIndex])
            }
            else {
                header.setHeaderTitle(MAIN_CHAPTER_TITLE[pageIndex - 1])
            }
        }
        else{
            Log.d(classTag, "no header fragment")
        }

        var tabLayout = findViewById<TabLayout>(R.id.tabs)

        // add bar
        toolbar = findViewById(R.id.toolBar)
        setActionBar(toolbar)

        // get pager
        myViewPager     = findViewById(R.id.pager)

        // section
        val tutorial    = ViewPagerAdapterTutorial(supportFragmentManager)
        val chapter1    = ViewPagerAdapterChapter1(supportFragmentManager)
        val chapter2    = ViewPagerAdapterChapter2(supportFragmentManager)
        val chapter3_1  = ViewPagerAdapterChapter3_1(supportFragmentManager)
        val chapter3_2  = ViewPagerAdapterChapter3_2(supportFragmentManager)
        val chapter3_3  = ViewPagerAdapterChapter3_3(supportFragmentManager)
        val chapter4    = ViewPagerAdapterChapter4(supportFragmentManager)
        val chapter5    = ViewPagerAdapterChapter5(supportFragmentManager)
        val chapter6    = ViewPagerAdapterChapter6(supportFragmentManager)
        val chapter7    = ViewPagerAdapterChapter7(supportFragmentManager)
        val chapter8    = ViewPagerAdapterChapter8(supportFragmentManager)

        // set pages
        when (pageIndex) {

            0 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                disableTab(tabLayout, 1)
                myViewPager?.adapter = tutorial
            }

            1 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter1
            }

            2 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter2
            }

//            3 -> {
//                tabLayout.tabMode = TabLayout.MODE_SCROLLABLE
//                myViewPager?.adapter = chapter3
//            }
            3 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter3_1
            }

            4 -> {
                tabLayout.tabMode = TabLayout.MODE_SCROLLABLE
                myViewPager?.adapter = chapter3_2
            }

            5 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter3_3
            }

            6 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter4
            }

            7 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter5
            }

            8 -> {
                tabLayout.tabMode = TabLayout.MODE_FIXED
                myViewPager?.adapter = chapter6
            }

//            9 -> {
//                tabLayout.tabMode = TabLayout.MODE_FIXED
//                myViewPager?.adapter = chapter7
//            }

            9 -> {
                tabLayout.tabMode = TabLayout.MODE_SCROLLABLE
                myViewPager?.adapter = chapter8
            }

            else -> {
                myViewPager?.adapter = chapter1
            }

        }

        myTabLayout = findViewById(R.id.tabs)
        myTabLayout?.setupWithViewPager(myViewPager)

    }

    // touch tab disabled
    private fun disableTab(tabLayout: TabLayout, index: Int){
        Handler().postDelayed(Runnable {
            val tabStrip = tabLayout.getChildAt(0) as ViewGroup
            for (i in 0 until tabStrip.childCount){
                tabStrip.getChildAt(i).isEnabled = false
            }
        }, 100)
    }


}
