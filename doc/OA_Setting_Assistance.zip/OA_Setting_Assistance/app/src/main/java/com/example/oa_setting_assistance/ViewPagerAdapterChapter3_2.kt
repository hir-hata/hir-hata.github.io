package com.example.oa_setting_assistance

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapterChapter3_2(fm: FragmentManager) : FragmentPagerAdapter(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    // for Log
    private val classTag = ViewPagerAdapterChapter3::class.java.simpleName

    override fun getItem(position: Int): Fragment {

        var tabFragment:Fragment     = TabFragment()
        var frBundle        = Bundle()
        var pageIndex  = position + 1

        when (pageIndex) {

            1 -> {
                tabFragment = Chapter3_2()
            }

            2 -> {
                tabFragment = Chapter3_3()
            }

//            3 -> {
//                tabFragment = Chapter3_4()
//            }

            3 -> {
                tabFragment = Chapter3_5()
            }

            4 -> {
                tabFragment = Chapter3_6()
            }

            5 -> {
                tabFragment = Chapter3_7()
            }

            6 -> {
                tabFragment = ChapterEnd(MAIN_CHAPTER_CODE[3])
            }

            else -> {
                frBundle.putString("message", "Fragment$pageIndex")
                tabFragment.arguments = frBundle
            }

        }

        return tabFragment
    }

    override fun getCount(): Int {
        return 6
    }

    override fun getPageTitle(position: Int): CharSequence? {

        var pageIndex = position + 1

        if(pageIndex == count){
            return "End"
        }
        else {
            return "Page ${(pageIndex)}"
        }

    }


}