package com.example.oa_setting_assistance

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class Chapter6_2 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter6_2::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

    }

    override fun setOnClickNavFuncButton1() {

        CommonFun.setContext(requireContext())
        CommonFun.sendLog("${LOG_HEADER[2]}${LOG_TEXT[6]}")

        // install emc-call
        val intent = Intent(Intent.ACTION_VIEW).apply {

            data = Uri.parse(
                "https://play.google.com/store/apps/details?id=jp.co.infocom.emc.android"
            )
            setPackage("com.android.vending")
        }
        startActivity(intent)
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    // constant
    companion object {

        val const_class         = Chapter6_2::class.java.simpleName
        val const_title         = "安否確認アプリインストール"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.emc_call_install
        val const_showNavFooter = true
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.google_play_badge, "text" to "安否確認"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = false

        var const_message = """
            「安否確認」ボタンを押下して、<BR>
            「インストール」をタップします
        """.trimIndent()

        var const_bottomMessage = """
        """.trimIndent()

    }

}