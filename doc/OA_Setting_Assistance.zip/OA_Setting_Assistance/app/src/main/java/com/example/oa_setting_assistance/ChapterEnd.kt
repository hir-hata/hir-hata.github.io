package com.example.oa_setting_assistance

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.Image
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.text.HtmlCompat
import com.takusemba.spotlight.Spotlight
import com.takusemba.spotlight.Target
import com.takusemba.spotlight.shape.RoundedRectangle
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class ChapterEnd(
        ChapterIndex         :String        = "-1"
    ) :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage)
    ,    swipeTemplate.OnClickListener {

    private val chapterIndex = ChapterIndex

    // for Log
    private val classTag = ChapterEnd::class.java.simpleName

    private var templateView    : View? = null

    // for spotlight
    private var spotlight : Spotlight? = null
    private var targets = ArrayList<Target>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)
        val endChapterButton  = view.findViewById<Button>(R.id.endChapterButton)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        // set end button
        endChapterButton.text   = const_done

        // end button tap listener
        endChapterButton.setOnClickListener {

            // edit chapter end false -> true
            val dataStore: SharedPreferences = this.requireActivity().getSharedPreferences("UserDefault", Context.MODE_PRIVATE)
            val endChapter = "Chapter$chapterIndex"
            val doneChapterFlag = dataStore.getBoolean("$endChapter", false)

            CommonFun.setContext(requireContext())

            var logKey = LOG_HEADER[0] + setLogText(chapterIndex)

            // first time
            if(!doneChapterFlag) {
                logKey = "${LOG_HEADER[3]}$logKey"
            }

            CommonFun.sendLog(logKey)

//            // show survey dialog
//            if(!doneChapterFlag && chapterIndex == MAIN_CHAPTER_CODE[8]){
//                dataStore.edit().putBoolean("$endChapter", true)
//                    .apply()
//                showDialog()
//            }
//            else {
//                dataStore.edit().putBoolean("$endChapter", true)
//                    .apply()
//                goTop()
//            }

            dataStore.edit().putBoolean("$endChapter", true)
                .apply()
            goTop()
        }

        var planeText = ""

        planeText = when(chapterIndex){

            OPTION_CHAPTER_CODE[0] -> {
                OPTION_CHAPTER_CODE[0] + const_message
            }
            MAIN_CHAPTER_CODE[0] -> {
                MAIN_CHAPTER_TITLE[0] + const_message
            }
            MAIN_CHAPTER_CODE[1] -> {
                MAIN_CHAPTER_TITLE[1] + const_message
            }
            MAIN_CHAPTER_CODE[2] -> {
                MAIN_CHAPTER_TITLE[2] + const_message
            }
            MAIN_CHAPTER_CODE[3] -> {
                MAIN_CHAPTER_TITLE[3] + const_message
            }
            MAIN_CHAPTER_CODE[4] -> {
                MAIN_CHAPTER_TITLE[4] + const_message
            }
            MAIN_CHAPTER_CODE[5] -> {
                MAIN_CHAPTER_TITLE[5] + const_message
            }
            MAIN_CHAPTER_CODE[6] -> {
                MAIN_CHAPTER_TITLE[6] + const_message
            }
            MAIN_CHAPTER_CODE[7] -> {
                MAIN_CHAPTER_TITLE[7] + const_message
            }
            MAIN_CHAPTER_CODE[8] -> {
                MAIN_CHAPTER_TITLE[8] + const_message
            }
//            MAIN_CHAPTER_CODE[9] -> {
//                MAIN_CHAPTER_TITLE[9] + const_message
//            }
            else -> {
                "" + const_message
            }
        }

        val htmlText  = HtmlCompat.fromHtml(planeText, HtmlCompat.FROM_HTML_MODE_COMPACT)
        messageBody.text    = htmlText

    }

    fun showDialog(){

        // get layout
        val view = layoutInflater.inflate(R.layout.custom_dialog3, null)

        // set dialog title
        view.findViewById<TextView>(R.id.dialog_title).text = const_surveyTitle

        // set dialog title
        val htmlText  = HtmlCompat.fromHtml(const_surveyMessage, HtmlCompat.FROM_HTML_MODE_COMPACT)
        view.findViewById<TextView>(R.id.dialog_message).text    = htmlText

        // show dialog
        AlertDialog.Builder(requireActivity())
            .setView(view)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                goTop()
            }
            .show()

    }

    fun goTop(){
        // back to top page
        val intent = Intent(requireContext(), TopActivity::class.java)
        startActivity(intent)
        activity?.overridePendingTransition(R.anim.in_left, R.anim.out_right)
    }

    fun makeTarget(layerType : Int, target : View, description : String, next: Boolean) : Target {

        // 1st coach mark
        val rootContext = ConstraintLayout(context)
        var coachLayout = layoutInflater.inflate(layerType, rootContext)
        val coachTargetView = target
        val coachInfo = Target.Builder()
            .setAnchor(coachTargetView)
            .setShape(RoundedRectangle(coachTargetView.height.toFloat() + 10f, coachTargetView.width.toFloat() + 10f, 10f))
            .setOverlay(coachLayout)
            .build()

        // disable child view
        coachLayout.setOnClickListener {
        }

        coachLayout.findViewById<TextView>(R.id.coach_mark_text).text = description

        val nextTarget      = View.OnClickListener { spotlight!!.next() }
        val closeSpotlight  = View.OnClickListener { spotlight!!.finish() }

        if(next) {
            coachLayout.findViewById<View>(R.id.close_target).setOnClickListener(nextTarget)
        }
        else{
            coachLayout.findViewById<View>(R.id.close_target).setOnClickListener(closeSpotlight)
        }

        return coachInfo

    }

    fun showSpotlight(){

        targets.add(makeTarget(R.layout.coach_mark_target_center, templateView!!.findViewById<View>(R.id.endChapterButton),
            const_coach_message1, false))

        // create spotlight
        spotlight = Spotlight.Builder(activity as Activity)
            .setTargets(targets)
            .setBackgroundColor(R.color.deepBlackTr)
            .setDuration(100L)
            .setAnimation(DecelerateInterpolator(2f))
            .build()

        spotlight!!.start()

    }

    fun setLogText(chapterIndex : String) : String {

        var text = ""

        text = when(chapterIndex){

            OPTION_CHAPTER_CODE[0] -> {
                OPTION_CHAPTER_CODE[0]
            }
            MAIN_CHAPTER_CODE[0] -> {
                MAIN_CHAPTER_CODE[0]
            }
            MAIN_CHAPTER_CODE[1] -> {
                MAIN_CHAPTER_CODE[1]
            }
            MAIN_CHAPTER_CODE[2] -> {
                MAIN_CHAPTER_CODE[2]
            }
            MAIN_CHAPTER_CODE[3] -> {
                MAIN_CHAPTER_CODE[3]
            }
            MAIN_CHAPTER_CODE[4] -> {
                MAIN_CHAPTER_CODE[4]
            }
            MAIN_CHAPTER_CODE[5] -> {
                MAIN_CHAPTER_CODE[5]
            }
            MAIN_CHAPTER_CODE[6] -> {
                MAIN_CHAPTER_CODE[6]
            }
            MAIN_CHAPTER_CODE[7] -> {
                MAIN_CHAPTER_CODE[7]
            }
            MAIN_CHAPTER_CODE[8] -> {
                MAIN_CHAPTER_CODE[8]
            }
            MAIN_CHAPTER_CODE[9] -> {
                MAIN_CHAPTER_CODE[9]
            }
            else -> {
                ""
            }
        }

        return text
    }

    override fun onResume() {
        super.onResume()
        Log.d(classTag,"onResume : ${classTag}")

        if(chapterIndex == OPTION_CHAPTER_CODE[0]) {
            showSpotlight()
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d(classTag,"onPause : ${classTag}")

        if(chapterIndex == OPTION_CHAPTER_CODE[0]) {
            spotlight!!.finish()
        }
    }


    override fun setOnClickNavFuncButton1() {
        Log.d(classTag, "navFuncButton1")
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    // constant
    companion object {

        val const_class         = ChapterEnd::class.java.simpleName
        val const_title         = "手順の完了"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.done
        val const_showNavFooter = false
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.phone_icon, "text" to "電話する"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )
        val const_showEndChapterButton  = true
        val const_showBottomMessage     = false
        val const_hideUpperMessage      = false

        var const_message = """
        の手順は終了です<br>
        <br>
        完了ボタンを押下し、次の手順に進んでください
        """.trimIndent()

        var const_bottomMessage = """
        """.trimIndent()

        val const_done = "完了"

        var const_coach_message1 = """
            各手順の最後に完了画面が表示されます
            完了ボタンをタップすることで
            次の手順に進めるようになります
        """.trimIndent()

        var const_surveyTitle   = "アンケートへのご協力のお願い"

        var const_surveyMessage = """
        <BR>
        設定お疲れ様でした！<BR>
        <BR>
        さらなる、アプリ品質向上の為<BR>
        アンケートへのご協力をお願いいたします<BR>
        <BR>
        後日、アンケートメールを配信しますので、
        アンケートへお答えください
        """

    }
}