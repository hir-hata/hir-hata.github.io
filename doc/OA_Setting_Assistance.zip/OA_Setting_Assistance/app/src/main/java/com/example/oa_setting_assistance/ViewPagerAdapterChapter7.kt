package com.example.oa_setting_assistance

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapterChapter7(fm: FragmentManager) : FragmentPagerAdapter(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    // for Log
    private val classTag = ViewPagerAdapterChapter7::class.java.simpleName

    override fun getItem(position: Int): Fragment {

        var tabFragment:Fragment     = TabFragment()
        var frBundle        = Bundle()
        var pageIndex  = position + 1

        when (pageIndex) {

            1 -> {
                tabFragment = Chapter7_4()
            }

            2 -> {
                tabFragment = ChapterEnd(MAIN_CHAPTER_CODE[8])
            }

            else -> {
                frBundle.putString("message", "Fragment$pageIndex")
                tabFragment.arguments = frBundle
            }

        }

        return tabFragment
    }

    override fun getCount(): Int {
        return 2
    }

    override fun getPageTitle(position: Int): CharSequence? {

        var pageIndex = position + 1

        if(pageIndex == count){
            return "End"
        }
        else {
            return "Page ${(pageIndex)}"
        }

    }


}