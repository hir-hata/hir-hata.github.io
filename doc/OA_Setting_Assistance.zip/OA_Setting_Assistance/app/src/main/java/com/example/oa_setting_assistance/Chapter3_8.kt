package com.example.oa_setting_assistance

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context.CLIPBOARD_SERVICE
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isGone
import kotlinx.android.synthetic.main.fragment_swipe_template.*

class Chapter3_8 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage,
        const_hideUpperMessage,
        const_showDetailTextIcon,
        const_detailText)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Chapter3_8::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView    : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        imageView.setOnClickListener{
            changeImage()
        }
    }

    override fun setOnClickNavFuncButton1() {
        // launch anyconnect
        val intent      = Intent()
        val packageName = "com.cisco.anyconnect.vpn.android.avf"
        val className   = "com.cisco.anyconnect.ui.PrimaryActivity"
        intent.setClassName(packageName,className)
        startActivity(intent)
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    private fun changeImage() {

        when (currentImage) {
            R.drawable.anyconnect_setup_1_1 -> {
                currentImage = R.drawable.anyconnect_setup_1_2
            }
            R.drawable.anyconnect_setup_1_2 -> {
                currentImage = R.drawable.anyconnect_setup_1_3
            }
            R.drawable.anyconnect_setup_1_3 -> {
                currentImage = R.drawable.tap_image_back
            }
            else -> {
                currentImage = R.drawable.anyconnect_setup_1_1
            }
        }

        imageView.setImageResource(currentImage)

    }

    // constant
    companion object {

        val const_class         = Chapter3_8::class.java.simpleName
        val const_title         = "AnyConnect設定 1"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tap_image
        val const_showNavFooter = false
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.app_open_icon, "text" to "AnyConnect"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true
        val const_hideUpperMessage      = true
        val const_showDetailTextIcon    = true

        var const_message = """
        <font color=#ff0000><b>!! 件名：[Android-VPN]証明書発行のお知らせ MACアドレス:・・・のメール内容で
        <BR>VPNの設定が完了している場合は本対応不要です !!</b></font><BR>
        """.trimIndent()

        var const_bottomMessage = """
        ホーム画面から「AnyConnect」を起動し、<BR>
        以降は画像をタップし手順に従い設定します<BR>
        <BR>
        <font color=#ff0000><b>!! AnyConnectに許可～が出ない場合があります !!</b></font>
        """.trimIndent()

        val const_detailText = """
        ホーム画面から「AnyConnect」を起動し、<BR>
        確認のダイアログを2回ともに「OK」タップします<BR>
        <BR>
        AnyConnectに許可～が表示された場合は、<BR>
        「許可」をタップしてください<BR>
        <BR>
        <font color=#ff0000><b>!! AnyConnectに許可～が出ない場合があります !!</b></font>
        """.trimIndent()
    }

}