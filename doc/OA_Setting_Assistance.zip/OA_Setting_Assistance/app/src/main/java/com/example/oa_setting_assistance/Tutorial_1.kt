package com.example.oa_setting_assistance

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.takusemba.spotlight.Spotlight
import com.takusemba.spotlight.Target
import com.takusemba.spotlight.shape.RoundedRectangle


class Tutorial_1 :
    swipeTemplate(
        const_class,
        const_title,
        const_message,
        const_showImageView,
        const_imageResource,
        const_showNavFooter,
        const_numOfNavIcon,
        const_navButtonInfo,
        const_showPCicon,
        const_showEndChapterButton,
        const_showBottomMessage,
        const_bottomMessage)
    ,    swipeTemplate.OnClickListener {

    // for Log
    private val classTag = Tutorial_1::class.java.simpleName

    // current image id
    private var currentImage = 0

    private var templateView        : View? = null
    private var headerTemplateView  : View? = null
    private var tabLayout : View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        templateView =  inflater.inflate(R.layout.fragment_swipe_template, container, false)

        return templateView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        Log.d(classTag,"onViewCreated : ${classTag}")

        super.onViewCreated(view, savedInstanceState)

        //var imageView = view.findViewById<ImageView>(R.id.imageView)

        // init
        currentImage = const_imageResource

        // get element
        val navFuncButton1  = view.findViewById<TextView>(R.id.navFuncButton1)
        val navFuncButton2  = view.findViewById<TextView>(R.id.navFuncButton2)
        val navFuncButton3  = view.findViewById<TextView>(R.id.navFuncButton3)
        val endChapterButton = view.findViewById<Button>(R.id.endChapterButton)

        //***** prepare for changing constraint programmatically *****/
        navFuncButton1.setOnClickListener{
            setOnClickNavFuncButton1()
        }

        navFuncButton2.setOnClickListener {
            setOnClickNavFuncButton2()
        }

        navFuncButton3.setOnClickListener {
            setOnClickNavFuncButton3()
        }

        endChapterButton.setOnClickListener{
            Log.d(classTag, "tap endend")
        }

    }

    override fun setOnClickNavFuncButton1() {
        Log.d(classTag, "navFuncButton1")
    }

    override fun setOnClickNavFuncButton2() {
        Log.d(classTag, "navFuncButton2")
    }

    override fun setOnClickNavFuncButton3() {
        Log.d(classTag, "navFuncButton3")
    }

    override fun setOnClickOpenCloseImage() {
        Log.d(classTag, "click opencloseImage")
    }

    // constant
    companion object {

        val const_class         = Tutorial_1::class.java.simpleName
        val const_title         = "チュートリアル1"
        val const_showPCicon    = false
        val const_showImageView = true
        val const_imageResource = R.drawable.tutorial_0
        val const_showNavFooter = false
        val const_numOfNavIcon  = 1
        val const_navButtonInfo = arrayOf(
            mapOf("imageId" to R.drawable.app_open_icon, "text" to "ボタン1"),
            mapOf("imageId" to R.drawable.mms_icon, "text" to "button text2"),
            mapOf("imageId" to R.drawable.copy_icon, "text" to "button text3")
        )

        val const_showEndChapterButton  = false
        val const_showBottomMessage     = true

        var const_message = """
            指を右から左にスライド(※)させることで<BR>
            ページを進めることができます<BR>
            戻る場合には、逆の動作を行ってください
        """.trimIndent()

        var const_bottomMessage = """
            ※この操作をスワイプと呼びます
        """.trimIndent()

    }

}