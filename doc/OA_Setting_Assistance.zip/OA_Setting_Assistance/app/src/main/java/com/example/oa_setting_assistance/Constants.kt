package com.example.oa_setting_assistance

val MAIN_CHAPTER_TITLE = arrayOf(
    "事前準備",
    "アンチウイルス設定",
    "VPN事前確認",
    "VPNアプリ設定",
    "VPN証明書インストール",
    "VPN接続確認",
    "Gmail設定",
    "安否確認システム",
//    "yellow接続確認",
    "その他設定"
)

val MAIN_CHAPTER_CODE = arrayOf(
    "Intro",
    "AntiVirus",
    "VPN_Pre",
    "VPN_App",
    "VPN_Cert",
    "VPN_Confirm",
    "Gmail",
    "Safety",
//    "Yellow",
    "AnySetting"
)


val OPTION_CHAPTER_TITLE = arrayOf(
    "このアプリの使い方",
    "最初からやり直す",
    "お問い合わせ"
)

val OPTION_CHAPTER_CODE = arrayOf(
    "Tutorial",
    "Reset",
    "Inquiry"
)

val DIALOG_MESSAGE = arrayOf(
    "最初からやり直します。よろしいですか？",

    """OAサポート窓口へ電話をします。
よろしいですか？
    """.trimIndent(),

    "Inquiry",

    """設定補助アプリにようこそ！
    """.trimIndent(),

    """端末の設定を始める前に
アプリの操作方法を学びましょう！
    """.trimIndent()
)

val LOG_HEADER = arrayOf(
    "Done_",
    "TapMenu_",
    "Click_",
    "First_"
)

val LOG_TEXT = arrayOf(
    "WiFi_Spot",
    "MMS_Input",
    "MMS_Open",
    "BCDM",
    "DeviceID",
    "AnyConnect",
    "EMC_Call",
    "Slack",
    "Zoom"
)

val PHONE_NUMBER = arrayOf(
    "080-0919-9900",
    "012-3456-7890"
)

val YELLOW_PW = arrayOf(
    "5X74fukLo7",
    "abcdefghij"
)

val OTHER_CONSTANTS = arrayOf(
    "firstLaunch"
)